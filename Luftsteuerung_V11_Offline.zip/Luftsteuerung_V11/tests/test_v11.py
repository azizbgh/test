import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock

from luftsteuerung.hardware import DaqController
from luftsteuerung.konfiguration import AO_CHANNELS, AI_GHF, AI_GLF
from luftsteuerung.protokoll import SessionLog
from luftsteuerung.regelung import RegulationSettings
from luftsteuerung.worker import DaqWorker


class MappingTests(unittest.TestCase):
    def test_daq_routes_logical_output_names_to_physical_channels(self):
        tasks = [Mock() for _ in range(3)]
        for task in tasks:
            task.write.return_value = 1
        hardware = DaqController(driver=Mock(Task=Mock(side_effect=tasks)))
        for channel in ("FU", "GHF", "GLF"):
            hardware.write_current(channel, .008)
        for idx, task in enumerate(tasks):
            self.assertTrue(task.ao_channels.add_ao_current_chan.call_args.args[0].endswith(f"/ao{idx}"))
        self.assertTrue(AI_GHF.endswith("/ai0"))
        self.assertTrue(AI_GLF.endswith("/ai1"))

    def test_v11_log_records_actual_layout_and_blocked_auto_has_no_queue(self):
        worker = DaqWorker(DaqController(driver=Mock()), allow_automation=False)
        with self.assertRaises(RuntimeError):
            worker.request_start_regulation(RegulationSettings("BEIDE", 155))
        self.assertTrue(worker.commands.empty())
        with tempfile.TemporaryDirectory() as tmp:
            session = SessionLog(Path(tmp))
            path = session.start({}, worker.regulation_snapshot, 1.0)
            session.close()
            meta = json.loads(path.read_text().splitlines()[0].removeprefix("# metadata "))
            self.assertEqual(meta["output_mapping_version"], 2)
            self.assertEqual(meta["output_channels"], AO_CHANNELS)


try:
    import numpy
    import scipy
except ImportError:
    HAVE_OFFLINE = False
else:
    HAVE_OFFLINE = True


@unittest.skipUnless(HAVE_OFFLINE, "requirements-offline.txt erforderlich")
class OfflineTests(unittest.TestCase):
    def test_historical_only_swaps_output_columns_and_refuses_double_swap(self):
        from luftsteuerung.identifikation import protocol
        fixture = {
            "format_version": 1,
            "settings": {"recording_kind": "manual", "measurement_source": "hardware"},
            "initial_snapshot": {"outputs_percent": {"GLF": 90, "GHF": 80, "FU": 20}},
        }
        csv_header = "mode;GLF_confirmed_percent;GHF_confirmed_percent;GLF_command_current_A;GHF_command_current_A;GLF_m3h;GHF_m3h\n"
        csv_row = "MANUAL;90;80;0.0056;0.0072;32;132\n"
        with tempfile.TemporaryDirectory() as tmp:
            original = Path(tmp) / "CSV_B02.csv"
            original.write_text("# metadata " + json.dumps(fixture) + "\n" + csv_header + csv_row)
            original_bytes = original.read_bytes()
            meta, _, rows = protocol(original, legacy=True)
            self.assertEqual(rows[0]["GHF_confirmed_percent"], "90")
            self.assertEqual(rows[0]["GHF_command_current_A"], "0.0056")
            self.assertEqual(rows[0]["GLF_m3h"], "32")
            self.assertEqual(meta["initial_snapshot"]["outputs_percent"]["GHF"], 90)
            self.assertEqual(original.read_bytes(), original_bytes)
            normalized = Path(tmp) / "normalized.csv"
            normalized.write_text("# metadata " + json.dumps(meta) + "\n" + csv_header + csv_row)
            with self.assertRaises(ValueError):
                protocol(normalized, legacy=True)
            self.assertEqual(protocol(normalized)[0]["output_mapping_version"], 2)

    def test_model_delay_and_limits(self):
        from luftsteuerung.anlagenmodell import LocalPlant
        gains = {"FU->GHF": 3, "FU->GLF": .7, "GHF->GHF": .75,
                 "GHF->GLF": -.4, "GLF->GHF": -.4, "GLF->GLF": .45}
        model = {"u0": [20, 80, 80], "y0": [131, 30],
                 "paths": {key: {"K": k, "T": 2, "L": 3} for key, k in gains.items()}}
        plant = LocalPlant("B", model, .1, (20, 80, 80))
        for _ in range(30):
            plant.advance((25, 80, 80))
        self.assertEqual(plant.measure(), (131, 30))
        for _ in range(240):
            plant.advance((25, 80, 80))
        self.assertAlmostEqual(plant.measure()[0], 146, places=3)
        with self.assertRaises(ValueError):
            plant.advance((26, 80, 80))
