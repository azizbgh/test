"""Lokales B/C-Mehrgrößenmodell für Offline-Versuche mit bestätigten Befehlen."""

from __future__ import annotations

import math

from .identifikation import INPUTS, OUTPUTS

# Aus den beobachteten Einzelstellversuchen. Gleichzeitige Bewegung im Kasten
# bleibt eine lineare Superpositionsannahme, bis D03 vorliegt.
OPERATING_BOUNDS = {
    "B": ((15.0, 25.0), (70.0, 90.0), (70.0, 90.0)),
    "C": ((35.0, 40.0), (80.0, 90.0), (80.0, 90.0)),
}


def clamp(value, bounds):
    return max(bounds[0], min(bounds[1], value))


class LocalPlant:
    """Sechs PT1-Zustände mit verzögerter Eingabe, keine DAQ-Schnittstelle."""

    def __init__(self, point, model, dt, initial, variant="train"):
        self.bounds = OPERATING_BOUNDS[point]
        self.u0 = model["u0"]
        self.y0 = model["y0"]
        self.initial = tuple(initial)
        self.history = []
        if not self.in_domain(initial):
            raise ValueError("Initialbefehle außerhalb der lokalen Versuchsgrenzen.")
        self.paths = []
        for i, actuator in enumerate(INPUTS):
            for j, sensor in enumerate(OUTPUTS):
                record = model["paths"][f"{actuator}->{sensor}"]
                gain, tau, delay = (record[key] for key in ("K", "T", "L"))
                if variant != "train":
                    observed = record["observed_range"]
                    if variant == "slow":
                        gain = min(observed["K"], key=abs)
                        tau, delay = observed["T"][1], observed["L"][1]
                    elif variant == "strong":
                        gain = max(observed["K"], key=abs)
                        tau, delay = observed["T"][0], observed["L"][0]
                    else:
                        raise ValueError(f"Unbekannte Modellvariante {variant}.")
                # Verzögerung auf Unterabtastung runden und im Modell linear interpolieren.
                age = delay / dt
                self.paths.append((i, j, gain, -math.expm1(-dt / tau), int(age), age % 1))
        self.states = [gain * (initial[i] - self.u0[i]) for i, _, gain, _, _, _ in self.paths]

    def in_domain(self, commands):
        return len(commands) == len(self.bounds) and all(
            math.isfinite(u) and lo <= u <= hi for u, (lo, hi) in zip(commands, self.bounds))

    def measure(self):
        y = list(self.y0)
        for x, (_, j, _, _, _, _) in zip(self.states, self.paths):
            y[j] += x
        return tuple(y)

    def advance(self, commands):
        if not self.in_domain(commands):
            raise ValueError("Stellbefehl außerhalb des lokalen Modellbereichs.")
        self.history.append(tuple(commands))
        for n, (i, _, gain, alpha, lag, fraction) in enumerate(self.paths):
            recent = len(self.history) - 1 - lag
            right = self.history[recent][i] if recent >= 0 else self.initial[i]
            left = self.history[recent - 1][i] if recent > 0 else self.initial[i]
            target = gain * (right * (1 - fraction) + left * fraction - self.u0[i])
            self.states[n] += alpha * (target - self.states[n])
