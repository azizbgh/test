"""Messprotokoll einer Regelsitzung; ausschließlich Dateiausgabe.

Die CSV unterscheidet Sensorströme von bestätigten Stellbefehlen. Der Strom
zu einem Stellbefehl wird nur berechnet und ist keine Ausgangsrückmessung.
Alle Aufrufe gehören in denselben Besitzerthread. Dateifehler werden an den
Aufrufer weitergegeben; dieses Modul besitzt keine DAQ- oder GUI-Funktionen.
"""

from __future__ import annotations

import csv
from collections.abc import Mapping
from dataclasses import fields, is_dataclass
from datetime import datetime, timezone
from enum import Enum
import json
import math
from pathlib import Path
from uuid import uuid4

from .konfiguration import AO_CHANNELS, AO_MAPPING_VERSION, SENSOR_CHANNELS
from .kennlinien import CONFIGURED_ACTUATOR_CURVES, ghf_amp_to_m3h, glf_amp_to_m3h


CSV_FIELDS = (
    "timestamp_monotonic_s", "elapsed_s", "status", "mode", "setpoint_m3h",
    "control_flow_m3h", "error_m3h", "GHF_m3h", "GLF_m3h",
    "GHF_sensor_current_A", "GLF_sensor_current_A", "GHF_age_ms", "GLF_age_ms",
    "FU_confirmed_percent", "FU_command_current_A",
    "GLF_confirmed_percent", "GLF_command_current_A",
    "GHF_confirmed_percent", "GHF_command_current_A",
    "GHF_target_m3h", "GLF_target_m3h", "message", "warning", "within_tolerance",
)


def _get(value, name, default=None):
    return value.get(name, default) if isinstance(value, Mapping) else getattr(value, name, default)


def _json_value(value):
    """Datenbehälter ohne Hardwareobjekte oder versteckte Objektattribute lesen."""
    if is_dataclass(value) and not isinstance(value, type):
        return {field.name: _json_value(getattr(value, field.name)) for field in fields(value)}
    if isinstance(value, Mapping):
        return {str(key): _json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_value(item) for item in value]
    if isinstance(value, Enum):
        return _json_value(value.value)
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    raise TypeError(f"Nicht unterstützter Protokoll-Metadatentyp: {type(value).__name__}")


def _finite(value):
    return (isinstance(value, (int, float)) and not isinstance(value, bool)
            and math.isfinite(value))


def _number(value):
    return value if _finite(value) else ""


def _raw_current(value):
    if _finite(value):
        return value
    if isinstance(value, float):
        return "NaN" if math.isnan(value) else "+Inf" if value > 0 else "-Inf"
    return ""


def _text(value):
    return "" if value is None else str(value.value if isinstance(value, Enum) else value)


class SessionLog:
    """Pro Regellauf eine neue UTF-8-CSV, periodische Proben mit höchstens 10 Hz.

    Statuswechsel werden zusätzlich sofort gespeichert, insbesondere Stopp/Fehler.

    ``None`` als Verzeichnis deaktiviert die Dateiausgabe. ``snapshot`` folgt
    dem Vertrag von RegulationSnapshot; ``outputs_percent`` darf ausschließlich
    bestätigte Befehle enthalten. ``start`` ersetzt keinen bestehenden Dateinamen.
    Alle OSError bleiben sichtbar, damit der Worker eine GUI-Warnung melden kann,
    ohne den Anlagenzustand allein wegen eines Protokollfehlers zu verändern.
    """

    def __init__(self, log_directory: Path | None):
        self.log_directory = None if log_directory is None else Path(log_directory)
        self.path: Path | None = None
        self._stream = None
        self._writer = None
        self._started_at = None
        self._last_written_at = None
        self._last_status = None

    @property
    def active(self) -> bool:
        return self._stream is not None

    def start(self, settings, snapshot, now: float) -> Path | None:
        """Metadaten und CSV-Kopf schreiben; vorhandenen Lauf zuvor abschließen."""
        self.close()
        if self.log_directory is None:
            return None
        if not _finite(now):
            raise ValueError("Protokollstart benötigt eine endliche monotone Zeit.")
        metadata = {
            "format_version": 1,
            "output_mapping_version": AO_MAPPING_VERSION,
            "output_channels": dict(AO_CHANNELS),
            "sensor_channels": dict(SENSOR_CHANNELS),
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
            "start_monotonic_s": now,
            "settings": _json_value(settings),
            "initial_snapshot": _json_value(snapshot),
            "output_semantics": "Bestätigte Sollbefehle; command_current_A ist berechnet, kein gemessener Ausgangsstrom.",
            "sampling": "Periodische Messungen höchstens 10 Hz; Statuswechsel werden zusätzlich sofort gespeichert. Zeitstempel stammen aus dem aufrufenden Worker.",
            "evidence": {
                "manufacturer_validation": False,
                "hardware_validation": False,
                "GHF_minimum": "Vorläufige Softwarevorgabe; keine belegte untere Messgenauigkeitsgrenze.",
                "error_delay": "Projektvorgabe von zunächst 2 s ist vorläufig; keine Hersteller- oder Sicherheitsfreigabe.",
            },
        }
        metadata_line = "# metadata " + json.dumps(metadata, ensure_ascii=False, allow_nan=False)
        self.log_directory.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
        path = self.log_directory / f"luftsteuerung_{stamp}_{uuid4().hex}.csv"
        stream = path.open("x", encoding="utf-8", newline="")
        try:
            stream.write(metadata_line + "\n")
            writer = csv.DictWriter(stream, fieldnames=CSV_FIELDS, delimiter=";", lineterminator="\n")
            writer.writeheader()
            stream.flush()
        except Exception:
            stream.close()
            raise
        self.path, self._stream, self._writer = path, stream, writer
        self._started_at, self._last_written_at = now, None
        self._last_status = None
        return path

    def record(self, snapshot, readings, now: float) -> bool:
        """Probe speichern; Statuswechsel umgehen die periodische 10-Hz-Grenze."""
        if self._stream is None:
            return False
        if not _finite(now) or now < self._started_at:
            raise ValueError("Protokollzeit ist ungültig oder liegt vor dem Start.")
        status = _text(_get(snapshot, "status"))
        if self._last_written_at is not None:
            if now < self._last_written_at:
                raise ValueError("Protokollzeit darf nicht rückwärts laufen.")
            if now - self._last_written_at < .1 - 1e-9 and status == self._last_status:
                return False
        row = {
            "timestamp_monotonic_s": now,
            "elapsed_s": now - self._started_at,
            "status": status,
            "mode": _text(_get(snapshot, "mode")),
            "setpoint_m3h": _number(_get(snapshot, "setpoint_m3h")),
            "control_flow_m3h": _number(_get(snapshot, "measured_total_m3h")),
            "error_m3h": _number(_get(snapshot, "error_m3h")),
            "message": _text(_get(snapshot, "message")),
            "warning": _text(_get(snapshot, "warning")),
        }
        within = _get(snapshot, "within_tolerance")
        row["within_tolerance"] = int(within) if isinstance(within, bool) else ""
        branch_targets = _get(snapshot, "branch_setpoints", {})
        for name, convert in (("GHF", ghf_amp_to_m3h), ("GLF", glf_amp_to_m3h)):
            reading = _get(readings, name)
            current = _get(reading, "current_a")
            at = _get(reading, "received_at")
            row[f"{name}_sensor_current_A"] = _raw_current(current)
            row[f"{name}_m3h"] = _number(convert(current)) if _finite(current) else ""
            # Negative Alter bleiben Diagnosehinweise auf einen Zukunftszeitstempel.
            row[f"{name}_age_ms"] = (now - at) * 1000.0 if _finite(at) and at > 0 else ""
            row[f"{name}_target_m3h"] = _number(_get(branch_targets, name))
        confirmed = _get(snapshot, "outputs_percent", {})
        for name in ("FU", "GLF", "GHF"):
            percent = _get(confirmed, name)
            valid = _finite(percent) and 0 <= percent <= 100
            row[f"{name}_confirmed_percent"] = percent if valid else ""
            row[f"{name}_command_current_A"] = CONFIGURED_ACTUATOR_CURVES[name](percent) if valid else ""
        self._writer.writerow(row)
        self._stream.flush()
        self._last_written_at, self._last_status = now, status
        return True

    def close(self) -> None:
        """Daten flushen und schließen; Dateifehler nicht als Hardwarefehler umdeuten."""
        stream = self._stream
        self._stream, self._writer = None, None
        if stream is not None:
            try:
                stream.flush()
            finally:
                stream.close()
