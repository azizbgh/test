"""Historische manuelle Sprünge normalisieren und lokale PT1-Modelle schätzen."""

from __future__ import annotations

import argparse
import csv
from hashlib import sha256
import json
from pathlib import Path
from statistics import median

import numpy as np
from scipy.optimize import least_squares

from .konfiguration import AO_CHANNELS, AO_MAPPING_VERSION, SENSOR_CHANNELS
from .regelung import GLF_RELIABLE_MIN_M3H


INPUTS = ("FU", "GHF", "GLF")
OUTPUTS = ("GHF", "GLF")
# Freigegebene Namen und physische Sollwertfolgen dieser historischen Messkampagne.
TRIALS = {
    "B01": ("FU", (20, 25, 20, 15, 20)),
    "B02": ("GHF", (80, 90, 80, 70, 80)),
    "B03": ("GLF", (80, 90, 80, 70, 80)),
    "C01": ("FU", (35, 40, 35)),
    "C02": ("GHF", (80, 90, 80)),
    "C03": ("GLF", (80, 90, 80)),
    "D01": ("GHF", (100, 0, 100)),
    "D02": ("GLF", (100, 0, 100)),
}


def protocol(path: Path, *, legacy: bool = False):
    """Nur explizit als historisch angegebene Rohdateien umbenennen."""
    with path.open(encoding="utf-8-sig", newline="") as stream:
        header = stream.readline()
        if not header.startswith("# metadata "):
            raise ValueError(f"{path.name}: Metadaten fehlen.")
        metadata = json.loads(header.removeprefix("# metadata "))
        reader = csv.DictReader(stream, delimiter=";")
        rows = list(reader)
        columns = reader.fieldnames
    if not columns or not rows or any(None in row or None in row.values() for row in rows):
        raise ValueError(f"{path.name}: unvollständige CSV.")

    version = metadata.get("output_mapping_version")
    if legacy:
        if version is not None or metadata.get("normalization") is not None:
            raise ValueError(f"{path.name}: dieser Stand darf nicht erneut vertauscht werden.")
        if metadata.get("format_version") != 1 or metadata.get("settings") != {
            "recording_kind": "manual", "measurement_source": "hardware",
        } or any(row["mode"] != "MANUAL" for row in rows):
            raise ValueError(f"{path.name}: kein historisches manuelles Hardwareprotokoll.")
        for row in rows:
            for suffix in ("confirmed_percent", "command_current_A"):
                a, b = f"GHF_{suffix}", f"GLF_{suffix}"
                row[a], row[b] = row[b], row[a]
        initial = metadata["initial_snapshot"]["outputs_percent"]
        initial["GHF"], initial["GLF"] = initial["GLF"], initial["GHF"]
        metadata.update(output_mapping_version=AO_MAPPING_VERSION, output_channels=AO_CHANNELS,
                        sensor_channels=SENSOR_CHANNELS, normalization={
                            "source": path.name, "sha256": sha256(path.read_bytes()).hexdigest(),
                            "source_output_mapping_version": 1,
                            "swapped": ["GHF_confirmed_percent", "GLF_confirmed_percent",
                                        "GHF_command_current_A", "GLF_command_current_A",
                                        "initial_snapshot.outputs_percent.GHF/GLF"],
                        })
    elif version != AO_MAPPING_VERSION or metadata.get("output_channels") != AO_CHANNELS:
        raise ValueError(f"{path.name}: unbekannte Stellkanal-Version. Herkunft prüfen.")
    return metadata, columns, rows


def step_response(t, gain, time_constant, delay, delta):
    """PT1 mit Totzeit, bezogen auf den stationären Vorwert."""
    return gain * delta * -np.expm1(-np.maximum(0.0, t - delay) / time_constant)


def _fit(t, y, baseline, delta, tail, output, age):
    end = float(np.median(y[tail]))
    change = end - baseline
    limit = 50.0 if output == "GHF" else GLF_RELIABLE_MIN_M3H
    if min(baseline, end) < limit or len(y) < 40 or t[-1] < 10:
        return {"accepted": False, "reason": "Messbereich oder Fenster", "before": baseline, "after": end}
    noise = float(1.4826 * np.median(np.abs(y[t < 0] - baseline)))
    if abs(change) < max(0.25, 3 * noise):
        return {"accepted": False, "reason": "Sprung im Rauschen", "before": baseline, "after": end, "noise": noise}
    relative = y - baseline
    result = least_squares(
        lambda x: step_response(t, *x, delta) - relative,
        [np.clip(change / delta, -19.9, 19.9), 2.0, 2.5],
        bounds=([-20, .15, 0], [20, 20, min(10, t[-1] - 3)]),
        loss="soft_l1", f_scale=max(.15, noise),
    )
    k, tau, delay = map(float, result.x)
    predicted = step_response(t, k, tau, delay, delta)
    rmse = float(np.sqrt(np.mean((predicted - relative) ** 2)))
    variance = float(np.var(y))
    r2 = 1 - rmse**2 / variance if variance > 0 else 0
    accepted = (result.success and r2 >= .7 and np.sign(k) == np.sign(change / delta)
                and tau < 19.9 and delay < min(10, t[-1] - 3) - .1)
    return {"accepted": bool(accepted), "K": k, "T": tau, "L": delay,
            "rmse": rmse, "r2": r2, "noise": noise, "before": baseline, "after": end,
            "max_sample_age_ms": float(np.max(age))}


def analyze_trials(paths: list[Path], normalized: Path, *, legacy: bool):
    """Ausgabeverzeichnis neu anlegen. Originalprotokolle bleiben schreibgeschützt."""
    supplied = {p.stem.removeprefix("CSV_"): p for p in paths}
    if len(paths) != len(TRIALS) or set(supplied) != set(TRIALS):
        raise ValueError("Genau CSV_B01–B03, CSV_C01–C03 und CSV_D01–D02 angeben.")
    files, steps, closures, traces = {}, [], [], {}
    for name, (actuator, sequence) in TRIALS.items():
        path = supplied[name]
        meta, columns, rows = protocol(path, legacy=legacy)
        commands = np.array([[float(r[f"{key}_confirmed_percent"]) for key in INPUTS] for r in rows])
        measured = np.array([[float(r[f"{key}_m3h"]) for key in OUTPUTS] for r in rows])
        stamps = np.array([float(r["elapsed_s"]) for r in rows])
        ages = np.array([[float(r[f"{key}_age_ms"]) for key in OUTPUTS] for r in rows])
        if (not all(np.isfinite(a).all() for a in (commands, measured, stamps, ages))
                or not np.all(np.diff(stamps) > 0) or np.any((ages < 0) | (ages > 1000))):
            raise ValueError(f"{name}: Zeit, Alter, Stellwerte oder Messwerte ungültig.")
        idx = INPUTS.index(actuator)
        delta = np.diff(commands, axis=0)
        changes = np.flatnonzero(np.any(np.abs(delta) > 1e-5, axis=1)) + 1
        if not np.allclose(np.delete(delta, idx, axis=1), 0, atol=1e-5) or (
            list(np.round(commands[np.r_[0, changes], idx], 5)) != list(sequence)
        ):
            raise ValueError(f"{name}: physische Folge weicht vom Versuchsplan ab.")
        initial = np.mean(measured[(stamps >= stamps[changes[0]] - 5) &
                                  (stamps < stamps[changes[0]] - .3)], axis=0)
        files[name] = {"samples": len(rows), "Hz_median": 1 / float(np.median(np.diff(stamps))),
                       "initial_commands": commands[0].tolist(), "initial_means": initial.tolist(),
                       "source": meta.get("normalization")}
        for j, i in enumerate(changes):
            end = changes[j + 1] if j + 1 < len(changes) else len(rows)
            step_time = (stamps[i - 1] + stamps[i]) / 2
            begin = changes[j - 1] if j else 0
            diff = float(delta[i - 1, idx])
            response = {}
            for col, output in enumerate(OUTPUTS):
                t = stamps[begin:end] - ages[begin:end, col] / 1000 - step_time
                y = measured[begin:end, col]
                keep = (t >= -5)
                t, y = t[keep], y[keep]
                if np.count_nonzero(t < -.25) < 4:
                    raise ValueError(f"{name}: unzureichender Vorlauf bei Sprung {j+1}.")
                baseline = float(np.median(y[t < -.25]))
                tail = t >= t[-1] - 5
                traces[name, j + 1, output] = (t, y - baseline)
                response[output] = ({"before": baseline, "after": float(np.median(y[tail]))}
                                    if name.startswith("D") else
                                    _fit(t, y, baseline, diff, tail, output, ages[begin:end, col][keep]))
            row = {"trial": name, "actuator": actuator, "step": j + 1, "delta": diff,
                   "time": float(step_time), "time_bracket": float(stamps[i] - stamps[i-1]),
                   "holdout": j == len(changes) - 1, "responses": response}
            (closures if name.startswith("D") else steps).append(row)
        if legacy:
            normalized.mkdir(parents=True, exist_ok=True)
            with (normalized / path.name).open("x", encoding="utf-8", newline="") as stream:
                stream.write("# metadata " + json.dumps(meta, ensure_ascii=False) + "\n")
                writer = csv.DictWriter(stream, fieldnames=columns, delimiter=";", lineterminator="\n")
                writer.writeheader()
                writer.writerows(rows)

    models = {}
    for point in ("B", "C"):
        candidate = [s for s in steps if s["trial"].startswith(point)]
        source = [f for n, f in files.items() if n.startswith(point)]
        models[point] = {"u0": source[0]["initial_commands"],
                         "y0": np.mean([x["initial_means"] for x in source], axis=0).tolist(),
                         "paths": {}}
        for names in ((a, b) for a in INPUTS for b in OUTPUTS):
            actuator, output = names
            train = [s["responses"][output] for s in candidate
                     if s["actuator"] == actuator and not s["holdout"] and s["responses"][output]["accepted"]]
            key = f"{actuator}->{output}"
            if not train:
                raise ValueError(f"{point} {key}: kein akzeptierter Trainingssprung.")
            fits = [s["responses"][output] for s in candidate
                    if s["actuator"] == actuator and s["responses"][output]["accepted"]]
            estimate = {p: median(f[p] for f in train) for p in ("K", "T", "L")}
            for s in candidate:
                if s["actuator"] == actuator and s["holdout"]:
                    observed = s["responses"][output]
                    observed["holdout_steady_error"] = estimate["K"] * s["delta"] - (
                        observed["after"] - observed["before"])
                    t, y = traces[s["trial"], s["step"], output]
                    predicted = step_response(t, estimate["K"], estimate["T"], estimate["L"], s["delta"])
                    observed["holdout_rmse"] = float(np.sqrt(np.mean((predicted[t >= 0] - y[t >= 0]) ** 2)))
            models[point]["paths"][key] = {
                **estimate, "all_medians": {p: median(f[p] for f in fits) for p in ("K", "T", "L")},
                "observed_range": {p: [min(f[p] for f in fits), max(f[p] for f in fits)] for p in ("K", "T", "L")},
                "fit_count": len(fits), "train_count": len(train),
            }
    return {"files": files, "steps": steps, "closures": closures, "models": models}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--legacy", action="store_true", help="Historische Messkampagne explizit bestätigen")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("csv", type=Path, nargs=8)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    result = analyze_trials(args.csv, args.output / "normalisiert", legacy=args.legacy)
    with (args.output / "identifikation.json").open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
