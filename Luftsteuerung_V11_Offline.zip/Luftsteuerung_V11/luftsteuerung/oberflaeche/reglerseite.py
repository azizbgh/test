"""Reglerseite im vorhandenen hellen Dashboard; alle Widgets im Tk-Hauptthread.

Die Ansicht verwendet ausschließlich Worker-Snapshots und vorhandene Messpakete.
Sie schreibt keine Ausgänge und besitzt weder DAQ-Tasks noch eigene Messzyklen.
"""
from __future__ import annotations

from collections import deque
import math
import time
import tkinter as tk
from tkinter import messagebox

import customtkinter as ctk

from ..kennlinien import ghf_amp_to_m3h, glf_amp_to_m3h
from ..regelung import DEFAULT_FU_FOLLOW, PIDGains, RegulationSettings
from .luftschema import AirflowDiagram, BranchDisplay
from .reglerverlauf import RegulationTrend
from .darstellung import FONT_FAMILY, COLOR_BLUE, COLOR_DARK, COLOR_ORANGE, COLOR_RED, TEXT_MUTED, number_de


class RegulationPageMixin:
    """Widgets und Bedienaktionen der Seite Regelung, ohne Hardwarezugriff."""

    def _reg_text(self, parent, text, role="body", **kwargs):
        return ctk.CTkLabel(parent, text=text, font=self._reg_fonts[role],
                            text_color=kwargs.pop("text_color", COLOR_DARK),
                            height=kwargs.pop("height", 18), **kwargs)

    def _build_regulation_tab(self, tab):
        self.regulation_snapshot = getattr(self.worker, "regulation_snapshot", None)
        self._reg_request_pending = False
        self._reg_stop_pending = False
        self._reg_fault_pending = None
        self._reg_fault_generation = 0
        self._reg_last_evaluation = {}
        self._reg_applied_fu_follow = False
        self._reg_plot_at = 0.0
        self._reg_advanced_open = False
        self._reg_history = {name: deque(maxlen=1600) for name in ("TOTAL", "GHF", "GLF")}
        self._reg_history_last = {}
        self._reg_chart_mode = None
        self._reg_fonts = {
            "title": ctk.CTkFont(family=FONT_FAMILY, size=18, weight="bold"),
            "heading": ctk.CTkFont(family=FONT_FAMILY, size=12, weight="bold"),
            "plot_title": ctk.CTkFont(family=FONT_FAMILY, size=14, weight="bold"),
            "body": ctk.CTkFont(family=FONT_FAMILY, size=12),
            "small": ctk.CTkFont(family=FONT_FAMILY, size=11),
        }
        self._reg_mode = ctk.StringVar(master=self, value="Beide")
        self._reg_variables = {
            "setpoint": ctk.StringVar(master=self, value=""),
            "ghf_min": ctk.StringVar(master=self, value="50"),
            "delay": ctk.StringVar(master=self, value="2"),
        }
        for name, defaults in (("ghf", ("0,9", "0,108", "0,007")),
                               ("glf", ("0,32", "0,075", "0,001"))):
            for suffix, value in zip(("kc", "ti", "td"), defaults):
                self._reg_variables[name + "_" + suffix] = ctk.StringVar(master=self, value=value)
        self._reg_fu_follow = ctk.BooleanVar(master=self, value=DEFAULT_FU_FOLLOW)
        self._reg_editable = []
        tab.grid_columnconfigure(0, weight=1)
        # Wie in der Referenz: kompakter Luftweg oben, größerer Verlauf unten.
        tab.grid_rowconfigure(2, weight=10, uniform="reg_sections", minsize=168)
        tab.grid_rowconfigure(3, weight=12, uniform="reg_sections", minsize=180)
        title = ctk.CTkFrame(tab, fg_color="transparent")
        title.grid(row=0, column=0, sticky="ew", pady=(0, 4))
        title.grid_columnconfigure(0, weight=1)
        self._reg_text(title, "Regelung · Luftwege im Blick", "title", height=28).grid(
            row=0, column=0, sticky="w", padx=3)
        self.regulation_state_label = self._reg_text(
            title, "Bereit", "heading", fg_color="#E1EDF4", corner_radius=5,
            text_color=TEXT_MUTED, width=115, height=28)
        self.regulation_state_label.grid(row=0, column=1, padx=6)
        self.regulation_parameters_button = ctk.CTkButton(
            title, text="Parameter", width=105, height=30, font=self._reg_fonts["body"],
            fg_color="#FFFFFF", border_color="#8799AD", border_width=1,
            text_color=COLOR_DARK, hover_color="#E4EDF6", command=self._show_regulation_parameters)
        self.regulation_parameters_button.grid(row=0, column=2)

        self.regulation_toolbar = self._panel(tab)
        controls = self.regulation_toolbar
        controls.grid(row=1, column=0, sticky="ew", pady=(0, 6))
        controls.grid_columnconfigure(1, weight=1)
        controls.grid_columnconfigure((5, 6), weight=1, uniform="reg_actions")
        self._reg_text(controls, "Betriebsart", "heading").grid(
            row=0, column=0, padx=(8, 3), pady=8)
        modes = ctk.CTkFrame(controls, fg_color="transparent")
        modes.grid(row=0, column=1, sticky="w", padx=(0, 5))
        self.regulation_mode_buttons = {}
        for column, name in enumerate(("Nur GLF", "Nur GHF", "Beide")):
            radio = ctk.CTkRadioButton(
                modes, text=name, variable=self._reg_mode, value=name, width=69,
                radiobutton_width=15, radiobutton_height=15, border_width_checked=4,
                border_width_unchecked=2, font=self._reg_fonts["body"],
                fg_color="#008C83", hover_color="#00766E", text_color=COLOR_DARK,
                command=self._reg_draft_changed)
            radio.grid(row=0, column=column, padx=3)
            self.regulation_mode_buttons[name] = radio
            self._reg_editable.append(radio)
        self._reg_text(controls, "Gesamt-Sollwert", "heading").grid(row=0, column=2, padx=(4, 4))
        spin = ctk.CTkFrame(controls, width=96, height=30, corner_radius=4,
                            fg_color="#FBFCFE", border_width=1, border_color="#8799AD")
        spin.grid(row=0, column=3, padx=2)
        spin.grid_propagate(False)
        spin.grid_columnconfigure(0, weight=1)
        spin.grid_rowconfigure((0, 1), weight=1)
        self.regulation_setpoint_entry = self._reg_entry(spin, "setpoint", width=70, height=28)
        self.regulation_setpoint_entry.configure(border_width=0)
        self.regulation_setpoint_entry.grid(row=0, column=0, rowspan=2, sticky="ew", padx=(2, 0))
        self.regulation_setpoint_arrows = {}
        for row, (text, step) in enumerate((("+", 1), ("-", -1))):
            arrow = ctk.CTkButton(
                spin, text=text, width=20, height=13, corner_radius=2,
                font=self._reg_fonts["heading"], fg_color="#E7EEF5", hover_color="#D2E1ED",
                text_color=COLOR_DARK, command=lambda delta=step: self._step_regulation_setpoint(delta))
            arrow.grid(row=row, column=1, sticky="nsew", padx=(0, 2),
                       pady=(2, 0) if row == 0 else (0, 2))
            self.regulation_setpoint_arrows[step] = arrow
            self._reg_editable.append(arrow)
        self._reg_text(controls, "m³/h").grid(row=0, column=4, padx=(2, 8))
        self.regulation_start_button = ctk.CTkButton(
            controls, text="Regelung starten", width=135, height=32,
            font=self._reg_fonts["heading"], fg_color="#008C83", hover_color="#00766E",
            command=self._start_regulation)
        self.regulation_start_button.grid(row=0, column=5, sticky="ew", padx=(3, 4))
        self.regulation_stop_button = ctk.CTkButton(
            controls, text="Regelung anhalten", width=140, height=32,
            font=self._reg_fonts["heading"], fg_color="#FFFFFF", border_width=1,
            border_color="#8799AD", text_color=COLOR_DARK, hover_color="#E4EDF6",
            state="disabled", command=self._stop_regulation)
        self.regulation_stop_button.grid(row=0, column=6, sticky="ew", padx=(4, 8))

        process = self._panel(tab)
        process.grid(row=2, column=0, sticky="nsew", pady=(0, 6))
        process.grid_columnconfigure(0, weight=1)
        process.grid_rowconfigure(0, weight=1)
        self.regulation_diagram = AirflowDiagram(process)
        self.regulation_diagram.grid(row=0, column=0, sticky="nsew", padx=4, pady=4)

        plots = ctk.CTkFrame(tab, fg_color="transparent")
        plots.grid(row=3, column=0, sticky="nsew")
        plots.grid_columnconfigure(0, weight=57, uniform="reg_plots")
        plots.grid_columnconfigure(1, weight=43, uniform="reg_plots")
        plots.grid_rowconfigure(0, weight=1)
        right = ctk.CTkFrame(plots, fg_color="transparent")
        right.grid(row=0, column=1, sticky="nsew", padx=(4, 0))
        right.grid_columnconfigure(0, weight=1)
        right.grid_rowconfigure((0, 1), weight=1, uniform="reg_branches")
        self.regulation_graphs = {}
        self.regulation_chart_frames = {}
        for name, parent, row, column, caption, color in (
                ("TOTAL", plots, 0, 0, "Gesamt · Soll / Ist", "#008C83"),
                ("GHF", right, 0, 0, "GHF · Durchflussverlauf", "#263F85"),
                ("GLF", right, 1, 0, "GLF · Durchflussverlauf", "#176FD1")):
            card = self._panel(parent)
            card.grid(row=row, column=column, sticky="nsew",
                      padx=(0, 4) if name == "TOTAL" else 0,
                      pady=(0, 3) if name == "GHF" else (3, 0) if name == "GLF" else 0)
            card.grid_columnconfigure(0, weight=1)
            card.grid_rowconfigure(1, weight=1)
            self._reg_text(card, caption, "plot_title", height=23).grid(
                row=0, column=0, sticky="w", padx=8, pady=(2, 0))
            canvas = RegulationTrend(card, color=color)
            canvas.grid(row=1, column=0, sticky="nsew", padx=4, pady=(0, 4))
            canvas.bind("<Configure>", self._mark_graphs_dirty, add="+")
            self.regulation_graphs[name] = canvas
            self.regulation_chart_frames[name] = card
        self.regulation_message_label = self._reg_text(
            tab, "Gesamtsollwert eingeben. Start immer mit Bedienerbestätigung.",
            "small", anchor="w", justify="left", wraplength=940)
        self.regulation_message_label.grid(row=4, column=0, sticky="ew", padx=3, pady=(2, 0))
        self.regulation_warning_label = self._reg_text(
            tab, "", "small", text_color=COLOR_ORANGE, anchor="w", justify="left", wraplength=940)
        self.regulation_warning_label.grid(row=5, column=0, sticky="ew", padx=3)
        self.regulation_warning_label.grid_remove()
        self._build_regulation_parameters()
        for key in ("ghf_min", "delay"):
            self._reg_variables[key].trace_add("write", lambda *_: self._reg_parameter_captions())
        tab.bind("<Configure>", self._regulation_page_size, add="+")
        self._reg_parameter_captions()
        self._refresh_regulation_controls()

    def _build_regulation_parameters(self):
        window = ctk.CTkToplevel(self)
        window.withdraw()
        window.title("Regelungsparameter · Übernahme erst beim Start")
        window.geometry("720x390")
        window.minsize(680, 360)
        window.transient(self)
        window.protocol("WM_DELETE_WINDOW", self._close_regulation_parameters)
        window.configure(fg_color="#F6F9FD")
        window.grid_columnconfigure(0, weight=1)
        window.grid_rowconfigure(5, weight=1)
        self.regulation_parameters_window = window
        self._reg_text(window, "PID-Parameter", "title", height=28).grid(
            row=0, column=0, sticky="w", padx=15, pady=(12, 2))
        self._reg_text(window, "Nur bei angehaltener Regelung editierbar. Änderungen werden erst beim nächsten Start übernommen.",
                       "small", wraplength=650, justify="left").grid(
                           row=1, column=0, sticky="w", padx=15, pady=(0, 8))
        tuning = self._panel(window)
        tuning.grid(row=2, column=0, sticky="ew", padx=14, pady=(0, 6))
        tuning.grid_columnconfigure((1, 2, 3), weight=1, uniform="pid_parameters")
        for column, caption in enumerate(("Zweig", "Kc", "Ti [min]", "Td [min]")):
            self._reg_text(tuning, caption, "heading").grid(
                row=0, column=column, sticky="w", padx=12, pady=(5, 1))
        for row, name in enumerate(("GHF", "GLF"), start=1):
            self._reg_text(tuning, name, "heading").grid(row=row, column=0, sticky="w", padx=12)
            for column, suffix in enumerate(("kc", "ti", "td"), start=1):
                self._reg_entry(tuning, name.lower() + "_" + suffix, width=105, height=29).grid(
                    row=row, column=column, sticky="ew", padx=12, pady=(1, 6))
        self.regulation_advanced_button = ctk.CTkButton(
            window, text="> Erweiterte Versuchsparameter", height=26, anchor="w",
            fg_color="transparent", hover_color="#E4EDF6", text_color=COLOR_ORANGE,
            font=self._reg_fonts["small"], command=self._toggle_regulation_advanced)
        self.regulation_advanced_button.grid(row=3, column=0, sticky="ew", padx=14)
        advanced = self._panel(window)
        advanced.grid_columnconfigure(3, weight=1)
        self.regulation_advanced_panel = advanced
        for row, key, caption, note in ((0, "ghf_min", "GHF-Minimum [m³/h]", "UNBESTÄTIGT"),
                                       (1, "delay", "Fehlerverzögerung [s]", "VORLÄUFIG")):
            self._reg_text(advanced, caption, "small").grid(row=row, column=0, sticky="w", padx=(10, 5), pady=3)
            self._reg_entry(advanced, key, width=75, height=27).grid(row=row, column=1, padx=5, pady=3)
            self._reg_text(advanced, note, "small", text_color=COLOR_ORANGE).grid(row=row, column=2, sticky="w", padx=5)
        self.regulation_fu_switch = ctk.CTkSwitch(
            advanced, text="FU-Nachführung", variable=self._reg_fu_follow,
            font=self._reg_fonts["small"], command=self._reg_draft_changed)
        self.regulation_fu_switch.grid(row=0, column=3, rowspan=2, sticky="e", padx=12)
        self._reg_editable.append(self.regulation_fu_switch)
        self.regulation_parameter_note = self._reg_text(
            advanced, "", "small", text_color=COLOR_ORANGE, wraplength=640, justify="left")
        self.regulation_parameter_note.grid(row=2, column=0, columnspan=4, sticky="w", padx=10, pady=(0, 5))
        self.regulation_parameters_close_button = ctk.CTkButton(
            window, text="Schließen", width=120, height=30, font=self._reg_fonts["body"],
            fg_color="#FFFFFF", border_width=1, border_color="#8799AD", text_color=COLOR_DARK,
            hover_color="#E4EDF6", command=self._close_regulation_parameters)
        self.regulation_parameters_close_button.grid(row=6, column=0, sticky="e", padx=14, pady=10)

    def _show_regulation_parameters(self):
        if self.closing or self.shutdown_blocked:
            return
        self.regulation_parameters_window.deiconify()
        self.regulation_parameters_window.lift()
        self.regulation_parameters_window.focus_set()
        self._refresh_regulation_controls()

    def _close_regulation_parameters(self):
        self.regulation_parameters_window.withdraw()

    def _step_regulation_setpoint(self, delta):
        if self.regulation_setpoint_entry.cget("state") != "normal":
            return
        raw = self._reg_variables["setpoint"].get().strip()
        try:
            value = float(raw.replace(",", ".")) if raw else 0.0
        except ValueError:
            return
        if math.isfinite(value):
            # Nur den Entwurf ändern. Die echte Modus-/Bereichsprüfung bleibt
            # in RegulationSettings.validate(), ohne Ausgabe durch die Pfeile.
            value = max(0.0, value + delta)
            self._reg_variables["setpoint"].set(number_de(value, 0 if value.is_integer() else 2))

    def _regulation_page_size(self, event=None):
        if event is not None and event.widget is not self.pages["Regelung"]:
            return
        width = int(self.geometry().split("x", 1)[0])
        for label in (self.regulation_message_label, self.regulation_warning_label):
            self._configure_if_changed(label, wraplength=max(650, width - 40))

    def _reg_entry(self, parent, key, *, width=90, height=30):
        entry = ctk.CTkEntry(parent, textvariable=self._reg_variables[key], width=width,
                             height=height, font=self._reg_fonts["body"], fg_color="#FBFCFE",
                             text_color=COLOR_DARK, border_color="#8D9DB0")
        self._reg_editable.append(entry)
        return entry

    def _reg_draft_changed(self):
        self._reg_parameter_captions()
        self._refresh_regulation_controls()
        self._render_regulation_measurement()

    def _toggle_regulation_advanced(self):
        self._reg_advanced_open = not self._reg_advanced_open
        if self._reg_advanced_open:
            self.regulation_advanced_panel.grid(row=4, column=0, sticky="ew", padx=14, pady=(2, 4))
        else:
            self.regulation_advanced_panel.grid_remove()
        self._reg_parameter_captions()

    def _reg_parameter_summary(self):
        def draft(key):
            raw = self._reg_variables[key].get().strip()
            try:
                value = float(raw.replace(",", "."))
                return number_de(value) if math.isfinite(value) else "ungültig"
            except ValueError:
                return "ungültig"
        return (f"GHF-Minimum {draft('ghf_min')} m³/h UNBESTÄTIGT · "
                f"Verzögerung {draft('delay')} s VORLÄUFIG")

    def _reg_parameter_captions(self):
        summary = self._reg_parameter_summary()
        prefix = "v" if self._reg_advanced_open else ">"
        self._configure_if_changed(self.regulation_advanced_button,
                                   text=prefix + " Erweiterte Versuchsparameter")
        self._configure_if_changed(self.regulation_parameter_note,
            text=summary)
        warning = getattr(self.regulation_snapshot, "warning", "")
        if warning:
            if getattr(self.regulation_snapshot, "status", "idle") != "running":
                warning = "Letzte Regelbewertung: " + warning
        self._configure_if_changed(self.regulation_warning_label, text=warning)
        if warning:
            self.regulation_warning_label.grid()
        else:
            self.regulation_warning_label.grid_remove()

    def _reg_settings(self):
        def value(key, label):
            try:
                result = float(self._reg_variables[key].get().strip().replace(",", "."))
            except ValueError as exc:
                raise ValueError(label + ": Bitte eine gültige Zahl eingeben.") from exc
            if not math.isfinite(result):
                raise ValueError(label + ": Zahl muss endlich sein.")
            return result
        def gains(name):
            return PIDGains(value(name + "_kc", name.upper() + " Kc"),
                            value(name + "_ti", name.upper() + " Ti [min]"),
                            value(name + "_td", name.upper() + " Td [min]"))
        settings = RegulationSettings(
            mode={"Nur GLF": "GLF", "Nur GHF": "GHF", "Beide": "BEIDE"}[self._reg_mode.get()],
            setpoint_m3h=value("setpoint", "Gesamtsollwert [m³/h]"),
            ghf_min_m3h=value("ghf_min", "GHF-Minimum [m³/h]"),
            deviation_delay_s=value("delay", "Fehlerverzögerung [s]"),
            ghf_gains=gains("ghf"), glf_gains=gains("glf"),
            fu_follow=bool(self._reg_fu_follow.get()))
        settings.validate()
        return settings

    def _start_regulation(self):
        if (self.confirming or self.output_busy or self.closing or self.shutdown_blocked
                or self._reg_request_pending or self._reg_stop_pending
                or getattr(self.regulation_snapshot, "status", "idle") == "running"):
            return
        try:
            settings = self._reg_settings()
        except (ValueError, TypeError) as exc:
            self._reg_start_error("Regelungsparameter ungültig", exc)
            return
        fu_command = self.command_labels["FU"].cget("text")
        details = (f"Modus: {self._reg_mode.get()}\nGesamtsollwert: {number_de(settings.setpoint_m3h)} m³/h\n"
                   f"GHF-Minimum: {number_de(settings.ghf_min_m3h)} m³/h (UNBESTÄTIGT)\n"
                   f"Fehlerverzögerung: {number_de(settings.deviation_delay_s)} s (VORLÄUFIG)\n\n")
        if settings.fu_follow:
            details += "FU-Nachführung EIN: Der Regler darf den FU-Sollwert schrittweise verändern.\n"
        else:
            details += f"FU-Nachführung AUS: FU bleibt auf letztem bestätigtem Befehl ({fu_command}).\n"
        details += "Befehlswerte sind keine Rückmessung der Ausgangsströme.\n\n"
        if self.simulate:
            details += ("Nur Simulation, keine NI-Ausgänge. Simulierte Sensorwerte reagieren nicht auf Stellbefehle "
                        "und sind kein Anlagenmodell.\n\n")
        else:
            details += ("Reale Regelung kann GLF/GHF und bei FU-Nachführung den FU verändern.\n"
                        "Die Startinitialisierung der Anwendung setzt FU 0 %, GLF/GHF 100 % auf jeweils 4 mA.\n"
                        "Nur bei freigegebener Anlage und unabhängiger Abschaltmöglichkeit starten.\n\n")
        details += "Stopp und Regelfehler halten die letzten Befehle (HOLD); sie garantieren keinen sicheren Anlagenzustand. Starten?"
        fault_generation = self._reg_fault_generation
        self.confirming = True
        dialog_error = None
        confirmed = False
        try:
            self._refresh_controls()
            confirmed = messagebox.askyesno("Regelung ausdrücklich starten", details, parent=self)
        except Exception as exc:
            dialog_error = exc
        finally:
            self.confirming = False
            self._refresh_controls()
        if dialog_error is not None:
            self._reg_start_error("Startbestätigung fehlgeschlagen", dialog_error)
            return
        # Ein verschachtelter Tk-Dialog kann währenddessen neue Workerereignisse liefern.
        if (confirmed and not self.closing and not self.shutdown_blocked
                and not self.output_busy and not self._reg_stop_pending
                and self._reg_fault_generation == fault_generation
                and getattr(self.regulation_snapshot, "status", "idle") != "running"):
            try:
                self._reg_request_pending = bool(self.worker.request_start_regulation(settings))
            except (ValueError, TypeError, RuntimeError) as exc:
                self._reg_request_pending = False
                self._reg_start_error("Regelungsstart abgelehnt", exc)
                return
            if self._reg_request_pending:
                self._reg_applied_fu_follow = settings.fu_follow
            self.regulation_message_label.configure(
                text="Regelungsstart angefordert · noch nicht bestätigt" if self._reg_request_pending
                     else "Start nicht angenommen · Ursache prüfen und erneut ausdrücklich starten",
                text_color=COLOR_ORANGE)
        else:
            self.regulation_message_label.configure(text="Start abgebrochen · Zustand geändert oder nicht bestätigt", text_color=TEXT_MUTED)
        self._refresh_controls()

    def _reg_start_error(self, title, error):
        self.regulation_message_label.configure(text=str(error), text_color=COLOR_RED)
        self._refresh_controls()
        self._show_error_details(title, str(error))

    def _stop_regulation(self):
        if self.confirming or self.closing or self.shutdown_blocked or self._reg_stop_pending:
            return
        self._reg_stop_pending = True
        self.worker.request_stop_regulation()
        self.regulation_message_label.configure(
            text="Stopp angefordert · zuletzt bestätigte Befehle bleiben unverändert", text_color=COLOR_ORANGE)
        self._refresh_controls()

    def _refresh_regulation_controls(self):
        if not hasattr(self, "regulation_start_button"):
            return
        running = getattr(self.regulation_snapshot, "status", "idle") == "running"
        editing = not (running or self.confirming or self.output_busy or self.closing
                       or self.shutdown_blocked or self._reg_request_pending or self._reg_stop_pending)
        for widget in self._reg_editable:
            self._configure_if_changed(widget, state="normal" if editing else "disabled")
        can_start = editing and self.worker.allow_automation
        self._configure_if_changed(self.regulation_start_button,
            state="normal" if can_start else "disabled",
            text="Regelung starten" if self.worker.allow_automation else "Automatik nur offline (V11)",
            fg_color="#008C83" if can_start else "#DCE5EB",
            text_color="#FFFFFF", text_color_disabled=TEXT_MUTED)
        can_stop = (running or self._reg_request_pending) and not (
            self.confirming or self.closing or self.shutdown_blocked or self._reg_stop_pending)
        self._configure_if_changed(self.regulation_stop_button, state="normal" if can_stop else "disabled")
        # Fault-Dialog einmal pro Fehlerübergang, niemals pro Messpaket. OK ist
        # ausschließlich Quittierung und löst keinen Regelungsstart aus.
        if self._reg_fault_pending and not self.confirming and not self.closing:
            detail = self._reg_fault_pending
            self._reg_fault_pending = None
            self._show_error_details("Regelung angehalten · HOLD", detail)

    def _on_regulation_event(self, snapshot):
        previous = getattr(self.regulation_snapshot, "status", "idle")
        self.regulation_snapshot = snapshot
        self._reg_request_pending = False
        self._reg_stop_pending = False
        labels = {"running": "Regelung aktiv", "fault": "Regelungsfehler",
                  "stopped": "Angehalten · HOLD", "idle": "Bereit"}
        color = COLOR_RED if snapshot.status == "fault" else COLOR_BLUE if snapshot.status == "running" else TEXT_MUTED
        self._configure_if_changed(self.regulation_state_label,
                                   text=labels.get(snapshot.status, "Status unbekannt"), text_color=color,
                                   fg_color="#FBE5E5" if snapshot.status == "fault" else "#E1EDF4")
        self._configure_if_changed(self.regulation_message_label,
            text="Gesamtsollwert eingeben." if snapshot.status == "idle" else snapshot.message,
            text_color=color)
        self._reg_parameter_captions()
        # Alter aus den zugrunde liegenden Messpaketen ableiten. Ein HOLD-
        # Snapshot darf den Zeitstempel der letzten Auswertung nicht erneuern.
        active = {name for name, target in snapshot.branch_setpoints.items()
                  if target > 0 and name in self.sensor_readings}
        stamps = [self.sensor_readings[name].received_at for name in active
                  if self.sensor_readings[name].received_at]
        stamp = min(stamps) if stamps else time.monotonic()
        for key, field in (("total", "measured_total_m3h"), ("error", "error_m3h")):
            value = getattr(snapshot, field, None)
            if value is not None and math.isfinite(value):
                previous_value = self._reg_last_evaluation.get(key, (None, 0.0))[0]
                if snapshot.status == "running" or value != previous_value:
                    self._reg_last_evaluation[key] = (value, stamp)
        if snapshot.status == "fault" and previous != "fault":
            self._reg_fault_generation += 1
            if not getattr(self, "_reg_sensor_fault_already_reported", False):
                self._reg_fault_pending = snapshot.message + ("\n\n" + snapshot.warning if snapshot.warning else "")
        self._render_regulation_measurement()
        self._refresh_controls()

    def _render_regulation_measurement(self):
        if not hasattr(self, "regulation_diagram"):
            return
        now = time.monotonic()
        snapshot = self.regulation_snapshot
        status = getattr(snapshot, "status", "idle")
        running = status == "running"
        mode = (snapshot.mode if running else
                {"Nur GLF": "GLF", "Nur GHF": "GHF", "Beide": "BEIDE"}[self._reg_mode.get()])
        selected = {"GHF", "GLF"} if mode == "BEIDE" else {mode}
        active = ({name for name, target in snapshot.branch_setpoints.items() if target > 0}
                  if running else selected)
        fresh, flows, stamps, display_readings = {}, {}, {}, {}
        unchecked = []
        for name, convert in (("GHF", ghf_amp_to_m3h), ("GLF", glf_amp_to_m3h)):
            reading = self.sensor_readings[name]
            valid = (reading.valid and reading.recent(now) and not self.measurement_error
                     and not self.closing and not self.shutdown_blocked)
            fresh[name] = valid
            finite = reading.current_a is not None and math.isfinite(reading.current_a)
            # Auch unplausible endliche Werte bleiben als ungeprüfte Rechenwerte
            # sichtbar. Fehlt ein endlicher Eingang, den letzten Wert markieren.
            shown = reading if finite else getattr(self, "_last_display_readings", {}).get(name)
            value = None
            if shown is not None and shown.current_a is not None:
                value = convert(shown.current_a)
                if not math.isfinite(value):
                    value = None
            flows[name] = value
            stamp = shown.received_at if shown is not None else 0.0
            stamps[name] = stamp
            age = max(0, round((now - stamp) * 1000)) if stamp else None
            cached = shown is not None and (shown is not reading or not reading.recent(now)
                                           or self.measurement_error)
            color = COLOR_DARK if valid else COLOR_RED if self.measurement_error or (
                reading.received_at and not reading.valid) else COLOR_ORANGE
            marker = "Alt · " if cached else "Ungeprüft · " if not valid else ""
            age_text = marker + (f"{age} ms" if age is not None else "—")
            if not valid:
                unchecked.append(name + (": letzter Wert" if cached else ": ungeprüfter Rechenwert"))
            raw = shown.current_a if shown is not None else None
            current_text = (number_de(raw * 1000, 3 if valid else 6) + " mA"
                            if raw is not None and math.isfinite(raw) else "— mA")
            branch_target = (getattr(snapshot, "branch_setpoints", {}).get(name)
                             if status != "idle" else None)
            display_readings[name] = BranchDisplay(
                target=number_de(branch_target) + " m³/h" if branch_target is not None else "— m³/h",
                actual=number_de(value) + " m³/h" if value is not None else "— m³/h",
                current=current_text, age=age_text, color=color)

        # Während der Regelung bleibt ausschließlich der vom Kern qualifizierte
        # Regel-Istwert maßgeblich. Im Vorlauf die gewählten Sensoren anzeigen,
        # ohne einen eingegebenen Sollwert als aktive Referenz zu übernehmen.
        known_total = (sum(flows[name] for name in selected)
                       if all(flows[name] is not None for name in selected) else None)
        live = (all(fresh.get(name, False) for name in active) and bool(active)
                and not self.closing and not self.shutdown_blocked)
        held = status in ("fault", "stopped")
        total, error, total_stamp = None, None, 0.0
        if status == "idle" or snapshot is None:
            total = known_total
            total_stamp = min((stamps[name] for name in selected), default=0.0)
        else:
            for key, field in (("total", "measured_total_m3h"), ("error", "error_m3h")):
                current = getattr(snapshot, field, None)
                stored, stamp = self._reg_last_evaluation.get(key, (None, 0.0))
                value = current if current is not None and math.isfinite(current) else (
                    None if running and live else stored)
                if key == "total":
                    total, total_stamp = value, stamp
                else:
                    error = value
        setpoint = getattr(snapshot, "setpoint_m3h", None)
        total_color = COLOR_DARK if live and not held else COLOR_RED if status == "fault" else COLOR_ORANGE
        age = max(0, round((now - total_stamp) * 1000)) if total_stamp else None
        if held:
            caption = "HOLD · Daten bei Stopp/Fehler" + (f" · Alter {age} ms" if age is not None else "")
        elif running:
            caption = ("Regel-Istwert der aktiven Zweige" if live else "Letzte Auswertung · ungeprüft")
            if error is None:
                caption += " · Gesamtabweichung nicht qualifiziert"
        else:
            caption = ("GHF für die Grundlast · GLF für die Feinregelung" if mode == "BEIDE"
                       else "GLF als einzelner Regelzweig" if mode == "GLF"
                       else "GHF als einzelner Regelzweig")
        if unchecked:
            caption += " · " + "; ".join(unchecked)
        fu = getattr(snapshot, "outputs_percent", {}).get("FU")
        command = number_de(fu) + " %" if fu is not None else self.command_labels["FU"].cget("text")
        fu_mode = "FU-Nachführung" if running and self._reg_applied_fu_follow else "FU fest"
        if held:
            fu_mode = "FU HOLD"
        display = dict(
            mode=mode, active_branches=active, readings=display_readings,
            fu_text="Befehl: " + command + " · " + fu_mode,
            actual=number_de(total) + " m³/h" if total is not None else "— m³/h",
            target=number_de(setpoint) + " m³/h" if setpoint is not None else "— m³/h",
            error=number_de(error) + " m³/h" if error is not None else "— m³/h",
            caption=caption, total_color=total_color)
        self.regulation_diagram.update_display(**display)
        self._reg_record_trends(now, mode, selected, fresh, flows, snapshot, known_total)
        if getattr(self, "_graphs_dirty", False) or now - self._reg_plot_at >= .2:
            self._reg_plot_at = now
            for name, canvas in self.regulation_graphs.items():
                if canvas.winfo_ismapped():
                    canvas.draw(self._reg_history[name], now, live=(
                        all(fresh[n] for n in selected) if name == "TOTAL" else fresh[name]))

    def _reg_record_trends(self, now, mode, selected, fresh, flows, snapshot, raw_total):
        """Vorhandene Messpakete um Darstellungsreferenzen ergänzen, nie lesen."""
        if mode != self._reg_chart_mode:
            # Der Gesamtverlauf bezieht sich auf die aktuelle Auswahl. Die
            # Einzelmessungen bleiben beim Wechsel der Betriebsart vergleichbar.
            self._reg_history["TOTAL"].clear()
            self._reg_history_last.pop("TOTAL", None)
            self._reg_chart_mode = mode
        running = getattr(snapshot, "status", "idle") == "running"
        for name in ("GHF", "GLF"):
            reading = self.sensor_readings[name]
            key = (reading.received_at, fresh[name])
            if self._reg_history_last.get(name) != key:
                self._reg_history_last[name] = key
                target = snapshot.branch_setpoints.get(name) if running else None
                self._reg_history[name].append((reading.received_at or now,
                                               flows[name] if fresh[name] else None, target))
        sample_times = tuple(self.sensor_readings[n].received_at for n in sorted(selected))
        all_fresh = all(fresh[n] for n in selected)
        key = (sample_times, all_fresh, running, getattr(snapshot, "error_m3h", None) is not None)
        if self._reg_history_last.get("TOTAL") != key:
            self._reg_history_last["TOTAL"] = key
            if running:
                # None bedeutet, dass der Kern keine qualifizierte Summe
                # ausweist. Den GLF-Teilwert dann nicht als Gesamtlinie zeichnen.
                value = snapshot.measured_total_m3h if snapshot.error_m3h is not None else None
                active = {n for n, target in snapshot.branch_setpoints.items() if target > 0}
                if not active or not all(fresh.get(n, False) for n in active):
                    value = None
                target = snapshot.setpoint_m3h
            else:
                value = raw_total if all_fresh else None
                target = None  # Sollwertentwurf ist keine aktive Sollkurve.
            stamp = max(sample_times, default=0.0) or now
            self._reg_history["TOTAL"].append((stamp, value, target))
        for history in self._reg_history.values():
            while history and history[0][0] < now - 60:
                history.popleft()
