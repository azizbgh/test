# Nassheuer-Luftsteuerung mit Regelungsseite

V11 ergänzt eine Daten- und Reglerprüfung für den Offline-Betrieb. Einzelheiten
und die reproduzierbaren Befehle stehen in [V11_Bericht.md](V11_Bericht.md).
Im Hardwaremodus steht die manuelle Kanalprüfung zur Verfügung. Der
Automatikstart ist in dieser Version auf den Simulationsmodus begrenzt.

Das Programm bleibt modular. Die ZIP vollständig entpacken und die Ordner
zusammenlassen; `main.py` ist der Programmeinstieg.

```text
python -m pip install -r requirements.txt
python main.py --simulate
```

Der Simulationsstart öffnet keine NI-Hardware. Die Beispielsensoren sind kein
Anlagenmodell. Die Regelungsseite zeigt das Luftschema für FU, GHF und GLF
sowie den Gesamtverlauf und die beiden Zweigverläufe. Über **Parameter**
öffnest du die PID-Werte und Versuchseinstellungen. Stopp und Regelfehler
halten die letzten Stellbefehle.

Hardwarebetrieb nach betrieblicher Freigabe:

```text
python -m pip install -r requirements-hardware.txt
python main.py --hardware
```

Dieser Start fordert bereits dreimal 4 mA an. Der passende NI-DAQmx-Treiber
muss auf dem Rechner vorhanden sein. Beim bestätigten Reglerstart ist die
FU-Nachführung standardmäßig aktiv. Für Versuche mit festem FU lässt sie sich
unter **Parameter → Erweitert** ausschalten.

Bedienung, offene Versuchsparameter, Protokolle und Prüfschritte:
[README_Regelung.md](README_Regelung.md).

Softwareprüfungen: `python -m unittest discover -s tests -v`.
GUI-Prüfungen benötigen zusätzlich eine verfügbare grafische Anzeige.
