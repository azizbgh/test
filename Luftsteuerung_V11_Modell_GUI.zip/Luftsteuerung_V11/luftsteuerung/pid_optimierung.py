"""Reproduzierbarer A/B-Vergleich. Diese Reglerkandidaten sprechen keine Hardware an."""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass, replace
from itertools import product
import json
from pathlib import Path
import random

from .anlagenmodell import LocalPlant, OPERATING_BOUNDS, clamp
from .identifikation import INPUTS, OUTPUTS
from .konfiguration import GHF_SENSOR_FACTOR, GLF_SENSOR_FACTOR, SENSOR_ZERO_A
from .messwerte import evaluate_sensor_currents
from .regelung import GLF_RELIABLE_MIN_M3H, PIDGains, RegulationController, RegulationSettings


@dataclass(frozen=True)
class Parameters:
    kp: float
    ti: float
    feedforward: float
    split_gain: float


class PrimaryFlowPI:
    """FU für die Summe, gegensinnige Schieberkorrektur bei festem Mittelwert."""

    def __init__(self, parameters, model, bounds, initial, initial_flow, settings):
        self.p = parameters
        self.settings = settings
        self.bounds = bounds
        self.initial = initial
        self.outputs = initial
        self.integral = 0.
        self.status = "running"
        self.reason = ""
        self.outside_since = self.low_glf_since = None
        self.share = model["y0"][1] / sum(model["y0"])
        self.fu_gain = sum(model["paths"][f"FU->{sensor}"]["K"] for sensor in OUTPUTS)
        # Bei einem GUI-Start bildet das erste qualifizierte Messpaket
        # den Bezugspunkt. Offline-Szenarien kennen den Anfangsfluss bereits.
        self.feedforward = None if initial_flow is None else self._feedforward(initial_flow)
        (_, (glo, ghi), (llo, lhi)) = bounds
        self.trim_bounds = (max(glo - initial[1], initial[2] - lhi),
                            min(ghi - initial[1], initial[2] - llo))

    def _feedforward(self, flow):
        return self.initial[0] + self.p.feedforward * (
            self.settings.setpoint_m3h - flow) / self.fu_gain

    def fault(self, reason):
        self.status, self.reason = "fault", reason
        return self.outputs

    def step(self, y, readings, elapsed, dt):
        if self.status != "running":
            return self.outputs
        cfg = self.settings
        if any(not readings[s].valid or not 0 <= elapsed - readings[s].received_at <= cfg.max_measurement_age_s
               for s in OUTPUTS):
            return self.fault("Messung ungültig oder veraltet")
        if y[1] < cfg.glf_missing_threshold_m3h:
            self.low_glf_since = elapsed if self.low_glf_since is None else self.low_glf_since
            if elapsed - self.low_glf_since >= cfg.glf_missing_delay_s:
                return self.fault("GLF unter Mindestdurchfluss")
        else:
            self.low_glf_since = None
        error = cfg.setpoint_m3h - sum(y)
        reliable = y[0] >= cfg.ghf_min_m3h and y[1] >= GLF_RELIABLE_MIN_M3H
        if elapsed >= cfg.settling_time_s and (not reliable or abs(error) > cfg.tolerance_m3h):
            self.outside_since = elapsed if self.outside_since is None else self.outside_since
            if elapsed - self.outside_since >= cfg.deviation_delay_s:
                return self.fault("Regelziel oder Messbereich anhaltend verfehlt")
        else:
            self.outside_since = None
        if not reliable:
            return self.outputs
        if self.feedforward is None:
            self.feedforward = self._feedforward(sum(y))

        proportional = self.p.kp * error
        inc = proportional * dt / self.p.ti
        candidate = self.feedforward + proportional + self.integral + inc
        lo, hi = self.bounds[0]
        if not (candidate > hi and inc > 0 or candidate < lo and inc < 0):
            self.integral += inc
        requested = clamp(self.feedforward + proportional + self.integral, (lo, hi))
        rate = cfg.fu_rate_percent_s * dt
        fu = clamp(self.outputs[0] + clamp(requested - self.outputs[0], (-rate, rate)), (lo, hi))
        split_error = y[1] - self.share * sum(y)
        trim = clamp(self.p.split_gain * split_error, self.trim_bounds)
        old_trim = self.outputs[1] - self.initial[1]
        trim = clamp(trim, (old_trim - rate, old_trim + rate))
        self.outputs = (fu, clamp(self.initial[1] + trim, self.bounds[1]),
                        clamp(self.initial[2] - trim, self.bounds[2]))
        return self.outputs


def scenarios(models):
    result = []
    for point, model in models.items():
        u0 = model["u0"]
        target = sum(model["y0"])
        result.append((point, "Anstieg", tuple(u0), target + 10))
        preloaded = (u0[0] + 4, *u0[1:])
        result.append((point, "Absenken", preloaded, target + 3))
    return result


def simulate(models, scenario, parameters=None, *, variant="train", noise=0., invalid_at=None,
             a_scale=(1., 1., 1.)):
    point, name, initial, target = scenario
    dt = .1
    model = models[point]
    plant = LocalPlant(point, model, dt, initial, variant)
    initial_total = sum(plant.measure())
    cfg = RegulationSettings("BEIDE", target)
    if parameters is None:
        kc_scale, ti_scale, td_scale = a_scale
        def scaled(gains):
            return PIDGains(gains.kc * kc_scale, gains.ti_minutes * ti_scale,
                            gains.td_minutes * td_scale)
        cfg = replace(cfg, ghf_gains=scaled(cfg.ghf_gains), glf_gains=scaled(cfg.glf_gains))
        controller = RegulationController()
        controller.start(cfg, dict(zip(INPUTS, initial)), 0)
    else:
        controller = PrimaryFlowPI(parameters, model, plant.bounds, initial, initial_total, cfg)
    state = initial
    actual, movements, clipped, first_fault = [], [0., 0., 0.], 0, None
    jitter = random.Random(59)
    for tick in range(601):
        t = tick * dt
        y = plant.measure()
        actual.append(sum(y))
        measured = tuple(value + noise * jitter.gauss(0, 1) for value in y)
        readings = evaluate_sensor_currents((
            SENSOR_ZERO_A + GHF_SENSOR_FACTOR * measured[0],
            None if invalid_at is not None and t >= invalid_at
            else SENSOR_ZERO_A + GLF_SENSOR_FACTOR * measured[1],
        ), t)
        if parameters is None:
            desired = controller.step(readings, t)
            proposed = tuple(desired[c] for c in INPUTS) if desired else state
            command = tuple(clamp(u, bounds) for u, bounds in zip(proposed, plant.bounds))
            clipped += int(proposed != command)
            if desired:
                controller.acknowledge(dict(zip(INPUTS, command)))
            status = controller.snapshot().status
        else:
            command = controller.step(measured, readings, t, dt)
            status = controller.status
        if tick and first_fault is None and status == "fault":
            first_fault = t
        for i, (before, after) in enumerate(zip(state, command)):
            movements[i] += abs(before - after)
        plant.advance(command)
        state = command

    error = [y - target for y in actual]
    misses = [i for i, e in enumerate(error) if abs(e) > cfg.tolerance_m3h]
    settled = (misses[-1] + 1) * dt if misses else 0.
    return {
        "point": point, "scenario": name, "variant": variant, "noise_sigma_m3h": noise,
        "settled_s": settled if settled <= 60 else None,
        "in_band_30_to_60": all(abs(e) <= cfg.tolerance_m3h for e in error[300:]),
        "fault_s": first_fault,
        "overshoot_m3h": max(0., max(error) if target >= initial_total else -min(error)),
        "undershoot_after_first_entry_m3h": max(
            [0.] + [-(e if target >= initial_total else -e)
                     for e in error[next((i for i,e in enumerate(error) if abs(e) <= cfg.tolerance_m3h), len(error)):]]),
        "iae_m3h_s": dt * sum(abs(e) for e in error),
        "travel_percent": dict(zip(INPUTS, movements)),
        "local_clip_samples": clipped,
        "end_commands": dict(zip(INPUTS, state)),
        "end_flow": actual[-1],
    }


def score(results):
    return sum(700 * (not r["in_band_30_to_60"] or r["fault_s"] is not None)
               + r["iae_m3h_s"] + 15 * r["overshoot_m3h"]
               + .5 * sum(r["travel_percent"].values()) for r in results)


def compare(models):
    cases = scenarios(models)
    candidates = [Parameters(*values) for values in
                  product((.05, .12, .22), (4., 8., 14.), (0., .7, 1.), (0., .25))]
    ranked = sorted(((score([simulate(models, case, p) for case in cases]), p)
                     for p in candidates), key=lambda row: row[0])
    selected = ranked[0][1]
    best_no_feedforward = next(p for _, p in ranked if p.feedforward == 0)
    a_candidates = list(product((.5, 1., 1.5), (.7, 1., 1.5), (0., 1.)))
    a_selected = min(a_candidates,
                     key=lambda s: score([simulate(models, case, a_scale=s) for case in cases]))
    evaluate = [(case, variant, noise) for case in cases
                for variant, noise in (("train", 0.), ("slow", .2), ("strong", .2))]
    return {"selected": asdict(selected), "candidates": len(candidates),
            "no_feedforward_best": asdict(best_no_feedforward),
            "A_selected_gain_scaling_Kc_Ti_Td": a_selected,
            "A_candidates": len(a_candidates),
            "training_top": [{"score": cost, "parameters": asdict(p)} for cost, p in ranked[:5]],
            "A": [simulate(models, case, variant=v, noise=n) for case, v, n in evaluate],
            "A_tuned": [simulate(models, case, variant=v, noise=n, a_scale=a_selected)
                        for case, v, n in evaluate],
            "B": [simulate(models, case, selected, variant=v, noise=n) for case, v, n in evaluate],
            "B_no_feedforward": [simulate(models, case, best_no_feedforward, variant=v, noise=n)
                                 for case, v, n in evaluate],
            "loss_GLF_at_12s": {
                "A": simulate(models, cases[0], invalid_at=12),
                "B": simulate(models, cases[0], selected, invalid_at=12),
            }}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("identification", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    models = json.loads(args.identification.read_text(encoding="utf-8"))["models"]
    result = compare(models)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
