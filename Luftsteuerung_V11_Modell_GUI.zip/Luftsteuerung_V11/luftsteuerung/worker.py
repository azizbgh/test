"""Hintergrundthread für Messung, Stellaufträge und Ressourcenfreigabe.

Die Oberfläche muss auf Klicks reagieren können, während der NI-Treiber wartet.
Dafür übernimmt DaqWorker die Treiberaufrufe in einem eigenen Thread. Zwei
Queues funktionieren wie getrennte Postfächer: commands enthält Aufträge der
Oberfläche, events enthält Antworten des Workers. Widgets werden nicht übergeben.

Manuelle und automatische Aufträge teilen denselben Besitzerthread. Stop und
Regelfehler halten die letzten bestätigten Befehle. run() fordert beim Start
für FU, GLF und GHF jeweils 4 mA an; beim bestätigten Programmabschluss werden
ebenfalls 4 mA angefordert. Die Simulation verwendet keine NI-Ausgänge.
"""

from __future__ import annotations

import queue
import threading
import time
import math

from .konfiguration import (
    AI_GHF,
    AI_GLF,
    GUI_REFRESH_MS,
    MAX_MEASUREMENT_AGE_S,
    SENSOR_CHANNELS,
)
from .kennlinien import (
    CONFIGURED_ACTUATOR_CURVES,
    validate_current,
    validate_percent,
    fu_amp_to_percent,
)
from .hardware import DaqController, SimulatedDaqController
from .messwerte import DaqState, SensorReading, evaluate_sensor_currents
from .regelung import RegulationController, RegulationSettings
from .protokoll import SessionLog


# Führt Messung und Ausgaben außerhalb des GUI-Threads aus.
class DaqWorker(threading.Thread):
    """Einziger Besitzer der DAQ-Tasks; GUI erhält nur unveränderliche Ereignisse.

    Schließanforderungen sperren neue Writes sofort. Ein bereits laufender
    Treiberaufruf ist nicht abbrechbar; die GUI wartet auf dessen Abschluss.
    """

    # Erstellt die Queues und Zustandsvariablen für den Worker.
    def __init__(self, controller: DaqController, *, log_directory=None,
                 allow_automation: bool = True) -> None:
        super().__init__(name="Luftsteuerung-DAQ", daemon=False)
        self.controller = controller
        self.allow_automation = allow_automation
        self.model_controller = (controller if isinstance(controller, SimulatedDaqController)
                                 and hasattr(controller, "offline_regulator") else None)
        if self.model_controller is not None and not allow_automation:
            raise ValueError("Eine Modellsimulation benötigt den Simulationsbetrieb.")
        # Ereignisformat jeweils (Art, Nutzdaten), Richtung Worker -> Tk:
        # measurement: (dict[str, SensorReading], monotone_Lesezeit)
        # Jede SensorReading enthält ihren eigenen Rohwert und Fehlerstatus.
        self.events: queue.Queue = queue.Queue()
        # Befehle Tk -> Worker: „write“, „restart_measurement“ oder „close“.
        # Keine Widgets in Nutzdaten ablegen.
        self.commands: queue.Queue = queue.Queue()
        # Sofortige Sperrabsicht mit Vorrang vor der Queue-Position des close-Befehls.
        self.close_requested = threading.Event()
        self.last_valid_at = 0.0
        self.measurement_valid = False
        self.sensor_readings = {name: SensorReading() for name in SENSOR_CHANNELS}
        self.measurement_running = False
        self.shutdown_blocked = False
        # Nur kurze Auftragsannahme schützen, keinen langsamen Treiberaufruf darunter halten.
        self.accepted_lock = threading.Lock()
        self.write_pending = False
        # Auch die Automatik benutzt ausschließlich diesen Besitzerthread.
        # Tk setzt nur die sofort sichtbare Stoppabsicht. Ein laufender
        # Treiberaufruf kann fertig werden, danach folgt kein weiterer AUTO-Kanal.
        self.regulator = (self.model_controller.offline_regulator if self.model_controller is not None
                          else RegulationController())
        self._regulation_snapshot = self.regulator.snapshot()
        self.regulation_stop_requested = threading.Event()
        self._regulation_generation = 0
        self._regulation_start_pending = None
        self._regulation_active = False
        self._active_generation = -1
        self._last_regulation_event = 0.0
        self._read_sequence = 0
        self._controlled_sequence = -1
        self._last_read_at = 0.0
        self.session_log = SessionLog(log_directory)

    @property
    def regulation_snapshot(self):
        """Unveränderliche Daten statt lebender Regler- oder Taskobjekte."""
        return self._regulation_snapshot

    def request_start_regulation(self, settings: RegulationSettings) -> bool:
        if not self.allow_automation:
            raise RuntimeError("V11: Automatik ist für die Offline-Prüfung vorgesehen.")
        settings.validate()
        with self.accepted_lock:
            if (self.close_requested.is_set() or self.shutdown_blocked or self.write_pending
                    or self._regulation_start_pending is not None
                    or self._regulation_active
                    or self.regulation_snapshot.status == "running"):
                return False
            self._regulation_generation += 1
            generation = self._regulation_generation
            self._regulation_start_pending = generation
            self.regulation_stop_requested.clear()
        self.commands.put(("start_regulation", (generation, settings)))
        return True

    def request_stop_regulation(self) -> None:
        # Generationswechsel verwirft auch noch wartende Startanforderungen.
        with self.accepted_lock:
            self._regulation_generation += 1
            self._regulation_start_pending = None
            self.regulation_stop_requested.set()
        self.commands.put(("stop_regulation", None))

    def _publish_regulation(self, *, force=False) -> None:
        self._regulation_snapshot = self.regulator.snapshot()
        now = time.monotonic()
        if force or now - self._last_regulation_event >= 0.1:
            self.events.put(("regulation", self._regulation_snapshot))
            self._last_regulation_event = now

    def _close_log(self) -> None:
        try:
            self.session_log.close()
        except Exception as exc:
            self.events.put(("regulation_log_error", f"Messprotokoll abschließen: {exc}"))

    def _record_regulation(self) -> None:
        try:
            self.session_log.record(self.regulator.snapshot(), self.sensor_readings, time.monotonic())
        except Exception as exc:
            # Eine nicht beschreibbare Protokolldatei ist kein Stellauftrag.
            self.events.put(("regulation_log_error", f"Messprotokoll schreiben: {exc}"))
            self._close_log()

    def _hold_regulation(self, reason="Regelung angehalten · letzte Stellwerte halten") -> None:
        if self.regulator.snapshot().status == "running":
            self.regulator.stop(reason)
            self._publish_regulation(force=True)
            self._record_regulation()
            self._close_log()
        with self.accepted_lock:
            if self.regulator.snapshot().status != "running":
                self._regulation_active = False

    def _fault_regulation(self, detail) -> None:
        with self.accepted_lock:
            self._regulation_generation += 1
            self._regulation_start_pending = None
            self._regulation_active = False
            self.regulation_stop_requested.set()
        snapshot = self.regulator.snapshot()
        if snapshot.status != "fault" or snapshot.message != str(detail):
            self.regulator.fault(str(detail))
        self._publish_regulation(force=True)
        self._record_regulation()
        self._close_log()

    def _confirmed_percent(self) -> dict[str, float]:
        result = {}
        for name, current in self.controller.last_written.items():
            if name in CONFIGURED_ACTUATOR_CURVES:
                percent = fu_amp_to_percent(current)
                if name != "FU":
                    percent = 100.0 - percent
                result[name] = validate_percent(min(100.0, max(0.0, percent)), name)
        return result

    def _start_regulation(self, generation, settings) -> None:
        with self.accepted_lock:
            valid = (generation == self._regulation_generation
                     and not self.regulation_stop_requested.is_set()
                     and not self.close_requested.is_set())
            if self._regulation_start_pending == generation:
                self._regulation_start_pending = None
            if valid:
                # Reservierung bleibt auch bei einem langsamen Log-Dateizugriff
                # aktiv. Ein Stop+Neustart darf in dieser Lücke nicht den alten
                # Lauf wieder freigeben, bevor der Besitzer den Stop verarbeitet.
                self._regulation_active = True
                self._active_generation = generation
        if not valid:
            return
        try:
            if not self.measurement_running or self.shutdown_blocked:
                raise RuntimeError("Messung läuft nicht. Messung zuerst neu verbinden.")
            if self.controller.output_fault:
                raise RuntimeError("Ausgabefehler vorhanden. Ausgänge zunächst manuell prüfen/korrigieren.")
            outputs = self._confirmed_percent()
            if set(outputs) != {"FU", "GLF", "GHF"}:
                raise RuntimeError("Nicht alle drei Ausgangsbefehle sind bestätigt. Startinitialisierung prüfen.")
            self.regulator.start(settings, outputs, time.monotonic())
            self._controlled_sequence = -1
            self._publish_regulation(force=True)
            try:
                metadata = ({"model_context": self.model_controller.model_metadata}
                            if self.model_controller is not None else {})
                path = self.session_log.start(settings, self.regulator.snapshot(), time.monotonic(),
                                              **metadata)
                if path:
                    self.events.put(("regulation_log", str(path)))
            except Exception as exc:
                self.events.put(("regulation_log_error", f"Messprotokoll nicht verfügbar: {exc}"))
            self._publish_regulation(force=True)
        except Exception as exc:
            self._fault_regulation(f"Reglerstart fehlgeschlagen: {exc}")

    def _check_control_sample_age(self) -> None:
        """Auch während mehrerer langsamer Writes das Quellpaket prüfen.

        Ein frischer Read im nächsten Durchlauf darf einen zwischenzeitlich
        veralteten Stellauftrag nicht nachträglich als gültig erscheinen lassen.
        """
        settings = self.regulator.settings
        if settings is None:
            raise RuntimeError("Kein Reglerauftrag vorhanden.")
        now = time.monotonic()
        for name, target in self.regulator.snapshot().branch_setpoints.items():
            if target > 0:
                reading = self.sensor_readings[name]
                age = now - reading.received_at
                if not math.isfinite(age) or not 0 <= age <= settings.max_measurement_age_s:
                    raise RuntimeError(f"{name}: Messpaket während der Ausgabe veraltet. Weitere Kanäle werden nicht geschrieben.")

    def _auto_write(self, outputs) -> None:
        successful = []
        try:
            if set(outputs) != {"FU", "GLF", "GHF"}:
                raise ValueError("Regelauftrag muss genau FU, GLF und GHF enthalten.")
            confirmed = self._confirmed_percent()
            commands = []
            # Alle Angaben VOR dem ersten DAQ-Zugriff validieren.
            for name, percent in outputs.items():
                value = validate_percent(percent, name)
                if self.model_controller is not None:
                    self.model_controller.validate_model_command(name, value)
                current = validate_current(CONFIGURED_ACTUATOR_CURVES[name](value))
                if name not in confirmed or not math.isclose(value, confirmed[name], abs_tol=0.005, rel_tol=0):
                    commands.append((name, value, current))
            order = {"GLF": 0, "GHF": 1, "FU": 2}
            # Unbenutzten Zweig zuerst schließen, FU zuletzt nachführen.
            commands.sort(key=lambda cmd: -1 if cmd[0] != "FU" and cmd[1] == 0 else order[cmd[0]])
            for name, percent, current in commands:
                if (self.regulation_stop_requested.is_set() or self.close_requested.is_set()
                        or self._active_generation != self._regulation_generation):
                    break
                if self.regulator.snapshot().status != "running":
                    break
                self._check_control_sample_age()
                self.controller.write_current(name, current)
                successful.append((name, percent, current))
                # Tatsächlich bestätigte Teilaufträge ehrlich behalten.
                self.regulator.acknowledge({name: percent})
                if (not self.regulation_stop_requested.is_set()
                        and self._active_generation == self._regulation_generation):
                    self._check_control_sample_age()
        except Exception as exc:
            self._fault_regulation(f"Automatische Ausgabe fehlgeschlagen: {exc}")
            self.events.put(("state", self.state()))
        finally:
            if successful:
                self.events.put(("auto_written", tuple(successful)))
            if (self.regulation_stop_requested.is_set()
                    or self._active_generation != self._regulation_generation):
                self._hold_regulation()

    def _tick_regulation(self, now) -> None:
        if (self.regulation_stop_requested.is_set()
                or self._active_generation != self._regulation_generation):
            self._hold_regulation()
        if self.regulator.snapshot().status != "running" or self.close_requested.is_set():
            return
        try:
            if not self.measurement_running or now - self._last_read_at > MAX_MEASUREMENT_AGE_S:
                self._fault_regulation("Keine aktuellen Messpakete · letzte Stellwerte halten")
                return
            if self._controlled_sequence == self._read_sequence:
                return
            self._controlled_sequence = self._read_sequence
            outputs = self.regulator.step(self.sensor_readings, now)
            if self.regulator.snapshot().status == "fault":
                self._fault_regulation(self.regulator.snapshot().message)
                return
            if outputs:
                self._auto_write(outputs)
            self._publish_regulation()
            self._record_regulation()
        except Exception as exc:
            self._fault_regulation(f"Reglerberechnung fehlgeschlagen: {exc}")

    # Erstellt einen Status-Schnappschuss ohne direkte Task-Objekte.
    def state(self) -> DaqState:
        return DaqState(self.controller.measurement_task is not None,
                        tuple(self.controller.output_tasks),
                        self.controller.output_attempted, self.controller.output_fault)

    # Nimmt einen Stellauftrag an, wenn noch keiner läuft und kein Schließen geplant ist.
    def request_write(self, commands: list[tuple[str, float, float]]) -> bool:
        with self.accepted_lock:
            if (self.close_requested.is_set() or self.write_pending
                    or self._regulation_start_pending is not None
                    or self._regulation_active
                    or self.regulation_snapshot.status == "running"):
                return False
            self.write_pending = True
        self.commands.put(("write", tuple(commands)))
        return True

    # Sperrt neue Aufträge und fordert das Schließen aller Tasks an.
    def request_close(self) -> None:
        self.close_requested.set()
        self.request_stop_regulation()
        self.commands.put(("close", ()))

    # Prüft, ob ein gültiger Messwert höchstens eine Sekunde alt ist.
    def _recent(self) -> bool:
        return (self.measurement_valid and
                time.monotonic() - self.last_valid_at <= MAX_MEASUREMENT_AGE_S)

    # Liest Sensorströme und sendet Messwerte oder Fehlermeldungen zur GUI.
    def _read(self) -> None:
        try:
            acquired_at = time.monotonic()
            currents = self.controller.read_currents()
            # Vor dem wartenden Leseaufruf erfasst: Treiberwartezeit zählt zum
            # Alter und wird nicht durch einen neuen Empfangsstempel verdeckt.
            self._last_read_at = acquired_at
            self._read_sequence += 1
            self.sensor_readings = evaluate_sensor_currents(currents, acquired_at)
            # Der gemeinsame Zustand dient ausschließlich der bisherigen
            # Ausgabefreigabe. Die Messkarten verwenden ihre eigenen Zustände.
            self.measurement_valid = all(reading.valid for reading in self.sensor_readings.values())
            if self.measurement_valid:
                self.last_valid_at = acquired_at
            # Auch fehlerhafte/fehlende Rohwerte mit ihrem Empfangszeitpunkt an
            # die GUI weitergeben. Kein Kanal wird wegen des anderen ausgeblendet.
            self.events.put(("measurement", (self.sensor_readings.copy(), acquired_at)))
        except Exception as exc:
            self.measurement_valid = False
            self.sensor_readings = {name: SensorReading(problem="DAQ-Messfehler")
                                    for name in SENSOR_CHANNELS}
            self.measurement_running = False
            # Erfassung beenden, Ausgänge erhalten; fehlgeschlossene Task-Referenzen bleiben.
            try:
                problems = self.controller.close_measurement()
            except Exception as close_exc:
                problems = [str(close_exc)]
            if self.regulator.snapshot().status == "running":
                self._fault_regulation(f"DAQ-Messfehler: {exc}")
            self.events.put(("measurement_error", str(exc) +
                             (" | Schließfehler: " + "; ".join(problems) if problems else "")))
            self.events.put(("state", self.state()))

    # Prüft einen Stellauftrag erneut und schreibt die Kanäle nacheinander.
    def _write(self, commands) -> None:
        successful = []
        try:
            if self.regulator.snapshot().status == "running":
                raise RuntimeError("Automatik läuft. Vor manuellen Stellbefehlen Regelung stoppen.")
            if not commands:
                raise ValueError("Leerer Ausgabeauftrag.")

            # Alle Angaben vor dem ersten Hardwarezugriff überprüfen.
            for name, percent, current in commands:
                if name not in CONFIGURED_ACTUATOR_CURVES:
                    raise RuntimeError(f"{name}: Stellgliedkennlinie fehlt.")
                expected = validate_current(CONFIGURED_ACTUATOR_CURVES[name](
                    validate_percent(percent, name)))
                if validate_current(current) != expected:
                    raise ValueError(f"{name}: Strom passt nicht zur Kennlinie.")
                if self.model_controller is not None:
                    self.model_controller.validate_model_command(name, percent)

            for name, percent, current in commands:
                if self.close_requested.is_set() or self.shutdown_blocked:
                    raise RuntimeError("Abschluss aktiv; Auftrag abgebrochen.")

                # Dieser Pfad dient bestätigten manuellen Aufträgen.
                # Fehlende Sensorfreigabe verhindert die Korrektur nicht.
                self.controller.write_current(name, current)
                successful.append((name, percent, current))
                self.regulator.acknowledge({name: percent})

            self.events.put(("write_ok", tuple(successful)))

        except Exception as exc:
            # Eingabe-/Abbruchfehler sind keine neuen Hardwarefehler.
            # Echte Ausgangsfehler merkt der Controller pro Kanal.
            self.events.put(("write_error", (str(exc), tuple(successful))))

        finally:
            with self.accepted_lock:
                self.write_pending = False
            self._publish_regulation(force=True)
            self.events.put(("state", self.state()))

    def request_restart_measurement(self) -> bool:
        """Ein Messneustart wird wie ein Schreibauftrag serialisiert."""
        self.request_stop_regulation()
        with self.accepted_lock:
            if self.close_requested.is_set() or self.write_pending:
                return False
            self.write_pending = True
        self.commands.put(("restart_measurement", ()))
        return True

    def _restart_measurement(self) -> None:
        """Nur die Messung neu verbinden; keine Ausgangswerte schreiben."""
        self._hold_regulation("Messneustart · letzte Stellwerte halten")
        self.measurement_running = False
        self.measurement_valid = False
        self.last_valid_at = 0.0
        self.sensor_readings = {
            name: SensorReading() for name in SENSOR_CHANNELS
        }
        self.events.put(("measurement_restarting", None))

        try:
            if self.close_requested.is_set() or self.shutdown_blocked:
                raise RuntimeError("Abschluss aktiv; kein Messneustart.")

            problems = self.controller.close_measurement()
            if problems:
                raise RuntimeError(
                    "Alter Mess-Task nicht freigegeben: " + "; ".join(problems)
                )

            if self.close_requested.is_set():
                raise RuntimeError("Abschluss angefordert; kein Messneustart.")

            self.controller.start_measurement()
            self.measurement_running = True
            self.events.put(("started", None))

        except Exception as exc:
            self.events.put((
                "measurement_error",
                f"Messneustart für GHF ({AI_GHF}) und GLF ({AI_GLF}) "
                f"fehlgeschlagen: {exc}",
            ))

        finally:
            # Auch ein fehlgeschlagener Neustart muss die Bedienung freigeben.
            with self.accepted_lock:
                self.write_pending = False
            self.events.put(("state", self.state()))
            self.events.put(("measurement_restart_done", None))

    # Initialisiert die Ausgänge, startet die Messung und bearbeitet danach Aufträge.
    def run(self) -> None:
        if not self.close_requested.is_set():
            successful = []
            problems = []

            # Hardware und Beispieldemo starten auf 4 mA; im lokalen
            # Modell gelten stattdessen die gemessenen Arbeitspunktbefehle.
            initial = (self.model_controller.initial_percent if self.model_controller is not None
                       else {"FU": 0.0, "GLF": 100.0, "GHF": 100.0})
            for name in ("FU", "GLF", "GHF"):
                if self.close_requested.is_set():
                    break
                try:
                    percent = initial[name]
                    current = CONFIGURED_ACTUATOR_CURVES[name](percent)
                    self.controller.write_current(name, current)
                    successful.append((name, percent, current))
                    self.regulator.acknowledge({name: percent})
                except Exception as exc:
                    # Weitere Kanäle trotzdem initialisieren; AUTO verlangt
                    # später alle drei bestätigten Ausgangswerte ohne Fehler.
                    problems.append(f"{name}: {exc}")
            if problems:
                self.controller.output_fault = True
                self.events.put((
                    "write_error",
                    (
                        "Startinitialisierung fehlgeschlagen: " + "; ".join(problems),
                        tuple(successful),
                    ),
                ))
            elif len(successful) == 3:
                self.events.put(("write_ok", tuple(successful)))

            # Messung auch nach einem Ausgabefehler zur Diagnose starten.
            if not self.close_requested.is_set():
                try:
                    self.controller.start_measurement()
                    self.measurement_running = True
                    self.events.put(("started", None))
                except Exception as exc:
                    self.events.put((
                        "measurement_error",
                        f"Messinitialisierung fehlgeschlagen: {exc}",
                    ))

        self._publish_regulation(force=True)
        self.events.put(("state", self.state()))
        next_read = time.monotonic()
        while True:
            if self.regulation_stop_requested.is_set():
                self._hold_regulation()
            # Abschluss hat Vorrang: Wiederanlauf sperren, dann Ressourcen freigeben.
            if self.close_requested.is_set() and not self.shutdown_blocked:
                self.shutdown_blocked = True
                self.measurement_running = False
                self.measurement_valid = False
                self._close_log()
                try:
                    problems = self.controller.close_tasks()
                except Exception as exc:
                    problems = [f"Ressourcenfreigabe fehlgeschlagen: {exc}"]
                self.events.put(("state", self.state()))
                if not problems:
                    self.events.put(("closed", ()))
                    return
                # Nach Fehler nur erneute Freigabe derselben Ressourcen zulassen.
                # Ein wartender Write wird verworfen, kein Wiedereinstieg in Messung.
                while True:
                    try:
                        action, _ = self.commands.get_nowait()
                    except queue.Empty:
                        break
                # Erst nach dem Verwerfen alter Aufträge eine Wiederholung anbieten.
                # Andernfalls könnte die GUI bereits einen neuen Close-Auftrag senden,
                self.events.put(("closed", tuple(problems)))
                continue
            try:
                # Kurzes Warten vermeidet dauerhaftes Busy-Waiting bei leerer Befehlsqueue.
                action, payload = self.commands.get(timeout=0.02)
            except queue.Empty:
                action = None
            # Expliziter Wiederholungsversuch betrifft nur noch nicht freigegebene Ressourcen.
            if action == "close" and self.shutdown_blocked:
                try:
                    problems = self.controller.close_tasks()
                except Exception as exc:
                    problems = [f"Ressourcenfreigabe fehlgeschlagen: {exc}"]
                self.events.put(("state", self.state()))
                self.events.put(("closed", tuple(problems)))
                if not problems:
                    return
            elif action == "start_regulation":
                self._start_regulation(*payload)
            elif action == "stop_regulation":
                if self.regulation_stop_requested.is_set():
                    self._hold_regulation()
                    # Auch ein vor Ausführung verworfener Start braucht eine
                    # Quittierung, damit der GUI-Stoppknopf nicht hängen bleibt.
                    self._publish_regulation(force=True)
            elif action == "restart_measurement":
                self._restart_measurement()
                next_read = time.monotonic()
            elif action == "write" and not self.close_requested.is_set():
                # Vor jedem Auftrag nochmals aktuelle Samples holen.
                if self.measurement_running:
                    self._read()
                self._write(payload)
            now = time.monotonic()
            if self.measurement_running and not self.close_requested.is_set() and now >= next_read:
                self._read()
                # Keine aufgestauten GUI-Leseaufrufe nachholen; neues Intervall ab Leseende.
                next_read = time.monotonic() + GUI_REFRESH_MS / 1000
            self._tick_regulation(time.monotonic())
