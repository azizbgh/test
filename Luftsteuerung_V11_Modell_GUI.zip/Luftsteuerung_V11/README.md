# Nassheuer-Luftsteuerung mit Regelungsseite

V11 ergänzt eine Daten- und Reglerprüfung für den Offline-Betrieb. Einzelheiten
und die reproduzierbaren Befehle stehen in [V11_Bericht.md](V11_Bericht.md).
Im Hardwaremodus steht die manuelle Kanalprüfung zur Verfügung. Der
Automatikstart ist in dieser Version auf den Simulationsmodus begrenzt.

Das Programm bleibt modular. Die ZIP vollständig entpacken und die Ordner
zusammenlassen; `main.py` ist der Programmeinstieg.

```text
python -m pip install -r requirements.txt
python main.py --simulate
```

Der Simulationsstart öffnet keine NI-Hardware. Die Beispielsensoren sind kein
Anlagenmodell. Die Regelungsseite zeigt das Luftschema für FU, GHF und GLF
sowie den Gesamtverlauf und die beiden Zweigverläufe. Über **Parameter**
öffnest du die PID-Werte und Versuchseinstellungen. Stopp und Regelfehler
halten die letzten Stellbefehle.

## V11: GUI mit datenbasiertem Anlagenmodell

Im entpackten Projektordner installieren und einen lokalen Arbeitspunkt wählen:

```text
python -m pip install -r requirements.txt -r requirements-offline.txt
python main.py --model B
```

Für Arbeitspunkt C: `python main.py --model C`. Die Anzeige der Betriebsart
enthält **MODELL**; dieser Betrieb verwendet keine NI-Hardware. Die mitgelieferten
Parameter werden automatisch aus `auswertung/identifikation.json` und
`auswertung/vergleich.json` geladen. Bei einem Entwicklungs-Checkout ohne diese
beigepackten Dateien den Auswertungsordner ausdrücklich angeben:

```text
python main.py --model B --model-data "PFAD_ZUM_AUSWERTUNGSORDNER"
```

Den Platzhalter durch den Ordner mit beiden JSON-Dateien ersetzen.

Auf der Seite **Regelung** ist ausschließlich **Beide** verfügbar. Den dort
angezeigten lokalen Modellbereich beachten; auch manuelle Eingaben unterliegen
den festen Modellgrenzen. Gesamtsollwert eingeben und **Regelung starten**
bestätigen. Die PI-Regelung verwendet das aus realen Messdaten identifizierte
lokale Modell; für den Start müssen GHF und GLF auf ihren zugehörigen
Arbeitspunktstellungen stehen. Im Automatiklauf hält der Regler diese Stellungen.
**Regelung anhalten** hält die letzten Stellbefehle für den nächsten Lauf.
Die CSV-Protokolle sind als simuliert gekennzeichnet und enthalten den
Modellkontext. Den Pfad zeigt die Anwendung in **Einstellungen →
Ereignisprotokoll**. Ergebnisse gelten für den jeweiligen lokalen Modellbereich.

Die bisherigen Aufrufe `--simulate` und `--hardware` bleiben unverändert.

## Hardwarebetrieb

Nach betrieblicher Freigabe:

```text
python -m pip install -r requirements-hardware.txt
python main.py --hardware
```

Dieser Start fordert bereits dreimal 4 mA an. Der passende NI-DAQmx-Treiber
muss auf dem Rechner vorhanden sein. Für die reale Anlage ist in V11 die
manuelle Kanalprüfung vorgesehen; der Automatikstart ist gesperrt.

Bedienung, offene Versuchsparameter, Protokolle und Prüfschritte:
[README_Regelung.md](README_Regelung.md).

Softwareprüfungen: `python -m unittest discover -s tests -v`.
GUI-Prüfungen benötigen zusätzlich eine verfügbare grafische Anzeige.
