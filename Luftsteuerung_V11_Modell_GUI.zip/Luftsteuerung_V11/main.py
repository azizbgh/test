"""Nassheuer-Luftsteuerung: zentraler Programmeinstieg.

Start im Projekt-Hauptordner: python main.py --simulate
Ohne Parameter wird ebenfalls die vorhandene Simulation verwendet.
--hardware wählt wie bisher die reale NI-Hardware. Dabei fordert der
vorhandene Worker beim Start 4 mA an allen drei Ausgängen an. Beim bestätigten
Schließen fordert der reale Controller ebenfalls dreimal 4 mA an.

Die Seite Regelung startet die Automatik erst nach eigener Bestätigung.
Ein Regler-Stopp oder Regelfehler hält die letzten bestätigten Stellbefehle;
er löst keine 4-mA-Rückstellung aus. FU-Nachführung ist standardmäßig aktiv.
Bedienung, Versuchsparameter und Prüfschritte stehen in README_Regelung.md.
Ein bestätigter DAQ-Schreibaufruf ist keine Rückmessung des Ausgangsstroms.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from luftsteuerung.oberflaeche.dashboard import LuftsteuerungDashboard


# Argumente auswerten und dieselbe Dashboardklasse wie im Original starten.
# Ein Import dieser Datei ruft main() nicht auf.
def main():
    parser = argparse.ArgumentParser(description="Nassheuer-Luftsteuerung")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--simulate", action="store_true", help="Simulation ohne NI-Zugriff")
    group.add_argument("--model", choices=("B", "C"), help="Anlagendatenbasierte FU-PI-Simulation")
    group.add_argument("--hardware", action="store_true", help="Manuelle NI-Prüfung; Start fordert dreimal 4 mA an")
    parser.add_argument("--model-data", type=Path, help="Ordner mit identifikation.json und vergleich.json")
    args = parser.parse_args()
    controller = None
    if args.model:
        try:
            from luftsteuerung.modellsimulation import ModelDaqController
            from luftsteuerung.pid_optimierung import Parameters
            directory = args.model_data or (Path(__file__).resolve().parent / "auswertung")
            models = json.loads((directory / "identifikation.json").read_text(encoding="utf-8"))["models"]
            params = json.loads((directory / "vergleich.json").read_text(encoding="utf-8"))["selected"]
            controller = ModelDaqController(args.model, models[args.model], Parameters(**params))
        except (OSError, KeyError, ValueError, TypeError, ImportError) as exc:
            parser.error(f"Modelldaten oder Offline-Abhängigkeiten nicht verfügbar: {exc}")
    elif args.model_data is not None:
        parser.error("--model-data benötigt --model B oder --model C.")
    app = LuftsteuerungDashboard(simulate=not args.hardware, controller=controller)
    app.mainloop()


if __name__ == "__main__":
    main()
