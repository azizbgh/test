# V11 – Messdaten und Offline-Reglervergleich

## Stand und Datenkette

Grundlage ist der verfügbare modulare Checkout mit dem zuletzt veröffentlichten
ZIP aus Commit `f843a98`. Der separat erwähnte V10-Quellstand und sein manueller
Logger waren im verfügbaren Repository und dessen GitHub-Refs nicht vorhanden.
Die Auswertungsmodule wurden in diesem Stand neu erstellt. Eine Zusammenführung
mit dem vollständigen V10 erfordert dessen Quelldateien.

Die GUI benennt Stellbefehle logisch, der Worker übergibt den Namen an
`DaqController.write_current`, der seinen NI-Task über `AO_CHANNELS` anlegt.
Die neue Zuordnung lautet FU → ao0, GHF → ao1, GLF → ao2. Die Sensoreingänge
bleiben GHF → ai0 und GLF → ai1, ebenso die 4–20-mA-Kennlinien. Der CSV-Logger
speichert die Zuordnung als `output_mapping_version=2`, einschließlich
Ausgangs- und Sensorkanälen. Bestätigte Befehle sind keine Rückmessung.

Die Normalisierung erfolgt explizit für die acht benannten historischen
manuellen Hardwaredateien. Sie vertauscht nur die beiden Schieberbefehle
(Prozent, berechnete Ampere und Anfangsbefehle), prüft die Sollwertfolgen
und erzeugt neue CSVs mit Quellname und SHA-256. Neuere oder bereits
normalisierte Dateien werden bei `--legacy` abgelehnt. Die normalisierten
Dateien ergeben bei erneuter Analyse ohne `--legacy` identische Fit-Ergebnisse.

Der reale V11-Start erlaubt manuelle Bedienung für die betreute Kanalprüfung.
Die GUI sperrt den Automatikstart, und der Worker lehnt diesen Auftrag ab.
Der bisherige `--simulate`-GUI-Modus nutzt weiter die Beispielsensoren.
Der messdatenbasierte Kandidat läuft im Offline-Modul und in der
geschlossenen GUI-Simulation `python main.py --model B` oder `--model C`.
Die Modell-GUI startet am jeweiligen Messarbeitspunkt, begrenzt Stell- und
Sollbefehle auf den lokalen Bereich und hält beide Schieber in der
Automatik auf ihrem Messarbeitspunkt. CSVs tragen die Datenquelle
`model_simulation` und den Modellkontext. Der Kandidat besitzt keine
NI-Anbindung. Gültigkeitsgrenzen, Fehlerzeiten und HOLD der
bisherigen Regelung wurden beibehalten. Der manuelle Logger, aus dem die
eingesandten CSVs stammen, ist in diesem Checkout nicht verfügbar.

## Identifikation

8 Protokolle, 5.041 Messpakete, Medianfrequenzen 7,55–7,98 Hz.
Aus B und C folgen 18 bestätigte Sprünge für 36 Teilantworten. Pro Teilstrecke
wird ein lokaler PT1 mit Totzeit robust an die Rohantwort angepasst.
Der Befehlswechsel ist zwischen zwei Logzeilen eingegrenzt (0,10–0,16 s);
Messwertalter wird vom Probenzeitpunkt abgezogen. Stationäre Vorwerte und
Plateaus stammen aus den CSVs. Der letzte Sprung je Stellglied und Punkt
wird vor der Modellschätzung zurückgehalten (B drei Trainingssprünge,
C einer je Teilstrecke). Es gelten dokumentierte Fit- und Rauschschwellen im
Quellcode; nach diesen Kriterien sind 36 Einzelanpassungen verwendbar.
Die abweichende Zahl 32 aus der Voranalyse ist wegen anderer Fenster/
Annahmekriterien kein Widerspruch und keine unabhängige Gütebestätigung.

Stationäre Anfangsmittel der drei Versuche je Punkt ergeben für B
130,97 + 30,03 = 161,00 m³/h und für C 175,63 + 40,13 = 215,76 m³/h.
Die Tabelle gibt die Mediane über alle Einzelfits wieder. Der Vergleich
verwendet separat die Trainingsparametersätze aus `identifikation.json`.

| Strecke | K B | T B, s | L B, s | K C | T C, s | L C, s |
|---|---:|---:|---:|---:|---:|---:|
| FU → GHF | +2,942 | 1,52 | 3,82 | +3,053 | 1,55 | 3,17 |
| FU → GLF | +0,703 | 2,58 | 2,77 | +0,647 | 2,62 | 3,02 |
| GHF → GHF | +0,759 | 1,31 | 3,03 | +0,764 | 1,32 | 2,56 |
| GHF → GLF | −0,408 | 2,49 | 2,92 | −0,451 | 2,56 | 3,07 |
| GLF → GHF | −0,434 | 3,16 | 2,12 | −0,517 | 1,00 | 3,11 |
| GLF → GLF | +0,434 | 2,22 | 2,83 | +0,526 | 2,29 | 2,92 |

K in m³/h pro Prozentpunkt. Die 12 zurückgehaltenen Teilantworten ergeben
RMSE von 0,14 bis 2,54 m³/h. Gerade FU→GHF und GHF→GHF in B liegen
in der Größenordnung der Regelbandbreite. Bei B/GLF→GHF liegt ein Fit an
der Totzeit-Untergrenze und koppelt das mit T ≈ 8,16 s. Das ist ein Hinweis
auf geringe Trennschärfe zwischen T und L. Die Vorzeichen bestätigen die
Voranalyse, besonders die Nebenstrecken unterscheiden sich numerisch.
Öffnen und Schließen werden in den Einzelergebnissen getrennt gespeichert.
Bei B/GHF→GHF liegen zum Beispiel die effektiven Totzeiten beim Öffnen
bei rund 1,99–2,72 s und beim Schließen bei 3,34–3,45 s. Die kleine
Stichprobe trägt derzeit keinen allgemein gültigen Richtungsregler.

D01, GHF geschlossen angefordert: GHF-Anzeige 77,24 → −0,39, GLF
16,97 → 61,49 m³/h. D02, GLF geschlossen angefordert: GLF-Anzeige
16,98 → −0,017, GHF 76,59 → 92,13 m³/h. Das zeigt die Umlenkung.
Die kleinen Anzeigen unter Messgrenze eignen sich nicht zur quantitativen
Restflussbestimmung.

## Architekturvergleich

Beiden Reglern stehen dieselben lokalen, aus Einzelversuchen abgeleiteten
Modellgrenzen zur Verfügung. B erlaubt FU 15–25 %, Schieber 70–90 %;
C erlaubt FU 35–40 %, Schieber 80–90 %. Der Verzögerungsblock und die
PT1-Zustände bilden die sechs lokalen Teilstrecken separat.
Gleichzeitige Änderungen werden linear überlagert. Die Gültigkeit dieser
Überlagerung muss mit D03 getrennt nachgewiesen werden.

* **A** verwendet den bisherigen Zweig-PID-Regler und die FU-Nachführung.
  Anforderungen außerhalb des lokalen Modellbereichs werden für den
  Vergleich begrenzt und in der Ergebnisdatei gezählt.
* **B** regelt den Gesamtdurchfluss mit einem FU-PI und lokaler Vorsteuerung.
  Schieber können gegensinnig um einen festen Mittelwert feintrimmen.
  Das beseitigt die freie gemeinsame Schieberbewegung. In C fehlt am
  eingegrenzten Arbeitspunkt der gegensinnige Stellweg.

18 Skalierungen der ursprünglichen PID-Werte für A und 54 PI-/Vorsteuerungs-
Kandidaten für B wurden anhand vier nominaler Fälle verglichen. Die
Bewertung kombiniert Bandverletzungen/HOLD, Fehlerfläche, Überschwingen
und Stellbewegung. Der anschließende Modellvergleich umfasst jeweils
4 Szenarien (B/C, auf/ab) × 3 Modelle. Die beiden Störmodelle verwenden
beobachtete Fit-Spannweiten und angenommenes Gaußrauschen von 0,2 m³/h pro
Sensor. Einzelne Trendfenster liefern keine kontinuierliche Messgenauigkeit
in allen Zuständen. Die Variante mit größerem bzw. kleinerem Betrag der
Verstärkung und den gewählten T/L-Enden ist eine Sensitivitätsprüfung.

| Kandidat | Durchgehend im ±2-Band von 30–60 s | HOLD | IAE, Mittel | Stellweg gesamt, Mittel | Max. Überschwingen |
|---|---:|---:|---:|---:|---:|
| A, ursprüngliche PID-Werte | 0/12 | 12 | 553,92 | 29,47 pp | 10,34 m³/h |
| A, beste geprüfte PID-Skalierung | 0/12 | 12 | 521,75 | 32,24 pp | 10,59 m³/h |
| B, bester PI mit Vorsteuerung | 12/12 | 0 | 75,60 | 9,00 pp | 0,64 m³/h |
| B, bester PI ohne Vorsteuerung | 12/12 | 0 | 98,03 | 16,50 pp | 0,05 m³/h |

IAE in (m³/h)·s. Einschwingzeit in den gerechneten Fällen für B mit
Vorsteuerung 6,8–9,3 s, ohne Vorsteuerung 8,3–14,8 s. Das Überschwingen
ist richtungsbezogen; Unterschwingen nach erstmaligem Bandeintritt,
Stellgrenzen und Befehlswege stehen je Fall in `vergleich.json`.
Beim simulierten Ausfall von GLF bei Sekunde 12 gehen A und B sofort auf HOLD.

**Empfehlung für die nächste Offline- und Inbetriebnahmestufe ist B.**
Der beste Kandidat nutzt Kp 0,05 Prozentpunkte je (m³/h), Ti 4 s und
70 % der lokal berechneten FU-Vorsteuerung. Der ausgewählte Schiebertrim
ist in diesen Gesamtdurchfluss-Tests null; ein Nutzen der aktiven
Feinverteilung ist damit noch nicht belegt. Haltet die Schieber für
den ersten B/C-Vergleich fest und belegt einen Verteilungsnutzen
mit einem eigenen kombinierten Versuch. Die Modellwerte sind keine
freigegebenen PID-Parameter für reale Ausgänge. Den Faktor 1,05 setzt
der datenbasierte Kandidat nicht zusätzlich ein; sein lokales K
enthält die bei der Messung vorhandenen Streckenverluste.

## Reproduzieren

Im Projektordner mit den Originaldateien an den angegebenen Pfaden:

```text
python -m pip install -r requirements.txt -r requirements-offline.txt
python -m luftsteuerung.identifikation --legacy --output neu CSV_B01.csv CSV_B02.csv CSV_B03.csv CSV_C01.csv CSV_C02.csv CSV_C03.csv CSV_D01.csv CSV_D02.csv
python -m luftsteuerung.pid_optimierung neu/identifikation.json --output neu/vergleich.json
python -m unittest discover -s tests -v
```

Für die bereits normalisierten CSVs dieselben Namen im Verzeichnis
`auswertung/normalisiert` und den Aufruf ohne `--legacy` verwenden.
Beide Befehle schreiben neue Ausgabepfade. 75 Tests bestanden in 28,923 s,
einschließlich GUI-Tests auf einer virtuellen Anzeige. Der GUI-Modelltest
koppelt die Messwerte mit den realen B-Modellparametern, prüft die
Bereichsgrenze, einen laufenden FU-Befehl, feste Schieber, HOLD und die
CSV-Kennzeichnung. Das Protokoll liegt im Paket unter `auswertung`.

## Offene Risiken und Validierung

1. Erst freigegebener manueller Kanaltest mit Betreuer. Jeweils einen
   Schieber einzeln bewegen und physische Bewegung sowie zugehörige
   Sensoranzeige kontrollieren. FU-Zuordnung, Grenzrichtung und
   4-mA-Start-/Endzustand dokumentieren. Der Luftweg muss unabhängig
   von der Software gesichert werden können.
2. B- und C-Punkte reproduzieren. Stirbt ein Zweig ab, Ursache und
   Magnetzustand klären. Die kleinste verlässliche GHF-Menge ist offen.
   Für absolute Genauigkeit im ±2-Band ist eine Messreferenz erforderlich.
3. D03 mit freigegebenen kombinierten Schritten und separat abgelegten
   Protokollen ausführen. Fehlerkurven der beiden Sensoren, Kennwerte der
   Richtungen und Vorhersagefehler mit den lokalen Modellen vergleichen;
   D03 bis zum Abschluss dieser Prüfung nicht für das Tuning verwenden.
4. Vor einer Automatikfreigabe Absenken, limitierte Stellreserve,
   Stopp/HOLD und Messfehler separat prüfen. Zuerst kleine freigegebene
   Sollwertänderungen an B und C, dann Umfang nur datenbasiert erweitern.
   Für 12, 150 und 549 m³/h sowie für die einzelnen Betriebsarten liefert
   dieser Vergleich keinen Nachweis. Vor einem Einsatz des neuen
   Reglers müssen der vollständige V10-Stand und seine manuellen
   Messfunktionen zusammengeführt oder nachvollziehbar ersetzt sein.
