# V11 – Aufbau, Bedienung und Refactoring

## Ausgangspunkt und Analyse

Vergleichsbasis ist das zuletzt veröffentlichte V11-Paket mit Modellsimulation
aus Commit `022bd92`. Die ursprüngliche Hardware-, Regel- und CSV-Logik
ist bereits auf eigene Dateien verteilt. Zwei umfangreiche Oberflächendateien
enthielten jedoch Seitenaufbau, Diagramme, Meldungen und das Reagieren auf den
Hintergrundprozess. Änderungen an einer einzelnen Seite erforderten dadurch
die Orientierung in vielen fachfremden Methoden.

Der FU-PI war Teil des Optimierungsprogramms. Das Anlagenmodell importierte
seine Kanalnamen aus der Rohdatenanalyse. Dadurch musste die GUI-Modellsimulation
zusätzlich das Optimierungs- und Analyseprogramm samt wissenschaftlichen
Bibliotheken laden. Die Stromrückrechnung war an der Grenze zum Worker und
in der Modellsimulation identisch hinterlegt. Der bestätigte Befehl wurde je
nach Herkunft an mehreren Stellen für die Anzeige aufbereitet.

Der Worker (*Hintergrund-Thread*) gehört bewusst zusammen. Er führt alle
Gerätebefehle in einer Reihenfolge aus. Stoppen, eine laufende Ausgabe und
das Freigeben des Geräts teilen Zustandsinformationen. Diese Abläufe sind
eine beabsichtigte technische Kopplung. Auch die gewöhnliche Demo, die
Modellsimulation und die echte manuelle Hardwareprüfung besitzen verschiedene
Start- und Abschlussabläufe.

## Vollständiger Projektbaum des ZIP

```text
Luftsteuerung_V11/
├── .gitignore                       Lokale Laufdateien von Git ausnehmen
├── main.py                          Programmeinstieg und Betriebsart
├── README.md                        Kurze Start- und Bedienanleitung
├── README_Regelung.md                Bedienung, Fehler und Hardwaregrenzen
├── V11_Bericht.md                    Messdaten und ursprünglicher Reglervergleich
├── PROJEKTSTRUKTUR.md                 Aufbau und Vergleich des Refactorings
├── requirements.txt                 Bibliothek für die grafische Oberfläche
├── requirements-offline.txt         Bibliotheken für Fits und Reglervergleich
├── requirements-hardware.txt        Python-Schnittstelle für die NI-Prüfung
├── luftsteuerung/
│   ├── __init__.py                   Kennzeichnet das Programmpaket
│   ├── konfiguration.py              Gerätekanäle, Einheiten und Grenzen
│   ├── kennlinien.py                 Prozent, Strom und Durchfluss umrechnen
│   ├── messwerte.py                  Messpakete und Gültigkeit beschreiben
│   ├── hardware.py                   NI-Tasks und einfache Beispieldemo
│   ├── worker.py                     Messung und Ausgaben der Reihe nach ausführen
│   ├── regelung.py                   Zweigregler mit FU-Nachführung
│   ├── fu_regler.py                  FU-PI-Kandidat für den lokalen Gesamtdurchfluss
│   ├── protokoll.py                  Sitzungsdaten als versionierte CSV speichern
│   ├── identifikation.py             Historische CSVs prüfen, normalisieren und fitten
│   ├── anlagenmodell.py              Lokales Modell für die sechs Wirkungsbeziehungen
│   ├── modellsimulation.py           Modell an Worker und FU-Regler anschließen
│   ├── pid_optimierung.py            Regler offline rechnen und vergleichen
│   └── oberflaeche/
│       ├── __init__.py               Kennzeichnet das Oberflächenpaket
│       ├── basis.py                  Fenstergrundlage, Bedienaktionen und Hochlauf
│       ├── dashboard.py              Navigation, Fensterlayout und Anzeige koordinieren
│       ├── steuerungsseite.py        Manuelle Stellbefehle und Messkarten aufbauen
│       ├── einstellungsseite.py      Geräteinformationen und Meldungen darstellen
│       ├── ereignisse.py             Meldungen aus dem Worker verarbeiten
│       ├── messverlauf.py            Die Messkurven der Steuerungsseite zeichnen
│       ├── reglerseite.py            Sollwert, Start, Stopp und Reglersicht bedienen
│       ├── reglerverlauf.py          Soll- und Istkurven der Regelungsseite zeichnen
│       ├── luftschema.py             Lüfter, Schieber und Gesamtwert zeichnen
│       └── darstellung.py            Farben, Schriften und Zahlenformate
├── tests/
│   ├── test_gui_regelung.py           Bedienung, Anzeige und geschlossene Modell-GUI
│   ├── test_hardware_puffer.py        Datenfenster mit einem Testtreiber
│   ├── test_protokoll.py              Dateiformat, Zeitstempel und Bestätigungen
│   ├── test_regelung.py               Stellgrenzen, Regelung und Fehlerfälle
│   ├── test_v11.py                    Kanalzuordnung, historische CSVs und Modell
│   └── test_worker_regelung.py        Auftragsfolge, HOLD und Schreibfehler
└── auswertung/
    ├── identifikation.json            Modellparameter für B/C
    ├── vergleich.json                 Ergebnisse und gewählter FU-PI-Kandidat
    ├── tests_original.txt             Prüfprotokoll des veröffentlichten Originals
    ├── tests_refactoring.txt          Prüfprotokoll dieses Pakets
    └── verhaltensvergleich.txt         Statischer und numerischer Vergleich
```

## Verschobene Aufgaben und gemeinsame Funktionen

- `_build_control_tab` und `_step_setpoint` sind in `steuerungsseite.py`.
  `_build_settings_tab` ist in `einstellungsseite.py`, die Zeichenmethode
  `_draw_graph` in `messverlauf.py`. Das Fenster ruft dieselben Methoden auf.
- `ereignisse.py` enthält den GUI-Aktualisierungstakt, die Verteilung der
  Worker-Meldungen und die Fehlerdialoge. Die GUI bekommt Daten über eine
  Warteschlange. Sie verwendet bei der Anzeige die bestätigten Meldungen
  des Workers.
- `fu_regler.py` enthält den vorhandenen `PrimaryFlowPI` und dessen
  Parameter. Der Modelladapter und der Offline-Vergleich importieren
  denselben Regler. Die bisherigen Importe aus `pid_optimierung` bleiben
  als Kompatibilitätsnamen verfügbar. Das Modell und seine GUI können
  dadurch ohne NumPy und SciPy gestartet werden.
- `kennlinien.stellstrom_zu_prozent` verwendet dieselbe Rückrechnung für
  den Worker und den Modelladapter. Der FU arbeitet aufsteigend, die beiden
  Schieber absteigend. Die jeweilige Bereichsprüfung bleibt beim Aufrufer.
- `darstellung.format_stellbefehl` erzeugt den kompakten Text für bestätigte
  manuelle und automatische Befehle. Die Steuerungsseite zeigt zum Beispiel
  **20,00 % · 7,200 mA**. Der Prozentwert stammt aus dem bestätigten Befehl,
  die Anzeige aus dem Textfeld bleibt bis zur Übernahme ein Entwurf.

Kanalzuordnung, Mess- und Stellbereiche, PID-Berechnungen, Vorsteuerung,
Schreibreihenfolge, CSV-Schema und HOLD sind Teil des Vergleichsvertrags.
Der Hardwaremodus bleibt auf die manuelle Kanalprüfung beschränkt und setzt
beim Start die vorgesehenen 4-mA-Werte. Die Modellsimulation startet am
gewählten B/C-Punkt. Die anwendungsseitigen Betriebsarten und die
Bestätigung von Stellbefehlen behalten ihre Bedeutung.

## Start für neue Mitarbeitende

1. Das ZIP vollständig entpacken und im Ordner mit `main.py` ein Terminal öffnen.
2. `python -m pip install -r requirements.txt` ausführen.
3. Mit `python main.py --simulate` die Beispieldemo oder mit
   `python main.py --model B` bzw. `--model C` das B/C-Modell starten.
   Die Modelldateien in `auswertung` gehören zum Paket. Unter **Regelung**
   den angezeigten Sollbereich beachten und den Start bestätigen.
4. Für den erneuten Vergleich `requirements-offline.txt` installieren.
   Den genauen Aufruf für Identifikation und Vergleich zeigt der V11-Bericht.
5. Für die abgestimmte manuelle NI-Kanalprüfung sind zusätzlich der installierte
   NI-DAQmx-Treiber und `requirements-hardware.txt` erforderlich. Der
   Hardwarestart lautet `python main.py --hardware`.

## Prüfumfang und separater Altfehler

Die Prüfprotokolle enthalten die tatsächlich ausgeführten Tests des Originals
und des Refactorings. Die GUI-Tests laufen auf einer virtuellen Anzeige.
Schreibbefehle werden über Testtreiber oder die Modellsimulation geprüft.
Im Original bestanden 75 Tests und im Refactoring 76. Der zusätzliche Test
prüft die Anzeige beim Start und nach manueller Bestätigung, einschließlich
Dezimalprozent und leerem Eingabefeld. Ein bestehender Modell-GUI-Test deckt
die automatische Bestätigungsanzeige ab. Die Identifikation und der
Offline-Reglervergleich erzeugten in getrennten Läufen bytegleiche Ergebnisse
zur veröffentlichten V11. Der Quellvergleich fand keine fehlende Funktion
und keine zirkulären Modulimporte.
Verdrahtung, tatsächliche Schieberbewegung und Regelgüte an der Anlage
bleiben Aufgaben der geplanten realen Validierung, einschließlich D03.

Ein vorhandener Fehlerfall wurde mit einem Testtreiber reproduziert: Wenn
ein NI-Ausgang beim Anlegen fehlschlägt und auch das erste Schließen dieses
Tasks scheitert, kann ein unvollständig konfigurierter Task erhalten bleiben.
Beim nächsten Schließversuch versucht die Anwendung erneut zu schreiben.
Die tatsächliche Wiederherstellung dieses Tasks wäre eine gesonderte
Änderung der Hardware-Fehlerbehandlung. Dieser Fall ist im Refactoring
unverändert geblieben.

Der vollständige separate V10-Stand mit manuellem Messlogger war bei der
V11-Entwicklung nicht verfügbar. Vergleichsbasis ist die tatsächlich
vorliegende veröffentlichte V11-Version.
