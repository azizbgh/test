"""Reiner FU-Reglerkandidat für lokale Offline- und GUI-Modellversuche.

Dieses Modul liest keine Dateien, passt keine Modelle an und besitzt keine
Hardware. Offline-Vergleich und Modell-GUI benutzen dieselbe Parameters-Klasse
und dieselbe PrimaryFlowPI-Berechnung. Die Auswahl eines Parametersatzes und
die Prüfung eines Modellbereichs erfolgen beim Aufrufer.

Anders als die älteren GHF-/GLF-PID-Werte rechnet dieser Kandidat direkt mit
m³/h. kp hat die Einheit FU-Prozentpunkt je m³/h; ti wird in Sekunden erwartet.
Der GUI-Adapter lässt nur split_gain=0 zu und hält damit beide Schieber fest.
"""

from __future__ import annotations

from dataclasses import dataclass

from .anlagenmodell import clamp
from .konfiguration import OUTPUTS
from .regelung import GLF_RELIABLE_MIN_M3H


@dataclass(frozen=True)
class Parameters:
    """Unveränderlicher Parametersatz für den lokalen Kandidaten.

    kp: FU-Prozentpunkt/(m³/h), ti: Sekunden, feedforward: dimensionsloser
    Faktor der modellbasierten Vorsteuerung. split_gain gewichtet im
    Offline-Vergleich eine gegensinnige Schieberkorrektur; die GUI verlangt 0.
    Diese Werte sind keine neuen GHF-/GLF-Kc-/Ti-/Td-Einstellungen.
    """

    kp: float
    ti: float
    feedforward: float
    split_gain: float


class PrimaryFlowPI:
    """PI für die Durchflusssumme mit Vorsteuerung und lokalen Stellgrenzen.

    Ausgabe ist ein Tupel (FU, GHF, GLF) in Prozent. Ohne Messqualifikation
    bleibt die letzte Ausgabe erhalten. Ein Fehler wechselt in HOLD; der
    Kandidat erzeugt dafür keine 4-mA-Rückstellbefehle. Ausgaben sind zunächst
    Rechenabsichten: Bestätigungen verwaltet der aufrufende Worker-Adapter.
    """

    def __init__(self, parameters, model, bounds, initial, initial_flow, settings):
        """Modell, Prozentgrenzen und bisherigen Arbeitspunkt übernehmen.

        initial verwendet die Reihenfolge (FU, GHF, GLF). initial_flow ist
        die anfangs gemessene Summe in m³/h. Bei None wird die Vorsteuerung
        erst aus dem ersten qualifizierten Messpaket initialisiert.
        """
        self.p = parameters
        self.settings = settings
        self.bounds = bounds
        self.initial = initial
        self.outputs = initial
        self.integral = 0.
        self.status = "running"
        self.reason = ""
        self.outside_since = self.low_glf_since = None
        self.share = model["y0"][1] / sum(model["y0"])
        self.fu_gain = sum(model["paths"][f"FU->{sensor}"]["K"] for sensor in OUTPUTS)
        # Bei einem GUI-Start bildet das erste qualifizierte Messpaket
        # den Bezugspunkt. Offline-Szenarien kennen den Anfangsfluss bereits.
        self.feedforward = None if initial_flow is None else self._feedforward(initial_flow)
        (_, (glo, ghi), (llo, lhi)) = bounds
        self.trim_bounds = (max(glo - initial[1], initial[2] - lhi),
                            min(ghi - initial[1], initial[2] - llo))

    def _feedforward(self, flow):
        """Aus gemessenen m³/h und Modellverstärkung einen FU-Bezug berechnen."""
        return self.initial[0] + self.p.feedforward * (
            self.settings.setpoint_m3h - flow) / self.fu_gain

    def fault(self, reason):
        """Fehler merken und die letzte Prozent-Ausgabe ohne Reset halten."""
        self.status, self.reason = "fault", reason
        return self.outputs

    def step(self, y, readings, elapsed, dt):
        """Ein Rechenschritt mit Istwerten (GHF, GLF) in m³/h.

        elapsed, dt und Sensorzeitstempel müssen denselben relativen Zeitbezug
        in Sekunden besitzen. Das zurückgegebene Tupel bleibt innerhalb der
        lokalen Grenzen; die FU-Änderung wird zusätzlich pro Sekunde begrenzt.
        Messfehler, GLF-Untergrenze und anhaltende Zielverfehlung erzeugen HOLD.
        """
        if self.status != "running":
            return self.outputs
        cfg = self.settings
        if any(not readings[s].valid or not 0 <= elapsed - readings[s].received_at <= cfg.max_measurement_age_s
               for s in OUTPUTS):
            return self.fault("Messung ungültig oder veraltet")
        if y[1] < cfg.glf_missing_threshold_m3h:
            self.low_glf_since = elapsed if self.low_glf_since is None else self.low_glf_since
            if elapsed - self.low_glf_since >= cfg.glf_missing_delay_s:
                return self.fault("GLF unter Mindestdurchfluss")
        else:
            self.low_glf_since = None
        error = cfg.setpoint_m3h - sum(y)
        reliable = y[0] >= cfg.ghf_min_m3h and y[1] >= GLF_RELIABLE_MIN_M3H
        if elapsed >= cfg.settling_time_s and (not reliable or abs(error) > cfg.tolerance_m3h):
            self.outside_since = elapsed if self.outside_since is None else self.outside_since
            if elapsed - self.outside_since >= cfg.deviation_delay_s:
                return self.fault("Regelziel oder Messbereich anhaltend verfehlt")
        else:
            self.outside_since = None
        if not reliable:
            return self.outputs
        if self.feedforward is None:
            self.feedforward = self._feedforward(sum(y))

        proportional = self.p.kp * error
        inc = proportional * dt / self.p.ti
        candidate = self.feedforward + proportional + self.integral + inc
        lo, hi = self.bounds[0]
        if not (candidate > hi and inc > 0 or candidate < lo and inc < 0):
            self.integral += inc
        requested = clamp(self.feedforward + proportional + self.integral, (lo, hi))
        rate = cfg.fu_rate_percent_s * dt
        fu = clamp(self.outputs[0] + clamp(requested - self.outputs[0], (-rate, rate)), (lo, hi))
        split_error = y[1] - self.share * sum(y)
        trim = clamp(self.p.split_gain * split_error, self.trim_bounds)
        old_trim = self.outputs[1] - self.initial[1]
        trim = clamp(trim, (old_trim - rate, old_trim + rate))
        self.outputs = (fu, clamp(self.initial[1] + trim, self.bounds[1]),
                        clamp(self.initial[2] - trim, self.bounds[2]))
        return self.outputs
