"""Automatische Durchflussregelung ohne Hardware- oder Oberflächenzugriffe.

Der Worker bleibt alleiniger Besitzer der NI-Tasks. Dieser Rechenkern liefert
nur gewünschte Prozentwerte. Erst ``acknowledge`` übernimmt vom Worker
bestätigte Ausgaben; ein berechneter Wert ist noch kein ausgegebener Strom.

Die PID-Berechnung verwendet Prozentwerte und eine tatsächlich verstrichene
Zeit. Ti/Td werden von Minuten in Sekunden umgerechnet. Das ist eine eigene,
dokumentierte Implementierung, keine Zusage bitgleicher Ergebnisse zu NI PID.vi.
Die zeitlichen Koordinations- und FU-Parameter sind Entwicklungswerte und
müssen an der realen Anlage geprüft werden. Hier gibt es kein Anlagenmodell.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Mapping

from .kennlinien import ghf_amp_to_m3h, glf_amp_to_m3h, validate_percent
from .konfiguration import MAX_MEASUREMENT_AGE_S
from .messwerte import SensorReading


CHANNELS = ("FU", "GLF", "GHF")
GLF_MIN_M3H = 12.0
GLF_MAX_M3H = 100.0
GHF_MAX_M3H = 449.0
GLF_RELIABLE_MIN_M3H = 10.0
DEFAULT_FU_FOLLOW = True


def _finite(value: float, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{label}: Eine endliche Zahl ist erforderlich.")
    return float(value)


def _clip(value: float, lower: float, upper: float) -> float:
    return max(lower, min(upper, value))


@dataclass(frozen=True)
class PIDGains:
    """Die übernommenen Verstärkungswerte: Kc sowie Ti und Td in Minuten."""

    kc: float
    ti_minutes: float
    td_minutes: float

    def validate(self) -> None:
        """Die Kenngrößen des Reglers auf endliche, nichtnegative Werte prüfen."""
        for name in ("kc", "ti_minutes", "td_minutes"):
            if _finite(getattr(self, name), name) < 0:
                raise ValueError(f"{name}: Negative PID-Parameter sind hier nicht zulässig.")


@dataclass(frozen=True)
class RegulationSettings:
    """Ein vollständiger, unveränderlicher Auftrag für einen Regellauf.

    ``ghf_min_m3h`` ist eine vorläufige Messuntergrenze, keine neu bestätigte
    Sensoreigenschaft. Verzögerungen, Geschwindigkeiten und Filter sind offen
    benannte Versuchsparameter. Eine freie FU-Gesamtkennlinie wird nicht erfunden.
    Für Messreihen mit festem FU kann die Nachführung ausgeschaltet werden.
    """

    mode: str
    setpoint_m3h: float
    ghf_min_m3h: float = 50.0
    deviation_delay_s: float = 2.0
    fu_follow: bool = DEFAULT_FU_FOLLOW
    ghf_gains: PIDGains = field(default_factory=lambda: PIDGains(0.900, 0.108, 0.007))
    glf_gains: PIDGains = field(default_factory=lambda: PIDGains(0.320, 0.075, 0.001))
    tolerance_m3h: float = 2.0
    settling_time_s: float = 30.0
    valve_min_percent: float = 20.0
    valve_max_percent: float = 100.0
    glf_reserve_low_m3h: float = 40.0
    glf_reserve_high_m3h: float = 60.0
    coordinator_dwell_s: float = 2.0
    base_rate_m3h_s: float = 2.0
    derivative_filter_s: float = 0.2
    max_measurement_age_s: float = MAX_MEASUREMENT_AGE_S
    glf_missing_threshold_m3h: float = 5.0
    glf_missing_delay_s: float = 10.0
    fu_dwell_s: float = 5.0
    fu_rate_percent_s: float = 1.0
    fu_reserve_margin_percent: float = 10.0

    def validate(self) -> None:
        """Betriebsart, Sollbereich, Messzeiten und Stellgrenzen vor dem Start prüfen."""
        if self.mode not in ("GLF", "GHF", "BEIDE"):
            raise ValueError("Regelungsart muss GLF, GHF oder BEIDE sein.")
        target = _finite(self.setpoint_m3h, "Durchflusssollwert")
        minimum = _finite(self.ghf_min_m3h, "Vorläufige GHF-Messuntergrenze")
        if not 0 < minimum < GHF_MAX_M3H:
            raise ValueError("GHF-Messuntergrenze muss größer 0 und kleiner 449 m³/h sein.")
        # Die vereinbarten Sollbereiche bleiben unabhängig von einer verstellten
        # vorläufigen Messuntergrenze sichtbar und unverändert.
        lower, upper = {"GLF": (12.0, 100.0), "GHF": (50.0, 449.0),
                        "BEIDE": (12.0, 549.0)}[self.mode]
        if not lower <= target <= upper:
            raise ValueError(f"{self.mode}: Sollwert muss zwischen {lower:g} und {upper:g} m³/h liegen.")
        if not isinstance(self.fu_follow, bool):
            raise ValueError("FU-Nachführung muss ausdrücklich ein- oder ausgeschaltet sein.")
        if not isinstance(self.ghf_gains, PIDGains) or not isinstance(self.glf_gains, PIDGains):
            raise ValueError("Für beide Zweige sind PIDGains erforderlich.")
        self.ghf_gains.validate()
        self.glf_gains.validate()
        for name in ("deviation_delay_s", "coordinator_dwell_s", "derivative_filter_s", "fu_dwell_s"):
            if _finite(getattr(self, name), name) < 0:
                raise ValueError(f"{name}: Die Zeit darf nicht negativ sein.")
        for name in ("tolerance_m3h", "settling_time_s", "base_rate_m3h_s", "max_measurement_age_s",
                     "glf_missing_threshold_m3h", "glf_missing_delay_s", "fu_rate_percent_s",
                     "fu_reserve_margin_percent"):
            if _finite(getattr(self, name), name) <= 0:
                raise ValueError(f"{name}: Der Wert muss größer 0 sein.")
        low = validate_percent(self.valve_min_percent, "Untere Reglerstellgrenze")
        high = validate_percent(self.valve_max_percent, "Obere Reglerstellgrenze")
        if low < 20 or low >= high:
            raise ValueError("Aktive Schieber müssen innerhalb 20–100 % begrenzt bleiben.")
        if not 12 <= _finite(self.glf_reserve_low_m3h, "GLF-Reserve unten") < _finite(
                self.glf_reserve_high_m3h, "GLF-Reserve oben") <= 100:
            raise ValueError("GLF-Reserve muss ein aufsteigendes Band innerhalb 12–100 m³/h sein.")
        if self.fu_reserve_margin_percent >= (high - low) / 2:
            raise ValueError("FU-Reservemarge ist für die Stellgrenzen zu groß.")


@dataclass(frozen=True)
class RegulationSnapshot:
    """Daten für die GUI; alle Wörterbücher sind unabhängige Lesekopien.

    measured_total_m3h meint die tatsächlich zur Regelung verwendete Summe.
    Bei einem GLF-Teilbetrieb erklärt warning ausdrücklich, dass ungemessener
    GHF-Restfluss damit nicht als nachgewiesene Null behandelt werden darf.
    """

    status: str
    mode: str
    setpoint_m3h: float | None
    measured_total_m3h: float | None
    branch_setpoints: Mapping[str, float]
    outputs_percent: Mapping[str, float]
    error_m3h: float | None
    elapsed_s: float
    message: str
    warning: str
    within_tolerance: bool


class _PercentPID:
    """Paralleler PID mit D auf der Messung und bedingter Integration.

    u = Kc*e + I - Kc*Td*d(PV)/dt. D auf PV vermeidet einen D-Sprung
    bei einem Sollwertsprung. Der zusätzliche D-Filter ist ein ausgewiesener
    Entwicklungsparameter. Bei Sättigung wird nicht weiter in die falsche
    Richtung integriert. Der Startintegrator übernimmt den bisherigen Stellwert.
    """

    def __init__(self, gains: PIDGains, lower: float, upper: float, filter_s: float):
        self.gains = gains
        self.lower, self.upper = lower, upper
        self.filter_s = filter_s
        self.integral = 0.0
        self.previous_pv: float | None = None
        self.derivative = 0.0
        self.output = lower

    def track(self, output: float, setpoint: float, pv: float) -> float:
        """Den Prozentregler auf den zuletzt bestätigten Stellwert einstellen."""
        self.output = _clip(output, self.lower, self.upper)
        self.integral = self.output - self.gains.kc * (setpoint - pv)
        self.previous_pv = pv
        self.derivative = 0.0
        return self.output

    def update(self, setpoint: float, pv: float, dt: float) -> float:
        """Aus Soll, Ist und verstrichenen Sekunden den nächsten Stellwert berechnen."""
        if self.previous_pv is None or dt <= 0:
            return self.track(self.output, setpoint, pv)
        measured_slope = (pv - self.previous_pv) / dt
        alpha = 1.0 if self.filter_s == 0 else dt / (self.filter_s + dt)
        self.derivative += alpha * (measured_slope - self.derivative)
        self.previous_pv = pv
        error = setpoint - pv
        proportional = self.gains.kc * error
        differential = -self.gains.kc * self.gains.td_minutes * 60.0 * self.derivative
        increment = (self.gains.kc * error * dt / (self.gains.ti_minutes * 60.0)
                     if self.gains.ti_minutes > 0 else 0.0)
        candidate = proportional + self.integral + increment + differential
        # Ein Fehler, der die Sättigung abbaut, darf sofort weiter integrieren.
        if candidate > self.upper and increment > 0:
            # Den bis zur Grenze verfügbaren Anteil noch übernehmen. Nur das
            # Überschreiten sperren: Auch ein großer dt-Schritt erreicht damit
            # die Stellgrenze, statt dauerhaft knapp darunter hängen zu bleiben.
            self.integral = min(self.integral + increment,
                                max(self.integral, self.upper - proportional - differential))
        elif candidate < self.lower and increment < 0:
            self.integral = max(self.integral + increment,
                                min(self.integral, self.lower - proportional - differential))
        else:
            self.integral += increment
        self.output = _clip(proportional + self.integral + differential, self.lower, self.upper)
        return self.output


class RegulationController:
    """Zustandsautomat: Stopp und Fehler halten bestätigte Ausgänge unverändert."""

    def __init__(self) -> None:
        self.settings: RegulationSettings | None = None
        self.status = "idle"
        self._outputs: dict[str, float] = {}
        self._branch_setpoints = {"GHF": 0.0, "GLF": 0.0}
        self._pid: dict[str, _PercentPID] = {}
        self._pid_started: set[str] = set()
        self._started_at = self._last_step_at = 0.0
        self._elapsed = 0.0
        self._measured: float | None = None
        self._error: float | None = None
        self._within = False
        self._message = "Regelung nicht gestartet."
        self._warning = ""
        self._base = 0.0
        self._glf_only = False
        self._deviation_since: float | None = None
        self._glf_low_since: float | None = None
        self._reserve_direction = self._fu_direction = 0
        self._reserve_since: float | None = None
        self._fu_since: float | None = None

    def start(self, settings: RegulationSettings, outputs_percent: Mapping[str, float], now: float) -> None:
        """Einen Lauf mit geprüften Einstellungen und bestätigten Stellwerten beginnen."""
        settings.validate()
        now = _finite(now, "Startzeit")
        if set(outputs_percent) != set(CHANNELS):
            raise ValueError("Vor Reglerstart müssen FU, GLF und GHF bestätigt initialisiert sein.")
        confirmed = {name: validate_percent(outputs_percent[name], name) for name in CHANNELS}
        glf_only = settings.mode == "GLF" or (
            settings.mode == "BEIDE" and settings.setpoint_m3h < settings.ghf_min_m3h + GLF_MIN_M3H)
        if glf_only and settings.setpoint_m3h > GLF_MAX_M3H:
            raise ValueError("Diese GHF-Messuntergrenze erlaubt am Sollwert keinen GLF-Teilbetrieb.")
        # Erst nach sämtlichen Prüfungen einen bestehenden Lauf ersetzen.
        self.__init__()
        self.settings = settings
        self._outputs = confirmed
        self._started_at = self._last_step_at = now
        self.status = "running"
        self._message = "Regelung aktiv · FU-Nachführung " + ("ein" if settings.fu_follow else "aus")
        self._glf_only = glf_only
        if settings.mode == "GHF":
            self._branch_setpoints["GHF"] = settings.setpoint_m3h
        elif self._glf_only:
            self._branch_setpoints["GLF"] = settings.setpoint_m3h
        else:
            desired_glf = (settings.glf_reserve_low_m3h + settings.glf_reserve_high_m3h) / 2
            self._base = _clip(settings.setpoint_m3h - desired_glf,
                               max(settings.ghf_min_m3h, settings.setpoint_m3h - GLF_MAX_M3H),
                               min(GHF_MAX_M3H, settings.setpoint_m3h - GLF_MIN_M3H))
            self._branch_setpoints = {"GHF": self._base, "GLF": settings.setpoint_m3h - self._base}
        for name, gains in (("GHF", settings.ghf_gains), ("GLF", settings.glf_gains)):
            self._pid[name] = _PercentPID(gains, settings.valve_min_percent,
                                          settings.valve_max_percent, settings.derivative_filter_s)

    def acknowledge(self, outputs_percent: Mapping[str, float]) -> None:
        """Nur tatsächlich bestätigte Writes übernehmen, auch bei Teilerfolg.

        Ein leerer oder teilweiser Auftrag verändert andere Kanäle nicht. Damit
        kann der Worker einen bereits bestätigten Kanal auch dann melden, wenn
        der nächste Kanal einen Treiberfehler verursacht hat.
        """
        if any(name not in CHANNELS for name in outputs_percent):
            raise ValueError("Unbekannter Ausgang in der Reglerbestätigung.")
        confirmed = {name: validate_percent(value, name) for name, value in outputs_percent.items()}
        self._outputs.update(confirmed)

    def stop(self, reason: str = "Regelung bewusst gestoppt · letzte Stellwerte gehalten.") -> None:
        """Die Berechnung beenden und die bestätigten Befehle als HOLD speichern."""
        self.status = "stopped"
        self._message = reason
        self._within = False

    def fault(self, reason: str) -> None:
        """Die Fehlerursache melden und die bereits bestätigten Befehle halten."""
        self.status = "fault"
        self._message = reason + " · Regelung angehalten, letzte bestätigte Stellwerte gehalten."
        self._within = False

    def _flow(self, name: str, readings: Mapping[str, SensorReading], now: float) -> float:
        assert self.settings is not None
        reading = readings.get(name)
        if not isinstance(reading, SensorReading) or not reading.valid:
            detail = reading.problem if isinstance(reading, SensorReading) else "Messwert fehlt"
            raise ValueError(f"{name}: {detail or 'Ungültiger Sensorstrom'}")
        age = now - reading.received_at
        if not math.isfinite(age) or not 0 <= age <= self.settings.max_measurement_age_s:
            raise ValueError(f"{name}: Messwert veraltet oder Zeitstempel ungültig.")
        conversion = ghf_amp_to_m3h if name == "GHF" else glf_amp_to_m3h
        return conversion(reading.current_a)

    def _coordinate(self, required_glf: float | None, now: float, dt: float) -> None:
        """Grundlast nur mit qualifizierten Messwerten und freiem Stellweg verschieben."""
        assert self.settings is not None
        cfg = self.settings
        direction = 0
        reserve_limit = cfg.valve_max_percent - cfg.fu_reserve_margin_percent
        if required_glf is not None:
            # Letzte bestätigte Stellbefehle als Näherung für den freien Stellweg.
            if required_glf > cfg.glf_reserve_high_m3h and self._outputs["GHF"] < reserve_limit:
                direction = 1
            elif required_glf < cfg.glf_reserve_low_m3h and self._outputs["GLF"] < reserve_limit:
                direction = -1
        if direction != self._reserve_direction:
            self._reserve_direction, self._reserve_since = direction, now if direction else None
        if direction and self._reserve_since is not None and now - self._reserve_since >= cfg.coordinator_dwell_s:
            self._base = _clip(self._base + direction * cfg.base_rate_m3h_s * dt,
                               max(cfg.ghf_min_m3h, cfg.setpoint_m3h - GLF_MAX_M3H),
                               min(GHF_MAX_M3H, cfg.setpoint_m3h - GLF_MIN_M3H))

    def _follow_fu(self, valve_outputs: Mapping[str, float], now: float, dt: float,
                   measurement_reliable: bool = True) -> float:
        """Optional: langsame gemeinsame Druck-/Leistungsreserve beeinflussen.

        Es gibt keinen Druckmesswert und keine angenommene FU-Durchflusskurve.
        Deshalb wird nur bei anhaltend fehlender Öffnungsreserve UND zu geringem
        Durchfluss erhöht. Sind alle aktiven Schieber stark gedrosselt und der
        Durchfluss ausreichend, wird langsam abgesenkt. Mechanische Grenzen
        können durch diese reine Softwarelogik nicht überwacht werden.
        """
        assert self.settings is not None
        cfg = self.settings
        fu = self._outputs["FU"]
        if not cfg.fu_follow or not measurement_reliable:
            # Eine unvollständige Summe darf niemals als zusätzlicher Bedarf
            # des gemeinsamen Lüfters ausgelegt werden. Auch die Wartezeit
            # zurücksetzen, damit die Freigabe später keinen sofortigen Sprung
            # aus einer zuvor unbrauchbaren Fehlerbewertung auslöst.
            self._fu_direction = 0
            self._fu_since = None
            return fu
        active = [valve_outputs[name] for name, target in self._branch_setpoints.items() if target > 0]
        high = cfg.valve_max_percent - cfg.fu_reserve_margin_percent
        low = cfg.valve_min_percent + cfg.fu_reserve_margin_percent
        direction = 0
        if active and self._error is not None:
            if max(active) >= high and self._error > cfg.tolerance_m3h:
                direction = 1
            elif max(active) <= low and self._error <= cfg.tolerance_m3h:
                direction = -1
        if direction != self._fu_direction:
            self._fu_direction, self._fu_since = direction, now if direction else None
        if direction and self._fu_since is not None and now - self._fu_since >= cfg.fu_dwell_s:
            fu = _clip(fu + direction * cfg.fu_rate_percent_s * dt, 0.0, 100.0)
        return fu

    def step(self, readings: Mapping[str, SensorReading], now: float) -> dict[str, float]:
        """Einen Rechenschritt ausführen; Fehler liefern keine Ausgabeabsicht."""
        if self.status != "running":
            return {}
        assert self.settings is not None
        cfg = self.settings
        try:
            now = _finite(now, "Reglerzeit")
            if now < self._last_step_at:
                raise ValueError("Reglerzeit läuft rückwärts.")
            dt = now - self._last_step_at
            self._last_step_at = now
            self._elapsed = now - self._started_at
            self._measured = self._error = None
            self._within = False
            active = ("GHF",) if cfg.mode == "GHF" else (("GLF",) if self._glf_only else ("GHF", "GLF"))
            flows = {name: self._flow(name, readings, now) for name in active}
            warnings = []
            ghf_reliable = "GHF" not in active or flows["GHF"] >= cfg.ghf_min_m3h
            glf_reliable = "GLF" not in active or flows["GLF"] >= GLF_RELIABLE_MIN_M3H
            reliable = ghf_reliable and glf_reliable
            if "GHF" in active:
                warnings.append(f"GHF-Messuntergrenze {cfg.ghf_min_m3h:g} m³/h ist vorläufig/unbestätigt.")
            if cfg.mode == "BEIDE" and self._glf_only:
                warnings.append("GLF-Teilbetrieb: GHF geschlossen angefordert; GHF-Restfluss und Gesamtgenauigkeit nicht nachgewiesen.")
            elif not self._glf_only and cfg.mode == "BEIDE":
                if ghf_reliable:
                    residual = cfg.setpoint_m3h - flows["GHF"]
                else:
                    # Zum Anfahren erhält GHF weiterhin seinen Grundlastsollwert.
                    # Der unterhalb der Messgrenze liegende Wert wird aber nicht
                    # als zuverlässig gemessener Summenanteil verkauft.
                    # GHF kann hier bereits erheblichen Durchfluss führen.
                    # Ihn rechnerisch auf null zu setzen würde GLF zusätzlich
                    # den gesamten Sollwert aufbürden und Überfluss erzeugen.
                    # Bis GHF zuverlässig messbar wird, bleibt der geplante
                    # GLF-Anteil bestehen; die Grundlast wird nicht verschoben.
                    residual = cfg.setpoint_m3h - self._base
                    warnings.append("GHF unter vorläufigem Messbereich: nur GLF als Regel-Istwert; Gesamtdurchfluss unvollständig.")
                self._coordinate(residual if reliable else None, now, dt)
                ghf_target = self._base
                if reliable:
                    # Nahe der GLF-Stellgrenze den nicht gedeckten Anteil weich
                    # an GHF übergeben, ohne den Grundlastspeicher zu verstellen.
                    reserve_limit = cfg.valve_max_percent - cfg.fu_reserve_margin_percent
                    glf_limit_share = _clip(
                        (self._outputs["GLF"] - reserve_limit) / cfg.fu_reserve_margin_percent,
                        0.0, 1.0)
                    required_ghf = min(cfg.setpoint_m3h - flows["GLF"],
                                       GHF_MAX_M3H, cfg.setpoint_m3h - GLF_MIN_M3H)
                    ghf_target += glf_limit_share * max(0.0, required_ghf - ghf_target)
                self._branch_setpoints = {"GHF": ghf_target,
                                          "GLF": _clip(residual, GLF_MIN_M3H, GLF_MAX_M3H)}
            if not glf_reliable:
                warnings.append("GLF unter dem angegebenen zuverlässigen Messbereich von etwa 10 m³/h.")
            incomplete_total = cfg.mode == "BEIDE" and not self._glf_only and not ghf_reliable
            self._measured = flows["GLF"] if incomplete_total else sum(flows.values())
            # Eine Teilsumme ist weder der Gesamtdurchfluss noch ein Nachweis
            # einer großen Gesamtabweichung. Die GUI erhält deshalb keine
            # scheinbar exakt berechnete Gesamtfehlerzahl aus dieser Teilsumme.
            self._error = None if incomplete_total else cfg.setpoint_m3h - self._measured
            self._within = reliable and self._error is not None and abs(self._error) <= cfg.tolerance_m3h
            if cfg.fu_follow:
                warnings.append("FU-Nachführung ist ein unbestätigter Versuchsalgorithmus ohne Drucküberwachung.")
            self._warning = " ".join(warnings)

            # Der GLF-Timer läuft nur, solange GLF tatsächlich verwendet wird.
            # Er wird bei jedem neuen Start/Betriebsartenwechsel zurückgesetzt.
            if "GLF" in active and flows["GLF"] < cfg.glf_missing_threshold_m3h:
                if self._glf_low_since is None:
                    self._glf_low_since = now
                if now - self._glf_low_since >= cfg.glf_missing_delay_s:
                    self.fault(f"GLF seit {cfg.glf_missing_delay_s:g} s unter {cfg.glf_missing_threshold_m3h:g} m³/h: "
                               "Magnetstellung, Schieber, Versorgung und Luftweg prüfen")
                    return {}
            else:
                self._glf_low_since = None

            # Die Anlaufzeit beginnt mit dem Reglerstart. Erst danach muss eine
            # Verfehlung zusätzlich anhalten. Ein einzelner Ausreißer stoppt nicht.
            if self._elapsed >= cfg.settling_time_s and not self._within:
                if self._deviation_since is None:
                    self._deviation_since = now
                if now - self._deviation_since >= cfg.deviation_delay_s:
                    if not reliable:
                        self.fault("Messbereich nach der Anlaufzeit anhaltend nicht zuverlässig; "
                                   "Regelziel und Gesamtdurchfluss können nicht bestätigt werden")
                    else:
                        self.fault(f"Regelziel ±{cfg.tolerance_m3h:g} m³/h nach {cfg.settling_time_s:g} s anhaltend verfehlt")
                    return {}
            else:
                self._deviation_since = None

            desired = {"FU": self._outputs["FU"], "GLF": 0.0, "GHF": 0.0}
            for name in active:
                reference = GHF_MAX_M3H if name == "GHF" else GLF_MAX_M3H
                sp = self._branch_setpoints[name] / reference * 100.0
                pv = flows[name] / reference * 100.0
                if name not in self._pid_started:
                    desired[name] = self._pid[name].track(self._outputs[name], sp, pv)
                    self._pid_started.add(name)
                else:
                    desired[name] = self._pid[name].update(sp, pv, dt)
            desired["FU"] = self._follow_fu(desired, now, dt, reliable)
            return desired
        except (ValueError, TypeError, OverflowError) as exc:
            self.fault(str(exc))
            return {}

    def snapshot(self) -> RegulationSnapshot:
        """Den Stand der Regelung als unabhängige Kopie für Anzeige und CSV liefern."""
        return RegulationSnapshot(
            status=self.status,
            mode=self.settings.mode if self.settings is not None else "",
            setpoint_m3h=self.settings.setpoint_m3h if self.settings is not None else None,
            measured_total_m3h=self._measured,
            branch_setpoints=MappingProxyType(self._branch_setpoints.copy()),
            outputs_percent=MappingProxyType(self._outputs.copy()),
            error_m3h=self._error,
            elapsed_s=self._elapsed,
            message=self._message,
            warning=self._warning,
            within_tolerance=self._within,
        )
