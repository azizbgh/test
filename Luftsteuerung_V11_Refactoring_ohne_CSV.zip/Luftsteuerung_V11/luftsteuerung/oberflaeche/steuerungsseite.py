"""Widgets und Eingabeentwürfe der vorhandenen Steuerungsseite.

Die Methoden verwenden weiterhin die Widgetverzeichnisse und Bediencallbacks
des Dashboards. Pfeiltasten ändern nur den Eingabetext; DAQ-Aufträge bleiben
bei den vorhandenen Methoden der Basisklasse.
"""

from __future__ import annotations

import tkinter as tk

import customtkinter as ctk

from ..kennlinien import parse_percent
from .darstellung import COLOR_DARK, number_de


class SteuerungsseiteMixin:
    """Baut die manuelle Steuerungsseite und bearbeitet deren Sollwertentwürfe."""

    def _build_control_tab(self, tab):
        """Erstellt die vorhandenen Messkarten, Stellbefehle und Verlaufscanvas."""
        # Die gemeinsame uniform-Gruppe begrenzt das Verhältnis zwischen
        # oberem Bedienbereich und den unteren Diagrammen.
        self._control_page = tab
        tab.grid_columnconfigure(0, weight=1)
        tab.grid_rowconfigure(
            0, weight=11, uniform="sections"
        )
        tab.grid_rowconfigure(
            1, weight=9, uniform="sections"
        )

        upper = ctk.CTkFrame(
            tab,
            fg_color="transparent",
        )
        upper.grid(
            row=0, column=0, sticky="nsew", pady=(0, 8)
        )
        upper.grid_columnconfigure(
            0, weight=27, uniform="workspace"
        )
        upper.grid_columnconfigure(
            1, weight=73, uniform="workspace"
        )
        upper.grid_rowconfigure(0, weight=1)

        # Linke Spalte: zwei gleich große Messkarten.
        readings = ctk.CTkFrame(
            upper,
            fg_color="transparent",
        )
        readings.grid(
            row=0, column=0, sticky="nsew", padx=(0, 8)
        )
        readings.grid_columnconfigure(0, weight=1)
        readings.grid_rowconfigure(
            (0, 1), weight=1, uniform="readings"
        )

        for row, name in enumerate(("GHF", "GLF")):
            card = self._panel(readings)
            card.configure(fg_color="#EDF4FA")
            card.grid(
                row=row,
                column=0,
                sticky="nsew",
                pady=(0, 4) if row == 0 else (4, 0),
            )
            card.grid_columnconfigure(0, weight=1)

            # Zusätzlicher Platz bleibt unterhalb des zusammengehörenden
            # Inhalts. Zahl und Einheit werden nicht auseinandergezogen.
            card.grid_rowconfigure(4, weight=1)

            self._text(
                card,
                f"{name} – Volumenstrom",
                "heading",
                height=20,
            ).grid(
                row=0,
                column=0,
                sticky="w",
                padx=10,
                pady=(4, 0),
            )

            number_row = ctk.CTkFrame(
                card,
                fg_color="transparent",
            )
            number_row.grid(
                row=1,
                column=0,
                sticky="w",
                padx=12,
                pady=(0, 2),
            )

            value = self._text(
                number_row,
                "—",
                "value",
                height=26,
            )
            value.grid(row=0, column=0, sticky="w")
            self.value_labels[name] = value

            # Die Einheit steht unmittelbar neben dem Messwert.
            self._text(
                number_row,
                "m³/h",
                "unit",
                height=24,
            ).grid(
                row=0,
                column=1,
                sticky="s",
                padx=(5, 0),
            )

            details = ctk.CTkFrame(
                card,
                fg_color="transparent",
            )
            details.grid(
                row=2, column=0, sticky="w", padx=12
            )

            self._text(
                details,
                "Sensorstrom:",
                "body",
                height=18,
            ).grid(
                row=0,
                column=0,
                sticky="w",
                padx=(0, 8),
            )

            current = self._text(
                details,
                "— mA",
                "strong",
                height=18,
            )
            current.grid(row=0, column=1, sticky="w")
            self.current_labels[name] = current

            age_row = ctk.CTkFrame(
                card,
                fg_color="transparent",
            )
            age_row.grid(
                row=3,
                column=0,
                sticky="w",
                padx=12,
                pady=(1, 4),
            )

            self._text(
                age_row,
                "Messwertalter:",
                "body",
                height=18,
            ).grid(
                row=0,
                column=0,
                sticky="w",
                padx=(0, 8),
            )

            age = self._text(
                age_row,
                "—",
                "strong",
                height=20,
                corner_radius=5,
                fg_color="#CEE7FB",
            )
            age.grid(
                row=0, column=1, sticky="w", ipadx=6
            )
            self.age_labels[name] = age

        # Rechte Spalte: zusammenhängende Tabelle statt drei großer Karten.
        panel = self._panel(upper)
        panel.grid(row=0, column=1, sticky="nsew")
        panel.grid_columnconfigure(0, weight=1)
        panel.grid_rowconfigure(1, weight=1)

        self._text(
            panel,
            "Manuelle Stellbefehle",
            "heading",
            height=20,
        ).grid(
            row=0,
            column=0,
            sticky="w",
            padx=12,
            pady=(4, 2),
        )

        table = ctk.CTkFrame(
            panel,
            fg_color="#D4DFEA",
            corner_radius=6,
            border_width=1,
            border_color="#BDCCDC",
        )
        table.grid(
            row=1, column=0, sticky="new", padx=10
        )
        table.grid_columnconfigure(0, weight=1)
        self._command_table = table

        self._spin_buttons = {}
        self._spin_frames = {}
        self._table_rows = []

        # Zeile 0 enthält die Spaltenüberschriften.
        # Zeilen 1–3 enthalten FU, GLF und GHF.
        for row in range(4):
            band = ctk.CTkFrame(
                table,
                corner_radius=0,
                fg_color=(
                    "#DCE6EF" if row == 0 else
                    "#F5F8FC" if row % 2 else
                    "#EDF3F9"
                ),
            )
            band.grid(
                row=row,
                column=0,
                sticky="nsew",
                padx=1,
                pady=(1, 0) if row < 3 else (1, 1),
            )
            band.grid_rowconfigure(0, weight=1)

            # Identische Spaltenproportionen in Kopf- und Datenzeilen.
            for col, weight in enumerate((22, 40, 38)):
                band.grid_columnconfigure(
                    col,
                    weight=weight,
                    uniform="columns",
                )

            if row == 0:
                for col, title in enumerate((
                    "Kanal",
                    "Sollwert [%]",
                    "Letzter bestätigter Befehl",
                )):
                    self._text(
                        band,
                        title,
                        "table_header",
                        height=18,
                    ).grid(
                        row=0,
                        column=col,
                        sticky="w",
                        padx=10,
                    )
                continue

            name = ("FU", "GHF", "GLF")[row - 1]
            self._table_rows.append(band)

            self._text(
                band,
                name,
                "channel",
                height=20,
            ).grid(
                row=0,
                column=0,
                sticky="w",
                padx=10,
                pady=1,
            )

            field = ctk.CTkFrame(
                band,
                fg_color="transparent",
            )
            field.grid(
                row=0,
                column=1,
                sticky="w",
                padx=10,
                pady=1,
            )

            # Ein leeres Feld bedeutet weiterhin:
            # Diesen Kanal beim Übernehmen unverändert lassen.
            variable = ctk.StringVar(
                master=self,
                value="",
            )
            self.entry_variables[name] = variable

            # Feste Eingabebreite: Das Zahlenfeld wird nicht mehr
            # über die gesamte verfügbare Tabellenspalte gestreckt.
            spin = ctk.CTkFrame(
                field,
                width=132,
                height=30,
                corner_radius=5,
                fg_color="#FBFCFE",
                border_width=1,
                border_color="#8D9DB0",
            )
            spin.grid(row=0, column=0, sticky="w")
            spin.grid_propagate(False)
            spin.grid_columnconfigure(0, weight=1)
            spin.grid_rowconfigure((0, 1), weight=1)

            # self.inputs enthält weiterhin echte CTkEntry-Widgets,
            # damit die vorhandenen Bedienfunktionen weiterarbeiten.
            entry = ctk.CTkEntry(
                spin,
                width=100,
                height=28,
                textvariable=variable,
                font=self._fonts["entry"],
                border_width=0,
                fg_color="#FBFCFE",
                text_color=COLOR_DARK,
                corner_radius=4,
            )
            entry.grid(
                row=0,
                column=0,
                rowspan=2,
                sticky="ew",
                padx=(3, 0),
            )

            self.inputs[name] = entry
            self._spin_frames[name] = spin

            buttons = []

            # Beide Pfeile ändern ausschließlich den Eingabetext.
            # Sie lösen selbst keinen Schreibvorgang aus.
            for arrow_row, (symbol, step) in enumerate(
                (("▴", 1), ("▾", -1))
            ):
                button = ctk.CTkButton(
                    spin,
                    text=symbol,
                    width=20,
                    height=12,
                    corner_radius=2,
                    border_width=0,
                    font=self._fonts["small"],
                    fg_color="#E7EEF5",
                    hover_color="#D2E1ED",
                    text_color=COLOR_DARK,
                    command=lambda channel=name, delta=step:
                        self._step_setpoint(channel, delta),
                )
                button.grid(
                    row=arrow_row,
                    column=1,
                    sticky="nsew",
                    padx=(1, 2),
                    pady=(2, 0) if arrow_row == 0 else (0, 2),
                )
                buttons.append(button)

            self._spin_buttons[name] = buttons

            self._text(
                field,
                "%",
                "entry",
                height=26,
            ).grid(
                row=0,
                column=1,
                sticky="w",
                padx=(8, 0),
            )

            command_label = self._text(
                band,
                "—",
                "command",
                height=20,
            )
            command_label.grid(
                row=0,
                column=2,
                sticky="w",
                padx=10,
            )
            self.command_labels[name] = command_label

        self.fu_variable = self.entry_variables["FU"]
        self.fu_variable.trace_add(
            "write",
            lambda *_: self._update_preview(),
        )

        self._text(
            panel,
            "Befehlswerte · keine Ausgangsrückmessung",
            "small",
            height=12,
        ).grid(
            row=2,
            column=0,
            sticky="w",
            padx=12,
            pady=(2, 0),
        )

        actions = ctk.CTkFrame(
            panel,
            fg_color="transparent",
        )
        actions.grid(
            row=3,
            column=0,
            sticky="ew",
            padx=10,
            pady=2,
        )
        actions.grid_columnconfigure(
            (0, 1),
            weight=1,
            uniform="actions",
        )

        self.output_button = ctk.CTkButton(
            actions,
            text="▶  Sollwerte übernehmen",
            height=30,
            font=self._fonts["button"],
            fg_color="#008C83",
            hover_color="#00766E",
            state="disabled",
            command=self.output_update,
        )
        self.output_button.grid(
            row=0,
            column=0,
            sticky="ew",
            padx=(0, 4),
        )

        self.clear_button = ctk.CTkButton(
            actions,
            text="Eingaben leeren",
            height=30,
            font=self._fonts["button"],
            fg_color="#F9FBFE",
            border_width=1,
            border_color="#8799AD",
            hover_color="#E4EDF6",
            text_color=COLOR_DARK,
            command=self._clear_inputs,
        )
        self.clear_button.grid(
            row=0,
            column=1,
            sticky="ew",
            padx=(4, 0),
        )

        # Bestätigungen und Fehlermeldungen bleiben auf der Hauptseite.
        self.output_status = self._text(
            panel,
            "Noch kein Stellbefehl gesendet",
            "small",
            height=12,
            anchor="w",
            wraplength=470,
        )
        self.output_status.grid(
            row=4,
            column=0,
            sticky="ew",
            padx=12,
            pady=(0, 2),
        )

        # Unterer Bereich: zwei gleich große Diagramme.
        plots = self._panel(tab)
        plots.grid(row=1, column=0, sticky="nsew")
        plots.grid_columnconfigure(
            (0, 1),
            weight=1,
            uniform="plots",
        )
        plots.grid_rowconfigure(1, weight=1)

        self._text(
            plots,
            "MESSWERTVERLÄUFE · " +
            ("SIMULATION" if self.simulate else "HARDWARE"),
            "table_header",
            height=18,
        ).grid(
            row=0,
            column=0,
            columnspan=2,
            sticky="w",
            padx=10,
            pady=(3, 0),
        )

        for column, name in enumerate(("GHF", "GLF")):
            frame = self._panel(plots)
            frame.grid(
                row=1,
                column=column,
                sticky="nsew",
                padx=(4, 3) if column == 0 else (3, 4),
                pady=(0, 4),
            )
            frame.grid_columnconfigure(0, weight=1)
            frame.grid_rowconfigure(1, weight=1)

            self._text(
                frame,
                f"{name} · Durchflussverlauf",
                "heading",
                height=22,
            ).grid(
                row=0,
                column=0,
                sticky="w",
                padx=10,
                pady=(3, 0),
            )

            canvas = tk.Canvas(
                frame,
                background="#F6F9FD",
                highlightthickness=0,
                width=100,
                height=40,
            )
            canvas.grid(
                row=1,
                column=0,
                sticky="nsew",
                padx=4,
                pady=(0, 4),
            )
            canvas.bind(
                "<Configure>",
                self._mark_graphs_dirty,
                add="+",
            )
            self.graphs[name] = canvas

    def _step_setpoint(self, name, delta):
        """Ändert den Sollwertentwurf um einen Prozentpunkt."""
        entry = self.inputs[name]

        # Gesperrte Eingaben dürfen auch über die Pfeile nicht geändert werden.
        if entry.cget("state") == "disabled":
            return

        try:
            current = parse_percent(entry.get(), name)
        except ValueError:
            # Fehlerhafte Texteingaben bleiben zur Korrektur erhalten.
            return

        value = max(
            0.0,
            min(
                100.0,
                (current if current is not None else 0.0) + delta,
            ),
        )

        self.entry_variables[name].set(
            number_de(value, 0 if value.is_integer() else 2)
        )
