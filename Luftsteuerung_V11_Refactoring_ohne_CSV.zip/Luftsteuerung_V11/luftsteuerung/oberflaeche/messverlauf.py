"""Canvasdarstellung der bestehenden GHF- und GLF-Messwertverläufe.

Die Zeichenroutine verwendet ausschließlich die History des Dashboards.
Messdaten, Zeitstempel, Lücken und Live-Markierungen bleiben unverändert;
dieses Modul liest keine Hardware und plant keinen eigenen Messzyklus.
"""

from __future__ import annotations

from ..konfiguration import MAX_MEASUREMENT_AGE_S
from .darstellung import CARD_BG, COLOR_DARK, TEXT_MUTED, number_de


class MessverlaufMixin:
    """Zeichnet vorhandene Messpakete ohne zusätzliche Hardwareabfragen."""

    def _draw_graph(self, name, now):
        """Zeichnet den vorhandenen Kanalverlauf mit Lücken und Live-Wertkästchen."""
        canvas = self.graphs[name]

        if not canvas.winfo_ismapped():
            return

        width = canvas.winfo_width()
        height = canvas.winfo_height()

        if width < 60 or height < 20:
            return

        canvas.delete("all")

        history = list(self._history[name])
        valid_values = [
            value
            for _, value in history
            if value is not None
        ]

        if not valid_values:
            canvas.create_text(
                width / 2,
                height / 2,
                text="Noch keine gültigen Messdaten",
                fill=TEXT_MUTED,
                font=self._axis_font,
            )
            return

        # Jeder Kanal erhält eine eigene Skala.
        # Vorhandene kalibrierte Werte werden nicht verändert oder geklemmt.
        low = min(valid_values)
        high = max(valid_values)
        padding = max(1.0, (high - low) * 0.15)
        low -= padding
        high += padding

        line_height = self._axis_font.metrics("linespace")
        mini = height < line_height * 5

        left = (
            6 if mini
            else self._axis_font.measure("-999,9") + 10
        )
        right = width - 10
        top = 6 if mini else line_height + 4
        bottom = height - (
            6 if mini else line_height * 2 + 8
        )

        if bottom <= top or right <= left:
            return

        def point(timestamp, value):
            x = left + (
                (timestamp - (now - 60)) / 60
                * (right - left)
            )
            y = bottom - (
                (value - low) / (high - low)
                * (bottom - top)
            )
            return x, y

        if not mini:
            # Horizontales Raster und Durchflussskala.
            for index in range(4):
                value = low + (high - low) * index / 3
                y = point(now, value)[1]

                canvas.create_line(
                    left, y, right, y,
                    fill="#DFE7EE",
                )
                canvas.create_text(
                    left - 6,
                    y,
                    text=number_de(value, 1),
                    anchor="e",
                    font=self._axis_font,
                    fill=TEXT_MUTED,
                )

            # Gemeinsame Zeitachse: -60 Sekunden bis jetzt.
            for seconds in (-60, -45, -30, -15, 0):
                x = left + (
                    (seconds + 60) / 60
                    * (right - left)
                )

                canvas.create_line(
                    x, top, x, bottom,
                    fill="#E8EDF2",
                )
                canvas.create_text(
                    x,
                    bottom + 3,
                    text=str(seconds),
                    anchor="n",
                    font=self._axis_font,
                    fill=TEXT_MUTED,
                )

            canvas.create_text(
                left,
                0,
                text="m³/h",
                anchor="nw",
                font=self._axis_font,
                fill=TEXT_MUTED,
            )
            canvas.create_text(
                (left + right) / 2,
                height - 1,
                text="Zeit [s]",
                anchor="s",
                font=self._axis_font,
                fill=TEXT_MUTED,
            )

        color = (
            "#009688" if name == "GHF"
            else "#176FD1"
        )

        segment = []
        previous_time = None

        def draw_segment():
            if len(segment) >= 4:
                canvas.create_line(
                    *segment,
                    fill=color,
                    width=2,
                    smooth=False,
                )

        # Fehlerhafte Messungen und längere Empfangspausen dürfen
        # nicht durch eine scheinbar durchgängige Linie verbunden werden.
        for timestamp, value in history:
            gap = (
                previous_time is not None
                and timestamp - previous_time > MAX_MEASUREMENT_AGE_S
            )

            if value is None or gap:
                draw_segment()
                segment = []

            if value is not None:
                segment.extend(point(timestamp, value))

            previous_time = timestamp

        draw_segment()

        reading = self.sensor_readings[name]

        # Ein Live-Wertkästchen erscheint ausschließlich bei einem
        # aktuell gültigen Kanal ohne Messfehler oder aktiven Abschluss.
        live = (
            not (
                self.measurement_error
                or self.closing
                or self.shutdown_blocked
            )
            and reading.valid
            and reading.recent(now)
            and history
            and history[-1][1] is not None
            and now - history[-1][0] <= MAX_MEASUREMENT_AGE_S
        )

        if live:
            x, y = point(*history[-1])

            canvas.create_oval(
                x - 3,
                y - 3,
                x + 3,
                y + 3,
                fill=color,
                outline=CARD_BG,
            )

            # Tatsächlichen letzten Messwert anzeigen.
            text = (
                number_de(history[-1][1], 2)
                + " m³/h"
            )
            badge_width = self._badge_font.measure(text) + 16
            badge_height = (
                self._badge_font.metrics("linespace") + 8
            )

            # Das Kästchen muss vollständig in den Canvas passen.
            if (
                badge_width < right - left
                and badge_height < bottom - top
            ):
                bx = max(
                    left,
                    min(
                        x - badge_width + 6,
                        right - badge_width,
                    ),
                )
                by = max(
                    2,
                    min(
                        y - badge_height - 10,
                        bottom - badge_height,
                    ),
                )

                # Wenn oberhalb nicht genug Platz vorhanden ist,
                # das Kästchen unterhalb des Punktes platzieren.
                if by + badge_height > y - 5:
                    by = min(
                        bottom - badge_height,
                        y + 10,
                    )

                canvas.create_rectangle(
                    bx,
                    by,
                    bx + badge_width,
                    by + badge_height,
                    fill=(
                        "#D9F5EE" if name == "GHF"
                        else "#DEEDFF"
                    ),
                    outline=(
                        "#8DDACC" if name == "GHF"
                        else "#9DC5F7"
                    ),
                )
                canvas.create_text(
                    bx + badge_width / 2,
                    by + badge_height / 2,
                    text=text,
                    font=self._badge_font,
                    fill=COLOR_DARK,
                )
