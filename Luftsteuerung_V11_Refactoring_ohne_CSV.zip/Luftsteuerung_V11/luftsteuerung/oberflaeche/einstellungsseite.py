"""Vorhandene Einstellungen, Kanalhinweise und Ereignisprotokoll.

Diese Ansicht zeigt bereits verfügbare Daten. Sie übernimmt keine DAQ-Tasks
und verändert beim Aufbau weder Konfiguration noch Ausgangswerte.
"""

from __future__ import annotations

import customtkinter as ctk

from ..konfiguration import (
    AI_GHF,
    AI_GLF,
    AO_CHANNELS,
    SENSOR_VALID_MAX_A,
    SENSOR_VALID_MIN_A,
)
from .darstellung import CARD_BG, COLOR_DARK, number_de


class EinstellungsseiteMixin:
    """Baut die Informationsseite mit den bisher verwendeten Widgetreferenzen."""

    def _build_settings_tab(self, tab):
        """Erstellt die vorhandenen Systeminformationen und Protokollwidgets."""
        tab.grid_columnconfigure(0, weight=1)
        tab.grid_rowconfigure(0, weight=1)

        # Nur die Informationsseite darf bei Bedarf scrollen.
        body = ctk.CTkScrollableFrame(
            tab,
            fg_color=CARD_BG,
        )
        body.grid(row=0, column=0, sticky="nsew")

        self._label(
            body,
            "Einstellungen und Systeminformationen",
            size=20,
            bold=True,
        ).pack(
            anchor="w",
            padx=16,
            pady=(12, 6),
        )

        for name, channel in [
            *AO_CHANNELS.items(),
            ("GHF-Sensor", AI_GHF),
            ("GLF-Sensor", AI_GLF),
        ]:
            self._label(
                body,
                f"{name}: {channel}",
                anchor="w",
            ).pack(
                fill="x",
                padx=16,
            )

        self.preview_label = self._label(
            body,
            "FU-Stromvorschau: — mA",
            anchor="w",
        )
        self.preview_label.pack(
            fill="x",
            padx=16,
            pady=(6, 0),
        )

        self._label(
            body,
            f"Software-Plausibilität: "
            f"{number_de(SENSOR_VALID_MIN_A * 1000, 1)}–"
            f"{number_de(SENSOR_VALID_MAX_A * 1000, 1)} mA\n"
            "FU: 0 % = 4 mA, 100 % = 20 mA\n"
            "GLF/GHF: 0 % = 20 mA, 100 % = 4 mA\n"
            "Messwertalter = Zeit seit Softwareempfang, "
            "kein Hardware-Zeitstempel.\n"
            "Verläufe enthalten angezeigte Messpakete, "
            "keine zusätzlichen Abfragen.",
            justify="left",
            anchor="w",
            wraplength=620,
        ).pack(
            fill="x",
            padx=16,
            pady=8,
        )

        # Ausführliche Sensorzustände bleiben hier verfügbar.
        for name in ("GHF", "GLF"):
            label = self._label(
                body,
                f"{name}: Warte auf Messdaten",
                anchor="w",
                wraplength=620,
            )
            label.pack(fill="x", padx=16)
            self.quality_labels[name] = label

        self.measurement_status = self._label(
            body,
            "Initialisierung",
            anchor="w",
            wraplength=620,
        )
        self.measurement_status.pack(fill="x", padx=16)

        self.task_label = self._label(
            body,
            "Tasks: noch nicht initialisiert",
            anchor="w",
            justify="left",
            wraplength=620,
        )
        self.task_label.pack(
            fill="x",
            padx=16,
            pady=6,
        )

        self._label(
            body,
            "Ereignisprotokoll",
            size=16,
            bold=True,
        ).pack(
            anchor="w",
            padx=16,
            pady=(10, 4),
        )

        self.log_box = ctk.CTkTextbox(
            body,
            height=200,
            fg_color="#F2F5F7",
            text_color=COLOR_DARK,
            font=ctk.CTkFont(
                family="Consolas",
                size=12,
            ),
        )
        self.log_box.pack(
            fill="x",
            padx=16,
            pady=(0, 12),
        )
        self.log_box.configure(state="disabled")
