"""Dashboard-Koordinator mit Navigation, Größenanpassung und Messwertanzeige.

LuftsteuerungDashboard bleibt die beim Programmstart gewählte Klasse.
Steuerungsseite, Einstellungen und die bestehende Canvas-Zeichenroutine
liegen in eigenen UI-Mixins. Die Regelungsseite bleibt ebenfalls ein Mixin.
Worker, DAQ-Abläufe und deren Aufrufreihenfolge bleiben bei der vorhandenen
Basisklasse; es entstehen keine zusätzlichen Messabfragen.

Gleich benannte Methoden in Basis und Dashboard sind gezielte Überschreibungen.
super() führt die gemeinsame Basislogik weiterhin aus.
"""

from __future__ import annotations

from collections import deque
import time
from tkinter import font as tkfont

import customtkinter as ctk

from ..konfiguration import GUI_REFRESH_MS
from ..kennlinien import ghf_amp_to_m3h, glf_amp_to_m3h
from .basis import LuftsteuerungApp
from .reglerseite import RegulationPageMixin
from .steuerungsseite import SteuerungsseiteMixin
from .einstellungsseite import EinstellungsseiteMixin
from .messverlauf import MessverlaufMixin
from .darstellung import (
    CARD_BG,
    FONT_FAMILY,
    COLOR_BLUE,
    COLOR_DARK,
    COLOR_ORANGE,
    COLOR_RED,
    TEXT_MUTED,
    format_stellbefehl,
)


class LuftsteuerungDashboard(
    RegulationPageMixin, SteuerungsseiteMixin, EinstellungsseiteMixin,
    MessverlaufMixin, LuftsteuerungApp,
):
    """Ansicht B mit drei Seiten, Messwertalter und zwei Verlaufskurven."""

    def __init__(self, *, simulate=True, controller=None):
        # Die Diagramme verwenden bereits empfangene Messpakete.
        # Es werden dafür keine zusätzlichen Hardwareabfragen gestartet.
        self._history = {
            name: deque(maxlen=1200)
            for name in ("GHF", "GLF")
        }
        self._recorded = {"GHF": 0.0, "GLF": 0.0}
        self._plot_at = 0.0
        self._graphs_dirty = True
        self._density = None

        # Die vorhandene Basisklasse übernimmt weiterhin:
        # Worker, Hardwareinitialisierung, Bestätigungen und Programmabschluss.
        super().__init__(simulate=simulate, controller=controller)
        self._fit_dashboard(force=True)

    def _text(self, parent, text, role="body", **kwargs):
        """Erstellt eine Beschriftung mit einer gemeinsamen Schriftvorlage."""
        return ctk.CTkLabel(
            parent,
            text=text,
            font=self._fonts[role],
            text_color=kwargs.pop("text_color", COLOR_DARK),
            **kwargs,
        )

    def _panel(self, parent):
        """Gemeinsames Aussehen der Messkarten und Bedienbereiche."""
        return ctk.CTkFrame(
            parent,
            fg_color=CARD_BG,
            corner_radius=8,
            border_width=1,
            border_color="#D7E3E9",
        )

    def _build_gui(self):
        # Gemeinsame Schriftobjekte lassen sich beim Verkleinern des Fensters
        # anpassen, ohne sämtliche Widgets neu aufzubauen.
        self._fonts = {
            "title": ctk.CTkFont(
                family=FONT_FAMILY, size=18, weight="bold"
            ),
            "heading": ctk.CTkFont(
                family=FONT_FAMILY, size=14, weight="bold"
            ),
            "value": ctk.CTkFont(
                family=FONT_FAMILY, size=28, weight="bold"
            ),
            "body": ctk.CTkFont(
                family=FONT_FAMILY, size=11
            ),
            "small": ctk.CTkFont(
                family=FONT_FAMILY, size=10
            ),
            "entry": ctk.CTkFont(
                family=FONT_FAMILY, size=16, weight="bold"
            ),
            "button": ctk.CTkFont(
                family=FONT_FAMILY, size=12, weight="bold"
            ),
            "unit": ctk.CTkFont(
                family=FONT_FAMILY, size=24, weight="bold"
            ),
            "strong": ctk.CTkFont(
                family=FONT_FAMILY, size=12, weight="bold"
            ),
            "channel": ctk.CTkFont(
                family=FONT_FAMILY, size=18, weight="bold"
            ),
            "command": ctk.CTkFont(
                family=FONT_FAMILY, size=14
            ),
            "table_header": ctk.CTkFont(
                family=FONT_FAMILY, size=11, weight="bold"
            ),
        }

        # Negative Tk-Schriftgrößen bedeuten Pixel.
        self._axis_font = tkfont.Font(
            root=self, family=FONT_FAMILY, size=-11
        )
        self._badge_font = tkfont.Font(
            root=self, family=FONT_FAMILY, size=-12, weight="bold"
        )

        self.configure(fg_color="#F2F6FA")

        # Kopfzeile: Marke, Betriebsart und die drei gewünschten Seiten.
        self.header = ctk.CTkFrame(
            self,
            fg_color=CARD_BG,
            corner_radius=0,
        )
        self.header.grid(row=0, column=0, sticky="ew")
        self.header.grid_columnconfigure(0, weight=1)

        self._text(
            self.header,
            "NASSHEUER / LUFTSTEUERUNG",
            "title",
            height=34,
        ).grid(
            row=0, column=0, sticky="w", padx=12, pady=9
        )

        # Der Modus steht unter der Navigation auf einem durchgehenden Band.
        # Die Kennzeichnung folgt der tatsächlich gewählten Datenquelle.
        model = self.worker.model_controller
        mode_text = ("SIMULATION · Ausgänge simuliert" if self.simulate
                     else "HARDWARE · Reale Ein- und Ausgänge")
        if model is not None:
            mode_text = f"SIMULATION · V11-MODELL {model.model_point} · FU-PI · ohne NI-Hardware"
        self._text(
            self.header,
            mode_text,
            "table_header",
            height=32,
            anchor="w",
            padx=10,
            fg_color="#D9EEF3",
            text_color=COLOR_BLUE,
        ).grid(
            row=1, column=0, columnspan=2, sticky="ew"
        )

        self.nav = ctk.CTkFrame(
            self.header,
            fg_color="transparent",
        )
        self.nav.grid(row=0, column=1, padx=6, pady=6)

        self.pages = {}
        self.nav_buttons = {}

        for index, name in enumerate(
            ("Steuerung", "Regelung", "Einstellungen")
        ):
            page = ctk.CTkFrame(
                self,
                fg_color="transparent",
            )
            self.pages[name] = page

            button = ctk.CTkButton(
                self.nav,
                text=name,
                width=90,
                height=34,
                font=self._fonts["table_header"],
                corner_radius=2,
                border_width=1,
                border_color="#A8B5C0",
                command=lambda selected=name: self._show_page(selected),
            )
            button.grid(row=0, column=index, padx=2)
            self.nav_buttons[name] = button

        # Diese Widgetverzeichnisse werden auch von den vorhandenen
        # Bedien- und Messfunktionen der Basisklasse verwendet.
        self.value_labels = {}
        self.current_labels = {}
        self.age_labels = {}
        self.quality_labels = {}
        self.command_labels = {}
        self.inputs = {}
        self.entry_variables = {}
        self.graphs = {}

        self._build_control_tab(self.pages["Steuerung"])
        self._build_regulation_tab(self.pages["Regelung"])
        self._build_settings_tab(self.pages["Einstellungen"])

        # Untere Statuszeile mit dem vorhandenen Abschlussknopf.
        footer = ctk.CTkFrame(
            self,
            fg_color="transparent",
        )
        footer.grid(
            row=2, column=0, sticky="ew", padx=12, pady=(0, 6)
        )
        footer.grid_columnconfigure(0, weight=1)

        self.connection_label = self._text(
            footer,
            "Initialisierung",
            "small",
            anchor="w",
            height=18,
        )
        self.connection_label.grid(
            row=0, column=0, sticky="w"
        )

        self.close_button = ctk.CTkButton(
            footer,
            text="Programm schließen",
            width=150,
            font=self._fonts["table_header"],
            corner_radius=2,
            fg_color="#EDF3F9",
            border_width=1,
            border_color="#8799AD",
            hover_color="#E4EDF6",
            text_color=COLOR_DARK,
            command=self.on_close,
        )
        self.reconnect_button = ctk.CTkButton(
            footer, text="Messung neu verbinden", width=170, height=28,
            font=self._fonts["button"], fg_color="#E1EDF4",
            hover_color="#D5E5EE", text_color=COLOR_DARK,
            command=self._restart_measurement,
        )
        self.reconnect_button.grid(row=0, column=1, padx=(8, 0))
        self.close_button.grid(row=0, column=2, padx=(8, 0))

        self.bind("<Configure>", self._fit_dashboard, add="+")
        self._show_page("Steuerung")
        self._fit_dashboard(force=True)

    def _show_page(self, name):
        """Wechselt die Ansicht, ohne den DAQ-Worker neu zu starten."""
        self._selected_page = name
        for key, page in self.pages.items():
            if key == name:
                page.grid(
                    row=1,
                    column=0,
                    sticky="nsew",
                    padx=6 if name == "Regelung" else 10,
                    pady=(8, 4) if name == "Regelung" else 4,
                )
            else:
                page.grid_remove()

            self.nav_buttons[key].configure(
                fg_color="#008C83" if key == name else "#EDF3F9",
                hover_color="#00766E" if key == name else "#DDE9F3",
                text_color="#FFFFFF" if key == name else COLOR_DARK,
            )

        self._update_reconnect_visibility()
        self._graphs_dirty = True

    def _update_reconnect_visibility(self):
        # Der Regleransicht bleibt mehr Platz für Status und Abschluss. Bei
        # verlorener Messung erscheint der Wiederverbinden-Knopf direkt dort.
        if self._selected_page != "Regelung" or self.measurement_error:
            self.reconnect_button.grid()
        else:
            self.reconnect_button.grid_remove()



    def _refresh_controls(self):
        # Die vorhandenen Messwert-, Fehler- und Abschlussprüfungen
        # entscheiden weiterhin über die Bedienfreigabe.
        super()._refresh_controls()
        if hasattr(self, "_selected_page"):
            self._update_reconnect_visibility()

        # Die zusätzlichen Pfeiltasten erhalten denselben Zustand
        # wie das zugehörige Eingabefeld.
        for name, buttons in self._spin_buttons.items():
            state = self.inputs[name].cget("state")
            for button in buttons:
                self._configure_if_changed(
                    button,
                    state=state,
                )

        if self.output_button.cget("state") == "normal":
            self._configure_if_changed(
                self.output_button,
                fg_color="#008C83",
            )

    def _configure_if_changed(self, widget, **options):
        # Die Basisklasse liefert "Sensorstrom: ...".
        # Die neue Karte besitzt dafür eine separate feste Beschriftung.
        if widget in getattr(self, "current_labels", {}).values():
            text = options.get("text")
            if text is not None and text.startswith("Sensorstrom: "):
                options["text"] = text.removeprefix("Sensorstrom: ")

            if options.get("text_color") == TEXT_MUTED:
                options["text_color"] = COLOR_DARK

        super()._configure_if_changed(widget, **options)


    def _fit_dashboard(self, event=None, force=False):
        """Passt Schriften und Bedienelemente an die Fenstergröße an."""
        if event is not None and event.widget is not self:
            return

        if self.closing or self.shutdown_blocked:
            return

        dimensions = (
            self.geometry()
            .split("+", 1)[0]
            .split("-", 1)[0]
        )
        width, height = map(int, dimensions.split("x", 1))
        compact = height < 650 or width < 1100

        if compact == self._density and not force:
            return

        self._density = compact

        sizes = {
            "title": 16 if compact else 19,
            "heading": 13 if compact else 21,
            "value": 24 if compact else 46,
            "unit": 22 if compact else 40,
            "body": 10 if compact else 15,
            "strong": 11 if compact else 17,
            "channel": 15 if compact else 24,
            "entry": 16 if compact else 24,
            "command": 12 if compact else 20,
            "table_header": 10 if compact else 14,
            "small": 9 if compact else 10,
            "button": 11 if compact else 16,
        }

        for role, size in sizes.items():
            self._fonts[role].configure(size=size)

        self._axis_font.configure(
            size=-10 if compact else -14
        )
        self._badge_font.configure(
            size=-11 if compact else -16
        )

        # Im kompakten Fenster bleiben die Tabellenzeilen fest.
        # Im großen Fenster füllen sie den begrenzten Tabellenbereich.
        self._command_table.grid(
            sticky="new" if compact else "nsew"
        )

        for row in (1, 2, 3):
            self._command_table.grid_rowconfigure(
                row,
                weight=0 if compact else 1,
                uniform="data" if not compact else "",
            )

        row_height = 26 if compact else 46
        for band in self._table_rows:
            band.grid_rowconfigure(
                0,
                minsize=row_height,
            )

        for name, entry in self.inputs.items():
            entry.configure(
                height=24 if compact else 34
            )
            self._spin_frames[name].configure(
                width=110 if compact else 172,
                height=26 if compact else 36,
            )

        for button in (
            self.output_button,
            self.clear_button,
            self.reconnect_button,
        ):
            button.configure(
                height=26 if compact else 40,
                font=self._fonts["button"],
            )

        self.close_button.configure(height=34, font=self._fonts["table_header"])

        for button in self.nav_buttons.values():
            button.configure(
                width=88 if compact else 104,
                height=34,
            )

        # Bei kleinen Fenstern etwas mehr Höhe für die Bedienung reservieren.
        self._control_page.grid_rowconfigure(
            0,
            weight=3 if compact else 11,
        )
        self._control_page.grid_rowconfigure(
            1,
            weight=2 if compact else 9,
        )

        self.output_status.configure(
            wraplength=470 if compact else 760
        )
        self._graphs_dirty = True

    def _show_written(self, commands):
        commands = tuple(commands)

        # Weiterhin nur tatsächlich bestätigte Teilbefehle übernehmen
        # und deren Eingabefelder anschließend leeren.
        super()._show_written(commands)

        for name, percent, current in commands:
            self.command_labels[name].configure(
                text=format_stellbefehl(percent, current),
                text_color=COLOR_DARK,
            )

    def _mark_graphs_dirty(self, _event=None):
        self._graphs_dirty = True

    def _render_measurement(self):
        # Bestehende Einzelkanalbewertung und Ausgabefreigaben ausführen.
        super()._render_measurement()

        now = time.monotonic()

        for name, convert in (
            ("GHF", ghf_amp_to_m3h),
            ("GLF", glf_amp_to_m3h),
        ):
            reading = self.sensor_readings[name]

            # Das Alter gehört zum angezeigten Wert, nicht zu einer Fehlermeldung.
            displayed_at = self._display_times.get(name, 0.0)
            age = max(0, round((now - displayed_at) * 1000)) if displayed_at else None
            cached = self._display_cached.get(name, False)
            text = "—" if age is None else f"{age} ms"
            color = COLOR_DARK

            if self.measurement_error or (reading.received_at and not reading.valid):
                color = COLOR_RED
            elif cached or self.closing or self.shutdown_blocked:
                color = COLOR_ORANGE

            if cached:
                text += " · ALT"
            elif color == COLOR_RED:
                text += " · FEHLER"

            self._configure_if_changed(
                self.age_labels[name], text=text, text_color=color)

            # Pro neuem Softwareempfang höchstens einen Punkt speichern.
            # Ein ungültiger Messwert erzeugt eine Lücke im Verlauf.
            if (
                reading.received_at
                and reading.received_at != self._recorded[name]
            ):
                self._recorded[name] = reading.received_at

                valid = (
                    reading.valid
                    and not self.measurement_error
                    and reading.recent(now)
                )
                value = (
                    convert(reading.current_a)
                    if valid else None
                )

                self._history[name].append(
                    (reading.received_at, value)
                )

            # Das Diagramm zeigt ausschließlich die letzten 60 Sekunden.
            while (
                self._history[name]
                and self._history[name][0][0] < now - 60
            ):
                self._history[name].popleft()

        # Den vorhandenen GUI-Poller verwenden.
        # Kein zusätzlicher Thread und keine weitere after()-Schleife.
        if (
            self._graphs_dirty
            or now - self._plot_at >= max(
                0.2,
                GUI_REFRESH_MS / 1000,
            )
        ):
            self._graphs_dirty = False
            self._plot_at = now

            for name in ("GHF", "GLF"):
                self._draw_graph(name, now)
