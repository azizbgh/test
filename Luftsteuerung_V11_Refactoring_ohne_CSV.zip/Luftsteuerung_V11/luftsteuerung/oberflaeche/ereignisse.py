"""Worker-Ereignisse und Fehlerdialoge im Tk-Hauptthread verarbeiten.

WorkerEventsMixin bündelt den vorhandenen Queue-Poller, dessen Wiederplanung
nach Darstellungsfehlern, Bestätigungen aus dem Worker und Sensorfehlermeldungen.
Der Baustein besitzt keine Hardwaretasks und startet keine eigene Ereignisschleife.
LuftsteuerungApp stellt Widgets, Bedienzustände und die übrigen GUI-Helfer bereit.

Die Methodennamen und Abläufe bleiben beim Auslagern erhalten. Automatische
Schreibbestätigungen zeigen Prozent und berechneten Sollstrom; sie verändern
keine manuellen Eingabeentwürfe. Die ausführlichere manuelle Bestätigung bleibt
in basis.py. Stellbefehle sind keine Rückmessung des Ausgangsstroms.
"""

from __future__ import annotations

import queue
import time
import tkinter as tk
from tkinter import messagebox

from ..konfiguration import AI_GHF, AI_GLF, MAX_MEASUREMENT_AGE_S, SENSOR_CHANNELS
from ..messwerte import SensorReading
from .darstellung import COLOR_BLUE, COLOR_ORANGE, COLOR_RED, format_stellbefehl, number_de


class WorkerEventsMixin:
    """Gemeinsame Ereignisverarbeitung; ausschließlich vom GUI-Thread aufrufen."""

    # Liest Worker-Meldungen und plant mit after() den nächsten GUI-Durchlauf.
    def update_measurement(self) -> None:
        """GUI-Aktualisierung auch nach Darstellungsfehlern fortsetzen."""
        previous = self.poll_after_id
        self.poll_after_id = None

        # Eine vorhandene Planung ersetzen, keinen zweiten Poller erzeugen.
        if previous is not None:
            try:
                self.after_cancel(previous)
            except tk.TclError:
                pass

        delay = 50
        cycle_ok = True
        try:
            self._process_measurement_events()
        except Exception:
            import traceback
            cycle_ok = False
            delay = 500
            self._report_gui_error(traceback.format_exc())
        finally:
            try:
                alive = bool(self.winfo_exists())
            except tk.TclError:
                alive = False

            if alive:
                try:
                    # Busy nicht zurücksetzen: Ein DAQ-Auftrag könnte noch laufen.
                    self._refresh_controls()
                except Exception:
                    import traceback
                    cycle_ok = False
                    delay = 500
                    self._report_gui_error(traceback.format_exc())
                finally:
                    if cycle_ok:
                        self._last_gui_error = None
                    self.poll_after_id = self.after(
                        delay, self.update_measurement)

    def _report_gui_error(self, detail: str) -> None:
        # Gleiche Dauerfehler nicht ständig erneut in den Vordergrund holen.
        if detail == getattr(self, "_last_gui_error", None):
            return

        self._last_gui_error = detail
        print(detail)

        try:
            self._log("GUI-Fehler: " + detail.strip().splitlines()[-1])
        except Exception:
            pass

        try:
            self._show_error_details(
                "Fehler in der Oberfläche",
                detail + "\nDie Aktualisierung wird erneut versucht. "
                "Ein laufender Hardwareauftrag wird dabei nicht abgebrochen.")
        except Exception:
            import traceback
            traceback.print_exc()

    def _process_measurement_events(self) -> None:
        """Verarbeitet Ereignisse; die Zeitplanung übernimmt update_measurement()."""
        self.poll_after_id = None
        # Queue-Rückstau darf die nächste Bedienaktion nicht unbegrenzt verzögern.
        for _ in range(100):
            try:
                kind, payload = self.worker.events.get_nowait()
            except queue.Empty:
                break
            if kind == "regulation":
                self._reg_sensor_fault_already_reported = False
                if payload.status == "fault":
                    # Sensorwarnung und Regler-HOLD können dieselbe Ursache
                    # beschreiben. Genau ein Dialog genügt; Karte und Protokoll
                    # bleiben unabhängig davon sichtbar und aktuell.
                    for name, reading in self.sensor_readings.items():
                        if payload.message.startswith(name + ":") and reading.problem:
                            self._reg_sensor_fault_already_reported = (
                                self._sensor_popup_problem.get(name) == reading.problem)
                            self._sensor_popup_problem[name] = reading.problem
                if hasattr(self, "_on_regulation_event"):
                    self._on_regulation_event(payload)
                else:
                    self.regulation_snapshot = payload
            elif kind == "auto_written":
                # AUTO aktualisiert nur die bestätigten Befehlsanzeigen. Keine
                # manuellen Entwürfe löschen, keine 20 Logzeilen je Sekunde.
                for name, percent, current in payload:
                    self.command_labels[name].configure(
                        text=format_stellbefehl(percent, current),
                        text_color=COLOR_BLUE,
                    )
            elif kind in ("regulation_log", "regulation_log_error"):
                self._log(("Messprotokoll: " if kind == "regulation_log" else "Protokollfehler: ") + str(payload))
                if kind == "regulation_log_error":
                    self._show_error_details("Messprotokoll nicht verfügbar", str(payload))
            elif kind == "state":
                self.daq_state = payload
            # Originalen Worker-Zeitstempel übernehmen statt durch „jetzt“ zu ersetzen.
            elif kind == "measurement":
                readings, self.last_measurement_at = payload
                # Zustände enthalten unveränderliche Einzelwerte; keine Widgets
                # oder lebenden Task-Referenzen kommen aus dem Worker-Thread.
                previous = self.sensor_readings
                self.sensor_readings = readings
                self.last_currents = tuple(readings[name].current_a for name in SENSOR_CHANNELS)
                self.measurement_valid = all(reading.valid for reading in readings.values())
                self.measurement_error = False
                # Nur einen geänderten Fehlerstatus protokollieren, nicht jeden
                # identischen 200-ms-Messzyklus. Der betroffene Kanal ist benannt.
                for name, reading in readings.items():
                    if reading.problem and reading.problem != previous[name].problem:
                        raw = ("fehlt" if reading.current_a is None else
                               number_de(reading.current_a * 1000, 6) + " mA")
                        self._log(f"{name} / {SENSOR_CHANNELS[name]}: {raw} · {reading.problem}")
            elif kind == "measurement_restarting":
                self.measurement_valid = False
                self.measurement_error = False
                self.last_measurement_at = 0.0
                self.sensor_readings = {
                    name: SensorReading() for name in SENSOR_CHANNELS
                }
                self.measurement_message = "Messung wird neu verbunden."

            elif kind == "measurement_error":
                self.measurement_valid = False
                self.measurement_error = True
                self.sensor_readings = {
                    name: SensorReading(problem="DAQ-Messfehler")
                    for name in SENSOR_CHANNELS
                }
                self.measurement_message = str(payload)
                self._log(str(payload))
                if not (self.regulation_snapshot.status == "fault"
                        and self.regulation_snapshot.message.startswith("DAQ-Messfehler")):
                    self._show_error_details(
                        "Messung fehlgeschlagen",
                        f"GHF: {AI_GHF}\nGLF: {AI_GLF}\n\n{payload}\n\n"
                        "Messkanäle, Versorgung und Verbindung prüfen. Danach "
                        "'Messung neu verbinden' drücken. Manuelle Stellbefehle "
                        "bleiben nach Bestätigung möglich.",
                    )

            elif kind == "measurement_restart_done":
                self.output_busy = False
                self.output_status.configure(
                    text="Messneustart fehlgeschlagen · Details beachten"
                    if self.measurement_error else
                    "Messung gestartet · warte auf neue Messwerte",
                    text_color=COLOR_RED if self.measurement_error else COLOR_BLUE,
                )

            elif kind == "started":
                self.measurement_error = False
                self._log("Mess-Task gestartet: GHF ai0 / GLF ai1, 1.000 Hz" +
                          (" (simuliert)." if self.simulate else "."))
            # Erst dieses Ereignis berechtigt zu einer sichtbaren Erfolgsbestätigung.
            elif kind == "write_ok":
                self.output_busy = False
                self._show_written(payload)
                self.output_status.configure(text=("Simulierter Befehl verarbeitet" if self.simulate
                    else "DAQ-Write bestätigt · physikalischer Ausgangsstrom nicht gemessen"), text_color=COLOR_BLUE)
                self._log(("Simulierter Befehl: " if self.simulate else "DAQ-Write: ") +
                          ", ".join(f"{n} {number_de(p)} % / {number_de(a * 1000, 3)} mA" for n, p, a in payload))
            # Teilbestätigung ehrlich darstellen, kein Gesamt-Erfolg und kein Rollback.
            elif kind == "write_error":
                self.output_busy = False
                detail, successful = payload
                self._show_written(successful)
                self.output_status.configure(
                    text="Ausgabefehler · Eingaben korrigieren und erneut senden",
                    text_color=COLOR_RED,
                )
                confirmed = ", ".join(n for n, _, _ in successful) or "keine"
                self._log("Ausgabefehler: " + detail + " | Bestätigt: " + confirmed)
                self._show_error_details(
                    "Stellbefehl fehlgeschlagen",
                    f"{detail}\n\nBestätigte Teilbefehle: {confirmed}\n"
                    "Der tatsächliche Ausgangszustand ist nicht gemessen.\n\n"
                    "Kanaleinstellung/Verbindung prüfen, Sollwerte korrigieren "
                    "und erneut senden. Frühere Teilaufträge werden nicht "
                    "automatisch wiederholt.",
                )
            # Nur ohne gemeldete Schließfehler das Fenster endgültig zerstören.
            elif kind == "closed":
                if not payload:
                    # Genau ein Tk-Interpreter gehört dieser Anwendung. Auch noch
                    # wartende CTk-interne Zeichen-/Skalierungs-Callbacks abbrechen,
                    for callback_id in self.tk.call("after", "info"):
                        # Nur die Planung entfernen. Das jeweilige CTk-Kindwidget
                        # löscht sein registriertes Python/Tcl-Kommando beim destroy.
                        self.tk.call("after", "cancel", callback_id)
                    self.destroy()
                    return
                self.closing = False
                self.output_busy = False
                self.output_status.configure(text="Schließfehler · nur erneutes Schließen zulässig", text_color=COLOR_RED)
                self._log("Schließfehler: " + "; ".join(payload))
                self.close_button.configure(text="Schließen erneut versuchen")
        # Längeres Warten erklären, aber keinen noch aktiven Treiberaufruf gewaltsam beenden.
        if self.closing and time.monotonic() - self.shutdown_started_at > 6:
            self.output_status.configure(text="Warte auf DAQ-Treiber / Ressourcenfreigabe · noch nicht geschlossen",
                                         text_color=COLOR_ORANGE)
        # Auch ohne neue Nachricht müssen Messalter und Bedienbarkeit weiter geprüft werden.
        self._render_measurement()
        if hasattr(self, "_render_regulation_measurement"):
            self._render_regulation_measurement()
        self._notify_sensor_errors()


    def _show_error_details(self, title: str, detail: str) -> None:
        """Normaler Fehlerdialog mit OK, wie bei der Sollwertbestätigung."""
        if self.closing:
            return
        if self.confirming:
            # Keine Fehlerfenster über einen vorhandenen Dialog legen.
            self._pending_error = (title, detail)
            return

        # Sehr lange Meldungen im Terminal vollständig erhalten.
        text = detail
        if len(text) > 1200:
            print(title + "\n" + detail)
            text = text[:500] + "\n…\n" + text[-500:]
            text += "\n\nVollständige Meldung im Terminal."

        self.confirming = True
        try:
            self._refresh_controls()
            messagebox.showerror(
                title,
                text + "\n\nMit OK quittieren. Danach kannst du "
                "Einstellungen ändern und erneut versuchen.",
                parent=self,
            )
        finally:
            # Nach OK die Bedienung wieder freigeben.
            self.confirming = False
            self._refresh_controls()

        pending = getattr(self, "_pending_error", None)
        if pending is not None:
            self._pending_error = None
            self._show_error_details(*pending)

    def _notify_sensor_errors(self) -> None:
        """Aktuelle Sensorfehler einmal melden, nicht bei jedem Messpaket."""
        if (
            self.confirming or self.closing
            or self.shutdown_blocked or self.measurement_error
        ):
            return

        if not hasattr(self, "_sensor_popup_problem"):
            self._sensor_popup_problem = {}
            self._sensor_popup_clear_since = {}
            self._sensor_popup_last_seen = {}

        now = time.monotonic()
        alerts = []
        new_error = False

        for name, reading in self.sensor_readings.items():
            old_time = self._sensor_popup_last_seen.get(name, 0.0)

            # Eine Empfangspause unterbricht die fehlerfreie Beobachtungszeit.
            if (
                old_time
                and reading.received_at - old_time > MAX_MEASUREMENT_AGE_S
            ):
                self._sensor_popup_clear_since.pop(name, None)

            self._sensor_popup_last_seen[name] = reading.received_at

            # Alte Zwischenwerte aus einer aufgestauten Queue nicht melden.
            if not reading.recent(now):
                self._sensor_popup_clear_since.pop(name, None)
                continue

            if reading.valid:
                since = self._sensor_popup_clear_since.setdefault(name, now)

                # Erst nach stabiler Erholung denselben Fehler erneut melden.
                # Dadurch erzeugt Grenzpendeln keine ständigen Dialoge.
                if now - since >= 3.0:
                    self._sensor_popup_problem.pop(name, None)
                continue

            self._sensor_popup_clear_since.pop(name, None)

            if reading.current_a is None:
                # Ein leerer Startpuffer ist noch kein Bereichsfehler.
                continue

            problem = reading.problem or "Ungültiger Sensorstrom"
            alerts.append(
                f"{name}: {problem}\n"
                f"Kanal: {SENSOR_CHANNELS[name]}\n"
                f"Sensorstrom: "
                f"{number_de(reading.current_a * 1000, 6)} mA"
            )

            # Nach Kanal und Fehlergrund unterscheiden, nicht nach jedem µA.
            if self._sensor_popup_problem.get(name) != problem:
                self._sensor_popup_problem[name] = problem
                new_error = True

        if new_error:
            self._show_error_details(
                "Sensorfehler",
                "\n\n".join(alerts) +
                "\n\nDer Istwert bleibt mit Fehlerhinweis sichtbar. "
                "Manuelle Korrekturen bleiben möglich.",
            )

