"""Responsives Luftschema der Reglerseite, ausschließlich für die Darstellung.

Die Ansicht erhält fertig formatierte Zeichenketten. Sie summiert keine
Messwerte, beurteilt keine Sensoren und besitzt weder Regler noch NI-Tasks.
Auch ein inaktiver Zweig zeigt weiterhin seine übergebenen Rohmesswerte.
Die Pfeilfarbe bezeichnet den ausgewählten Regelpfad, keine gemessene Strömung.
"""

from __future__ import annotations

import math
import tkinter as tk
from dataclasses import dataclass
from tkinter import font as tkfont
from types import MappingProxyType
from typing import Mapping

from .darstellung import COLOR_DARK, FONT_FAMILY, TEXT_MUTED


_TURQUOISE = "#008C83"
_CARD_BLUE = "#EDF4FA"
_CARD_BORDER = "#C4D3E2"
_INACTIVE_BG = "#F2F4F6"
_INACTIVE_PATH = "#B2BEC9"


@dataclass(frozen=True)
class BranchDisplay:
    """Bereits formatierter Inhalt einer GHF-/GLF-Karte, Einheiten inklusive."""

    target: str
    actual: str
    current: str
    age: str
    color: str = COLOR_DARK


class AirflowDiagram(tk.Canvas):
    """FU links, zwei Mess-/Regelzweige mittig und die Gesamtauswertung rechts.

    Das umgebende Grid bestimmt die tatsächliche Größe. 215 Pixel sind die
    gewünschte Anfangshöhe; Koordinaten und Pixelfonts folgen der Canvas-Größe.
    Fonts werden ausdrücklich an das vorhandene Tk-Fenster gebunden, damit
    Linux und Windows dieselben Schriftgrößen sinnvoll darstellen.
    """

    def __init__(self, parent):
        super().__init__(parent, height=215, width=100, background="#F6F9FD",
                         highlightthickness=0, borderwidth=0)
        self._draw_job: str | None = None
        self._fonts: dict[tuple[str, int], tkfont.Font] = {}
        self.display_model: Mapping[str, object] = MappingProxyType({
            "mode": "BEIDE", "active_branches": frozenset(),
            "readings": MappingProxyType({}), "fu_text": "—",
            "actual": "— m³/h", "target": "— m³/h", "error": "— m³/h",
            "caption": "Noch kein Regellauf gestartet.", "total_color": COLOR_DARK,
            "fixed_valves": False,
        })
        self.bind("<Configure>", self._schedule_draw, add="+")
        self.bind("<Destroy>", self._cancel_draw, add="+")

    def update_display(self, *, mode: str, active_branches: set[str],
                       readings: Mapping[str, BranchDisplay], fu_text: str,
                       actual: str, target: str, error: str, caption: str,
                       total_color: str = COLOR_DARK, fixed_valves: bool = False) -> None:
        # Unabhängige Lesekopien verhindern, dass spätere Änderungen eines
        # Aufrufer-Wörterbuchs den Inhalt während einer Zeichnung verändern.
        self.display_model = MappingProxyType({
            "mode": mode, "active_branches": frozenset(active_branches),
            "readings": MappingProxyType(dict(readings)), "fu_text": fu_text,
            "actual": actual, "target": target, "error": error,
            "caption": caption, "total_color": total_color, "fixed_valves": fixed_valves,
        })
        self._schedule_draw()

    def _schedule_draw(self, _event=None) -> None:
        # Mehrere Messpakete oder Resize-Ereignisse im selben GUI-Durchlauf
        # benötigen nur eine Zeichnung. Keine eigene Erfassungs-/Zeit-Schleife.
        if self._draw_job is None:
            self._draw_job = self.after_idle(self._draw)

    def _cancel_draw(self, event) -> None:
        if event.widget is self and self._draw_job is not None:
            self.after_cancel(self._draw_job)
            self._draw_job = None

    def _font(self, role: str, pixels: int) -> tkfont.Font:
        pixels = max(8, int(pixels))
        key = (role, pixels)
        if key not in self._fonts:
            self._fonts[key] = tkfont.Font(
                root=self.winfo_toplevel(), family=FONT_FAMILY, size=-pixels,
                weight="bold" if role in ("heading", "value") else "normal",
            )
        return self._fonts[key]

    def _text(self, x: float, y: float, text: str, *, size: float,
              width: float, role: str = "body", anchor: str = "center",
              color: str = COLOR_DARK, truncate: bool = False) -> None:
        # Zahlen behalten ihre vollständige Zeichenfolge. Erst die Schrift
        # verkleinern, dann bei sehr knappen Fenstern an Leerzeichen umbrechen.
        # Nur der ergänzende Erklärungssatz darf mit Auslassung enden.
        pixels = max(9, round(size))
        font = self._font(role, pixels)
        while pixels > 9 and font.measure(text) > width:
            pixels -= 1
            font = self._font(role, pixels)
        if truncate and font.measure(text) > width:
            shortened = text
            while shortened and font.measure(shortened + "…") > width:
                shortened = shortened[:-1]
            text = shortened + "…"
        self.create_text(x, y, text=text, font=font, anchor=anchor,
                         fill=color, width=max(1, width), justify="left" if anchor == "w" else "center")

    def _box(self, left: float, top: float, right: float, bottom: float,
             *, active: bool = True, radius: float = 8) -> None:
        r = min(radius, (bottom - top) / 4, (right - left) / 4)
        self.create_polygon(
            left + r, top, right - r, top, right, top, right, top + r,
            right, bottom - r, right, bottom, right - r, bottom,
            left + r, bottom, left, bottom, left, bottom - r,
            left, top + r, left, top,
            smooth=True, splinesteps=24,
            fill=_CARD_BLUE if active else _INACTIVE_BG,
            outline=_CARD_BORDER, width=1,
        )

    def _fan(self, cx: float, cy: float, radius: float, *, active: bool) -> None:
        """Gezeichnetes Lüftersymbol; kein Bildasset und keine Scheinanimation."""
        self.create_oval(cx - radius, cy - radius, cx + radius, cy + radius,
                         fill=_TURQUOISE if active else _INACTIVE_PATH, outline="")
        for angle in (0, 120, 240):
            points = []
            for length, offset in ((0.12, -25), (0.76, -20), (0.85, 17), (0.23, 52)):
                direction = math.radians(angle + offset)
                points.extend((cx + radius * length * math.cos(direction),
                               cy + radius * length * math.sin(direction)))
            self.create_polygon(*points, smooth=True, fill="#FFFFFF", outline="")
        self.create_oval(cx - radius * .12, cy - radius * .12,
                         cx + radius * .12, cy + radius * .12,
                         fill="#FFFFFF", outline="")

    def _draw(self) -> None:
        self._draw_job = None
        width, height = self.winfo_width(), self.winfo_height()
        if width < 120 or height < 70:
            return
        self.delete("all")
        model = self.display_model
        active = model["active_branches"]
        mode = model["mode"]
        readings = model["readings"]
        # Der Schriftmaßstab wächst nicht unbegrenzt mit einem maximierten
        # Fenster. Dadurch bleiben Schema und darunterliegende Trends ruhig.
        scale = max(.78, min(width / 1180, height / 215, 1.15))
        wide = width >= 1180
        # Die normale Ansicht folgt den Proportionen der vorhandenen Vorlage.
        # Erst bei kleiner Breite erhält die dicht belegte Zweigkarte mehr Platz.
        fu_left, fu_right = (.015 * width, .225 * width) if wide else (.014 * width, .200 * width)
        branch_left, branch_right = (.29 * width, .74 * width) if wide else (.255 * width, .765 * width)
        total_left, total_right = (.82 * width, .985 * width) if wide else (.825 * width, .987 * width)
        center_y = .475 * height
        row_limits = {"GHF": (.065 * height, .415 * height),
                      "GLF": (.535 * height, .885 * height)}

        # Inaktive Segmente zuerst zeichnen. Gemeinsame Stücke des gewählten
        # Pfads bleiben dadurch türkis, auch wenn der zweite Zweig grau ist.
        for name in sorted(row_limits, key=lambda item: item in active):
            top, bottom = row_limits[name]
            middle = (top + bottom) / 2
            color = _TURQUOISE if name in active else _INACTIVE_PATH
            pen = {"fill": color, "width": max(1.2, (2.3 if name in active else 1.5) * scale),
                   "arrow": "last", "arrowshape": (7 * scale, 9 * scale, 4 * scale),
                   "capstyle": "round", "joinstyle": "round"}
            if name not in active:
                pen["dash"] = (3, 4)
            split = (fu_right + branch_left) / 2
            merge = (branch_right + total_left) / 2
            self.create_line(fu_right, center_y, split, center_y, split, middle,
                             branch_left - 3, middle, **pen)
            self.create_line(branch_right, middle, merge, middle, merge, center_y,
                             total_left - 3, center_y, **pen)

        # FU-Karte mit gemeinsamem Lüfter. fu_text benennt ausschließlich den
        # vom Aufrufer gelieferten Befehl, keinen hier angenommenen Istzustand.
        self._box(fu_left, .295 * height, fu_right, .665 * height,
                  active=bool(active), radius=8 * scale)
        fan_x = fu_left + (36 if wide else 23) * scale
        fan_radius = (24 if wide else 15) * scale
        self._fan(fan_x, center_y, fan_radius, active=bool(active))
        fu_text_x = fu_left + (72 if wide else 46) * scale
        fu_text_width = max(30, fu_right - fu_text_x - 9 * scale)
        self._text(fu_text_x, center_y - 16 * scale,
                   "FU · Gemeinsamer Lüfter" if wide else "FU · Lüfter", size=15 * scale,
                   width=fu_text_width, role="heading", anchor="w")
        self._text(fu_text_x, center_y + 7 * scale, model["fu_text"], size=12 * scale,
                   width=fu_text_width, anchor="w", color=TEXT_MUTED)

        for name, (top, bottom) in row_limits.items():
            selected = name in active
            self._box(branch_left, top, branch_right, bottom,
                      active=selected, radius=8 * scale)
            card_width, card_height = branch_right - branch_left, bottom - top
            branch = readings.get(name, BranchDisplay("—", "—", "—", "—", TEXT_MUTED))
            self._text(branch_left + 12 * scale, top + .39 * card_height, name,
                       size=21 * scale, width=.155 * card_width, role="heading", anchor="w")
            role = ("Grundlast" if name == "GHF" else "Feinregelung") if mode == "BEIDE" else "Einzelregelung"
            if model["fixed_valves"]:
                role = "Schieber fest"
            elif not selected:
                role = "nicht verwendet"
            elif mode == "BEIDE" and name == "GLF" and "GHF" not in active:
                role = "Teilbetrieb"
            self._text(branch_left + 12 * scale, top + .76 * card_height, role,
                       size=11 * scale, width=.16 * card_width, anchor="w", color=TEXT_MUTED)
            # Vier feste Spalten: Die größere Istwert-Spalte erhält mehr Platz.
            # Auch Fehlerströme mit sechs Nachkommastellen passen bei 1024 px.
            reference_label = "Stellbefehl" if model["fixed_valves"] else "Teilsoll"
            columns = ((.18, .38, reference_label, branch.target, 13, "body"),
                       (.38, .61, "Istwert", branch.actual, 22, "value"),
                       (.61, .85, "Sensorstrom", branch.current, 13, "body"),
                       (.85, 1.0, "Alter", branch.age, 12, "body"))
            for begin, end, label, value, size, font_role in columns:
                x = branch_left + (begin + end) / 2 * card_width
                column_width = (end - begin) * card_width - 8 * scale
                self._text(x, top + .25 * card_height, label, size=11 * scale,
                           width=column_width, color=TEXT_MUTED)
                # Ein inaktiver Sensorfehler bleibt farbig sichtbar. Nur der
                # Pfad ist inaktiv; sein tatsächlich übergebener Rohwert nicht.
                value_color = TEXT_MUTED if label == "Teilsoll" and not selected else branch.color
                self._text(x, top + .66 * card_height, value, size=size * scale,
                           width=column_width, role=font_role, color=value_color)

        # Wie in der Vorlage: Titel links, darunter drei ruhige Zeilen mit
        # Bezeichnung links und rechtsbündigem Wert. Beide Textfelder erhalten
        # getrennte Breiten, damit auch die kompakte Ansicht nicht kollidiert.
        total_top, total_bottom = .075 * height, .885 * height
        self._box(total_left, total_top, total_right, total_bottom, radius=8 * scale)
        inner_left = total_left + 10 * scale
        inner_right = total_right - 10 * scale
        inner_width = inner_right - inner_left
        label_width = inner_width * .43
        value_width = inner_width - label_width - 6 * scale
        self._text(inner_left, total_top + 17 * scale, "Gesamt", size=18 * scale,
                   width=inner_width, role="heading", anchor="w")
        total_height = total_bottom - total_top
        for fraction, label, value, size in (
                (.36, "Istwert", model["actual"], 15),
                (.60, "Sollwert", model["target"], 12),
                (.82, "Abweichung", model["error"], 12)):
            y = total_top + fraction * total_height
            self._text(inner_left, y, label, size=11 * scale,
                       width=label_width, color=TEXT_MUTED, anchor="w")
            self._text(inner_right, y, value, size=size * scale,
                       width=value_width, role="value" if label == "Istwert" else "body", anchor="e",
                       color=model["total_color"] if label != "Sollwert" else COLOR_DARK)

        self._text(.52 * width, .955 * height, model["caption"], size=11 * scale,
                   width=.93 * width, color=TEXT_MUTED, truncate=True)
