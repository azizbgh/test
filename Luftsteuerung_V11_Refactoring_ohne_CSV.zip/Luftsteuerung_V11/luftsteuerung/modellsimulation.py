"""Lokale V11-Modellsimulation mit FU-Kandidat, ausdrücklich ohne NI-Ausgaben.

Dieser Adapter verbindet die vorhandene GUI-/Worker-Schnittstelle mit dem aus
Einzelstellversuchen identifizierten LocalPlant. Es ist weder ein vollständiges
Anlagenmodell noch ein zum Hardwarebetrieb freigegebener neuer Regler. Die
lineare Überlagerung der Einzelpfade bleibt eine Modellannahme.

Der Kandidat PrimaryFlowPI regelt hier ausschließlich den FU. Beide Schieber
bleiben an den Modell-Bezugspunkten. Ihre im Snapshot angezeigten Mengen sind
Referenzanteile und keine unabhängig geregelten Schiebersollwerte.
"""

from __future__ import annotations

import copy
from dataclasses import asdict
import math
import time
from types import MappingProxyType
from typing import Mapping

from .anlagenmodell import LocalPlant, OPERATING_BOUNDS
from .hardware import SimulatedDaqController
from .kennlinien import ghf_amp_to_m3h, glf_amp_to_m3h, stellstrom_zu_prozent, validate_current
from .konfiguration import GHF_SENSOR_FACTOR, GLF_SENSOR_FACTOR, SENSOR_ZERO_A, INPUTS, OUTPUTS
from .messwerte import SensorReading
from .fu_regler import Parameters, PrimaryFlowPI
from .regelung import GLF_RELIABLE_MIN_M3H, RegulationSettings, RegulationSnapshot


_TOLERANCE = 1e-9
_HOLD = " · Modellregelung angehalten, letzte bestätigte Befehle gehalten."
MAX_CANDIDATE_FU_RATE_PERCENT_S = 1.0


def _finite(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{name}: Eine endliche Zahl ist erforderlich.")
    return float(value)


class ModelDaqController(SimulatedDaqController):
    """Software-DAQ mit fester Modellschrittweite und echter verstrichener Zeit.

    ``model`` ist genau ein Eintrag aus ``identifikation.json[\"models\"]``.
    Eine injizierte monotone Uhr erleichtert reproduzierbare Softwareprüfungen;
    im normalen GUI-Betrieb wird time.monotonic verwendet. Keine Methode hier
    erzeugt einen nidaqmx-Task oder importiert den NI-Treiber.
    """

    def __init__(self, point: str, model: Mapping, parameters: Parameters, *,
                 dt: float = 0.1, variant: str = "train", clock=None):
        super().__init__()
        if point not in OPERATING_BOUNDS:
            raise ValueError("Modellpunkt muss B oder C sein.")
        dt = _finite(dt, "Modellschrittweite")
        if not 0 < dt <= 1:
            raise ValueError("Modellschrittweite muss größer 0 und höchstens 1 s sein.")
        if not isinstance(parameters, Parameters):
            raise ValueError("Der FU-Kandidat benötigt ein Parameters-Objekt.")
        for name in ("kp", "ti", "feedforward", "split_gain"):
            _finite(getattr(parameters, name), f"Kandidat {name}")
        if parameters.kp < 0 or parameters.ti <= 0 or not 0 <= parameters.feedforward <= 1:
            raise ValueError("Kandidatenparameter außerhalb der unterstützten Werte.")
        if parameters.split_gain != 0:
            raise ValueError("Die GUI-Modellsimulation unterstützt nur den FU-Kandidaten mit split_gain=0.")
        # Die Kopie schützt einen laufenden Versuch vor nachträglichem Ändern
        # des vom Aufrufer geladenen JSON-Wörterbuchs.
        self.model = copy.deepcopy(dict(model))
        if len(self.model.get("u0", ())) != 3 or len(self.model.get("y0", ())) != 2:
            raise ValueError("Das Modell benötigt drei Eingangs- und zwei Ausgangsbezugswerte.")
        for name, value in zip(INPUTS, self.model["u0"]):
            _finite(value, f"Modellbezug {name}")
        for name, value in zip(OUTPUTS, self.model["y0"]):
            if _finite(value, f"Modellmessbezug {name}") <= 0:
                raise ValueError("Modellmessbezüge müssen größer 0 sein.")
        for actuator in INPUTS:
            for sensor in OUTPUTS:
                try:
                    path = self.model["paths"][f"{actuator}->{sensor}"]
                    _finite(path["K"], "Modellverstärkung")
                    tau = _finite(path["T"], "Modellzeitkonstante")
                    delay = _finite(path["L"], "Modelltotzeit")
                    if tau <= 0 or not 0 <= delay <= 60:
                        raise ValueError("Modellzeitkonstanten müssen positiv, Totzeiten innerhalb 0–60 s sein.")
                except KeyError as exc:
                    raise ValueError(f"Modellpfad {actuator}->{sensor} ist unvollständig.") from exc
        nominal_fu_gain = sum(self.model["paths"][f"FU->{sensor}"]["K"] for sensor in OUTPUTS)
        if nominal_fu_gain <= 0:
            raise ValueError("Für den FU-Kandidaten muss die FU-Gesamtverstärkung positiv sein.")

        self.model_point = point
        self.initial_percent = dict(zip(INPUTS, map(float, self.model["u0"])))
        self.plant = LocalPlant(point, self.model, dt, tuple(self.initial_percent.values()), variant)
        self._commands = list(self.initial_percent.values())
        self._dt = dt
        self._clock = time.monotonic if clock is None else clock
        self._last_wall_at = _finite(self._clock(), "Modelluhr")
        self._remainder = 0.0
        self._closed = False

        # Diese Grenzen gelten NUR für feste u0-Schieber. Sie sind keine
        # Extrapolation des Modells auf 12–549 m³/h oder auf neue Ventilstellungen.
        gain = sum(path[2] for path in self.plant.paths if path[0] == 0)
        if gain <= 0:
            raise ValueError("Die Modellvariante hat keine positive FU-Gesamtverstärkung.")
        total = sum(self.model["y0"])
        fu0 = self.initial_percent["FU"]
        self.target_range = tuple(total + gain * (bound - fu0) for bound in self.plant.bounds[0])
        self.model_metadata = {
            "measurement_source": "local_model", "model_point": point,
            "model_variant": variant, "model_step_s": dt,
            "candidate": "PrimaryFlowPI", "candidate_parameters": asdict(parameters),
            "command_bounds_percent": dict(zip(INPUTS, self.plant.bounds)),
            "fixed_schieber_percent": {name: self.initial_percent[name] for name in OUTPUTS},
            "target_range_m3h": self.target_range,
            "hardware_validation": False,
            "model_assumption": "Lokale lineare Überlagerung identifizierter Einzelpfade; keine Hardwarefreigabe.",
        }
        self.offline_regulator = ModelRegulator(self, parameters)

    def validate_model_command(self, name: str, percent: float) -> float:
        """Vor einem ganzen Worker-Auftrag prüfbar; verändert keinen Zustand.

        Nur Rundungsreste innerhalb 1e-9 an einer Grenze werden kanonisiert.
        Ein fachlich außerhalb liegender Befehl wird niemals still begrenzt und
        anschließend als unverändert bestätigter Wunsch dargestellt.
        """
        if name not in INPUTS:
            raise ValueError(f"Unbekannter Modellausgang {name}.")
        value = _finite(percent, name)
        lower, upper = self.plant.bounds[INPUTS.index(name)]
        if not lower - _TOLERANCE <= value <= upper + _TOLERANCE:
            raise ValueError(f"Modell {self.model_point}: {name} muss innerhalb {lower:g}–{upper:g} % bleiben.")
        return max(lower, min(upper, value))

    def _advance(self) -> None:
        """Verstrichene monotone Zeit in feste, begrenzte Modellschritte umsetzen."""
        now = _finite(self._clock(), "Modelluhr")
        elapsed = now - self._last_wall_at
        if elapsed < -_TOLERANCE:
            raise RuntimeError("Die monotone Modelluhr ist rückwärts gelaufen.")
        self._last_wall_at = now
        self._remainder += max(0.0, elapsed)
        steps = int((self._remainder + self._dt * 1e-10) / self._dt)
        if not steps:
            return
        self._remainder = max(0.0, self._remainder - steps * self._dt)
        command = tuple(self._commands)
        # Nach max. Totzeit plus Nachbarsample sind ausschließlich die gerade
        # gehaltenen Befehle in allen verzögerten Pfaden angekommen. Weitere
        # identische PT1-Schritte können exakt zusammengefasst werden. So bleibt
        # selbst nach einer langen Fenster-/Systempause der Aufwand beschränkt.
        warmup = min(steps, self.plant.history.maxlen)
        for _ in range(warmup):
            self.plant.advance(command)
        remaining = steps - warmup
        if remaining:
            for index, (i, _, gain, alpha, _, _) in enumerate(self.plant.paths):
                target = gain * (command[i] - self.plant.u0[i])
                self.plant.states[index] = target + (self.plant.states[index] - target) * (1 - alpha) ** remaining
            self.plant.history.clear()
            self.plant.history.extend([command] * self.plant.history.maxlen)

    def start_measurement(self) -> None:
        """Den Software-Messauftrag starten; der Modellzustand bleibt erhalten."""
        if self._closed:
            raise RuntimeError("Diese Modellsitzung ist bereits geschlossen.")
        if self.measurement_task is not None:
            raise RuntimeError("Der Modell-Messauftrag existiert bereits.")
        self._advance()
        self.measurement_task = object()
        self.started_at = self._clock()

    def read_currents(self) -> tuple[float, float]:
        """GHF-/GLF-Modellwerte als Sensorströme in Ampere zurückgeben."""
        if self.measurement_task is None or self._closed:
            raise RuntimeError("Es läuft kein Modell-Messauftrag.")
        self._advance()
        ghf, glf = self.plant.measure()
        if not all(math.isfinite(value) for value in (ghf, glf)):
            raise RuntimeError("Das lokale Modell lieferte keinen endlichen Durchfluss.")
        return SENSOR_ZERO_A + ghf * GHF_SENSOR_FACTOR, SENSOR_ZERO_A + glf * GLF_SENSOR_FACTOR

    def write_current(self, name: str, current_a: float) -> None:
        """Einen geprüften Sollstrom nur im lokalen Softwaremodell bestätigen."""
        if self._closed:
            raise RuntimeError("Eine geschlossene Modellsitzung nimmt keine Befehle an.")
        current_a = validate_current(current_a)
        percent = stellstrom_zu_prozent(name, current_a)
        percent = self.validate_model_command(name, percent)
        self._advance()
        # Die Zeit bis zum Aufruf gehört noch zum vorherigen Befehl. Der neue
        # Befehl wirkt erst in folgenden Modellschritten auf die Strecke.
        super().write_current(name, current_a)
        self._commands[INPUTS.index(name)] = percent

    def close_tasks(self) -> list[str]:
        """Modell freigeben, ohne einen außerhalb liegenden 4-mA-Punkt anzufahren."""
        if not self._closed:
            try:
                self._advance()
            except Exception as exc:
                # Es gibt keine elektrische Ressource. Eine kaputte Modelluhr
                # darf deshalb das Schließen des Fensters nicht verriegeln.
                self.model_metadata["close_warning"] = str(exc)
        self._closed = True
        self.output_tasks.clear()
        self.measurement_task = None
        return []


class ModelRegulator:
    """Worker-Adapter des vorhandenen PrimaryFlowPI für einen lokalen Modellpunkt."""

    def __init__(self, controller: ModelDaqController, parameters: Parameters):
        self.controller = controller
        self.parameters = parameters
        self.settings: RegulationSettings | None = None
        self.status = "idle"
        self._primary: PrimaryFlowPI | None = None
        self._confirmed: dict[str, float] = {}
        self._branch_targets = {"GHF": 0.0, "GLF": 0.0}
        self._started_at = self._last_step_at = 0.0
        self._elapsed = 0.0
        self._measured = self._error = None
        self._within = False
        self._message = f"Lokale Modellsimulation {controller.model_point} bereit."
        self._warning = ("Nur lokales Modell; FU-Kandidat mit festen Schiebern. "
                         "Referenzanteile sind keine getrennten Schieberregelziele; keine Hardwarefreigabe.")

    def start(self, settings: RegulationSettings, outputs_percent: Mapping[str, float], now: float) -> None:
        """Einen lokalen BEIDE-Lauf mit bestätigten Prozentbefehlen starten.

        now ist die absolute monotone Workerzeit in Sekunden. Zielbereich,
        FU-Änderungsrate und feste Schieber werden vor jeder Zustandsänderung
        geprüft; die eigentliche PI-Berechnung bleibt im gemeinsamen Kandidaten.
        """
        settings.validate()
        now = _finite(now, "Reglerstartzeit")
        if settings.mode != "BEIDE":
            raise ValueError("Der lokale FU-Kandidat unterstützt ausschließlich BEIDE.")
        if not settings.fu_follow:
            raise ValueError("Der lokale Kandidat regelt den FU; FU-Nachführung muss eingeschaltet sein.")
        lower, upper = self.controller.target_range
        if not lower - _TOLERANCE <= settings.setpoint_m3h <= upper + _TOLERANCE:
            raise ValueError(f"Modell {self.controller.model_point}: Sollwert muss innerhalb {lower:.3f}–{upper:.3f} m³/h bleiben.")
        if settings.fu_rate_percent_s > MAX_CANDIDATE_FU_RATE_PERCENT_S + _TOLERANCE:
            raise ValueError("Der lokale FU-Kandidat ist auf höchstens 1 Prozentpunkt/s begrenzt.")
        if set(outputs_percent) != set(INPUTS):
            raise ValueError("Vor dem Modell-Reglerstart müssen alle drei Ausgangsbefehle bestätigt sein.")
        confirmed = {name: self.controller.validate_model_command(name, outputs_percent[name]) for name in INPUTS}
        for name in OUTPUTS:
            if abs(confirmed[name] - self.controller.initial_percent[name]) > _TOLERANCE:
                raise ValueError(f"Der FU-Kandidat hält {name} fest auf {self.controller.initial_percent[name]:g} %. "
                                 "Zuerst den Modell-Bezugspunkt wiederherstellen.")
        self.settings = settings
        self.status = "running"
        self._confirmed = confirmed
        # PrimaryFlowPI besitzt die einzigen Anlauf-/Messbereichs-/GLF-Timer.
        # None fordert dort eine erst mit dem ersten qualifizierten Istpaket
        # initialisierte Vorsteuerung an; y0 wird nicht als Messung ausgegeben.
        self._primary = PrimaryFlowPI(self.parameters, self.controller.model,
            self.controller.plant.bounds, tuple(confirmed[name] for name in INPUTS), None, settings)
        self._started_at = self._last_step_at = now
        self._elapsed = 0.0
        self._measured = self._error = None
        self._within = False
        self._message = "FU-Modellkandidat aktiv · Vorsteuerung wartet auf erstes qualifiziertes Messpaket."
        nominal_total = sum(self.controller.model["y0"])
        self._branch_targets = {
            name: settings.setpoint_m3h * reference / nominal_total
            for name, reference in zip(OUTPUTS, self.controller.model["y0"])
        }

    def acknowledge(self, outputs_percent: Mapping[str, float]) -> None:
        """Tatsächlich bestätigte Prozentbefehle einschließlich Teilerfolgen merken."""
        confirmed = {name: self.controller.validate_model_command(name, value)
                     for name, value in outputs_percent.items()}
        self._confirmed.update(confirmed)
        if self._primary is not None and set(self._confirmed) == set(INPUTS):
            # Ein berechneter, aber nicht vollständig geschriebener Auftrag ist
            # kein neuer Ausgangszustand. Teilbestätigungen bleiben trotzdem wahr.
            self._primary.outputs = tuple(self._confirmed[name] for name in INPUTS)

    def stop(self, reason: str = "Modellregelung gestoppt · letzte bestätigte Befehle gehalten.") -> None:
        """Weitere Regelschritte stoppen, ohne die Modell-Ausgänge zurückzustellen."""
        self.status = "stopped"
        self._message = reason
        self._within = False
        if self._primary is not None:
            self._primary.status = "stopped"
            self._primary.outputs = tuple(self._confirmed[name] for name in INPUTS)

    def fault(self, reason: str) -> None:
        """Fehlerzustand veröffentlichen und bestätigte Modellbefehle halten."""
        self.status = "fault"
        self._message = reason if reason.endswith(_HOLD) else reason + _HOLD
        self._within = False
        if self._primary is not None:
            self._primary.outputs = tuple(self._confirmed[name] for name in INPUTS)
            self._primary.fault(reason)

    def step(self, readings: Mapping[str, SensorReading], now: float) -> dict[str, float]:
        """Worker-Messpakete an den Kandidaten übergeben und Prozentabsichten liefern.

        Sensorströme werden in m³/h und Zeitstempel in relative Sekunden
        umgerechnet. Ein gestoppter oder fehlerhafter Lauf liefert {} und
        fordert damit keine weitere Ausgabe an. Ein Ergebnis ist erst nach
        acknowledge ein bestätigter Ausgangsbefehl.
        """
        if self.status != "running":
            return {}
        assert self.settings is not None
        cfg = self.settings
        try:
            now = _finite(now, "Reglerzeit")
            if now < self._last_step_at:
                raise ValueError("Die Modell-Reglerzeit läuft rückwärts.")
            dt = now - self._last_step_at
            self._last_step_at = now
            self._elapsed = now - self._started_at
            self._measured = self._error = None
            self._within = False
            y = []
            local_readings = {}
            for name, convert in (("GHF", ghf_amp_to_m3h), ("GLF", glf_amp_to_m3h)):
                reading = readings.get(name)
                if not isinstance(reading, SensorReading) or not reading.valid:
                    raise ValueError(f"{name}: Modellmesswert fehlt oder ist ungültig.")
                if not 0 <= now - reading.received_at <= cfg.max_measurement_age_s:
                    raise ValueError(f"{name}: Modellmesswert veraltet oder Zeitstempel ungültig.")
                y.append(convert(reading.current_a))
                # PrimaryFlowPI stammt aus dem Offline-Lauf und benutzt eine
                # relative Versuchszeit. Den Zeitstempel entsprechend umsetzen,
                # ohne sein wirkliches Alter durch einen frischen Stempel zu löschen.
                local_readings[name] = SensorReading(reading.current_a,
                    reading.received_at - self._started_at, reading.problem)
            self._measured = sum(y)
            self._error = cfg.setpoint_m3h - self._measured
            qualified = y[0] >= cfg.ghf_min_m3h and y[1] >= GLF_RELIABLE_MIN_M3H
            self._within = qualified and abs(self._error) <= cfg.tolerance_m3h
            assert self._primary is not None
            command = self._primary.step(tuple(y), local_readings, self._elapsed, dt)
            if self._primary.status == "fault":
                self.fault(self._primary.reason)
                return {}
            desired = {name: self.controller.validate_model_command(name, value)
                       for name, value in zip(INPUTS, command)}
            if any(abs(desired[name] - self.controller.initial_percent[name]) > _TOLERANCE for name in OUTPUTS):
                raise ValueError("Der FU-Kandidat darf die festen Modell-Schieber nicht verändern.")
            self._message = ("FU-Modellkandidat aktiv · Schieber fest am lokalen Bezugspunkt." if qualified
                             else "Modellregelung hält · qualifiziertes Messpaket abwarten.")
            return desired
        except (ValueError, TypeError, OverflowError) as exc:
            self.fault(str(exc))
            return {}

    def snapshot(self) -> RegulationSnapshot:
        """Eine unveränderliche GUI-/Protokollansicht mit bestätigten Befehlen bilden."""
        return RegulationSnapshot(
            status=self.status, mode="BEIDE" if self.settings is not None else "",
            setpoint_m3h=None if self.settings is None else self.settings.setpoint_m3h,
            measured_total_m3h=self._measured,
            branch_setpoints=MappingProxyType(self._branch_targets.copy()),
            outputs_percent=MappingProxyType(self._confirmed.copy()),
            error_m3h=self._error, elapsed_s=self._elapsed, message=self._message,
            warning=self._warning, within_tolerance=self._within,
        )
