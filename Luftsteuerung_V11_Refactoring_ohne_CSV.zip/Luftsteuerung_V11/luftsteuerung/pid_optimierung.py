"""Reproduzierbarer A/B-Vergleich. Diese Reglerkandidaten sprechen keine Hardware an."""

from __future__ import annotations

import argparse
from dataclasses import asdict, replace
from itertools import product
import json
from pathlib import Path
import random

from .anlagenmodell import LocalPlant, OPERATING_BOUNDS, clamp
from .konfiguration import GHF_SENSOR_FACTOR, GLF_SENSOR_FACTOR, SENSOR_ZERO_A, INPUTS, OUTPUTS
from .fu_regler import Parameters, PrimaryFlowPI
from .messwerte import evaluate_sensor_currents
from .regelung import GLF_RELIABLE_MIN_M3H, PIDGains, RegulationController, RegulationSettings


# Kompatibilität: Beide bislang hier definierten Namen werden weiterhin
# importiert und angeboten. Die einzige Reglerimplementierung liegt jetzt in
# fu_regler; dieses Modul organisiert nur Szenarien, Bewertung und Vergleich.


def scenarios(models):
    """Anstiegs-/Absenkszenarien innerhalb der vorhandenen Modellpunkte bilden."""
    result = []
    for point, model in models.items():
        u0 = model["u0"]
        target = sum(model["y0"])
        result.append((point, "Anstieg", tuple(u0), target + 10))
        preloaded = (u0[0] + 4, *u0[1:])
        result.append((point, "Absenken", preloaded, target + 3))
    return result


def simulate(models, scenario, parameters=None, *, variant="train", noise=0., invalid_at=None,
             a_scale=(1., 1., 1.)):
    """Einen Softwareversuch rechnen und Fehler, Zeiten sowie Stellwege auswerten.

    parameters=None wählt den bisherigen Zweigregler als A-Vergleich. Ein
    Parameters-Satz wählt den gemeinsamen FU-Kandidaten B. Istwerte und
    Abweichungen verwenden m³/h, Zeiten Sekunden und Stellwege Prozentpunkte.
    """
    point, name, initial, target = scenario
    dt = .1
    model = models[point]
    plant = LocalPlant(point, model, dt, initial, variant)
    initial_total = sum(plant.measure())
    cfg = RegulationSettings("BEIDE", target)
    if parameters is None:
        kc_scale, ti_scale, td_scale = a_scale
        def scaled(gains):
            return PIDGains(gains.kc * kc_scale, gains.ti_minutes * ti_scale,
                            gains.td_minutes * td_scale)
        cfg = replace(cfg, ghf_gains=scaled(cfg.ghf_gains), glf_gains=scaled(cfg.glf_gains))
        controller = RegulationController()
        controller.start(cfg, dict(zip(INPUTS, initial)), 0)
    else:
        controller = PrimaryFlowPI(parameters, model, plant.bounds, initial, initial_total, cfg)
    state = initial
    actual, movements, clipped, first_fault = [], [0., 0., 0.], 0, None
    jitter = random.Random(59)
    for tick in range(601):
        t = tick * dt
        y = plant.measure()
        actual.append(sum(y))
        measured = tuple(value + noise * jitter.gauss(0, 1) for value in y)
        readings = evaluate_sensor_currents((
            SENSOR_ZERO_A + GHF_SENSOR_FACTOR * measured[0],
            None if invalid_at is not None and t >= invalid_at
            else SENSOR_ZERO_A + GLF_SENSOR_FACTOR * measured[1],
        ), t)
        if parameters is None:
            desired = controller.step(readings, t)
            proposed = tuple(desired[c] for c in INPUTS) if desired else state
            command = tuple(clamp(u, bounds) for u, bounds in zip(proposed, plant.bounds))
            clipped += int(proposed != command)
            if desired:
                controller.acknowledge(dict(zip(INPUTS, command)))
            status = controller.snapshot().status
        else:
            command = controller.step(measured, readings, t, dt)
            status = controller.status
        if tick and first_fault is None and status == "fault":
            first_fault = t
        for i, (before, after) in enumerate(zip(state, command)):
            movements[i] += abs(before - after)
        plant.advance(command)
        state = command

    error = [y - target for y in actual]
    misses = [i for i, e in enumerate(error) if abs(e) > cfg.tolerance_m3h]
    settled = (misses[-1] + 1) * dt if misses else 0.
    return {
        "point": point, "scenario": name, "variant": variant, "noise_sigma_m3h": noise,
        "settled_s": settled if settled <= 60 else None,
        "in_band_30_to_60": all(abs(e) <= cfg.tolerance_m3h for e in error[300:]),
        "fault_s": first_fault,
        "overshoot_m3h": max(0., max(error) if target >= initial_total else -min(error)),
        "undershoot_after_first_entry_m3h": max(
            [0.] + [-(e if target >= initial_total else -e)
                     for e in error[next((i for i,e in enumerate(error) if abs(e) <= cfg.tolerance_m3h), len(error)):]]),
        "iae_m3h_s": dt * sum(abs(e) for e in error),
        "travel_percent": dict(zip(INPUTS, movements)),
        "local_clip_samples": clipped,
        "end_commands": dict(zip(INPUTS, state)),
        "end_flow": actual[-1],
    }


def score(results):
    """Modellversuche für die Suche bewerten; ein Score ist keine Anlagenfreigabe."""
    return sum(700 * (not r["in_band_30_to_60"] or r["fault_s"] is not None)
               + r["iae_m3h_s"] + 15 * r["overshoot_m3h"]
               + .5 * sum(r["travel_percent"].values()) for r in results)


def compare(models):
    """Parametersätze suchen und denselben ausgewählten Kandidaten erneut prüfen."""
    cases = scenarios(models)
    candidates = [Parameters(*values) for values in
                  product((.05, .12, .22), (4., 8., 14.), (0., .7, 1.), (0., .25))]
    ranked = sorted(((score([simulate(models, case, p) for case in cases]), p)
                     for p in candidates), key=lambda row: row[0])
    selected = ranked[0][1]
    best_no_feedforward = next(p for _, p in ranked if p.feedforward == 0)
    a_candidates = list(product((.5, 1., 1.5), (.7, 1., 1.5), (0., 1.)))
    a_selected = min(a_candidates,
                     key=lambda s: score([simulate(models, case, a_scale=s) for case in cases]))
    evaluate = [(case, variant, noise) for case in cases
                for variant, noise in (("train", 0.), ("slow", .2), ("strong", .2))]
    return {"selected": asdict(selected), "candidates": len(candidates),
            "no_feedforward_best": asdict(best_no_feedforward),
            "A_selected_gain_scaling_Kc_Ti_Td": a_selected,
            "A_candidates": len(a_candidates),
            "training_top": [{"score": cost, "parameters": asdict(p)} for cost, p in ranked[:5]],
            "A": [simulate(models, case, variant=v, noise=n) for case, v, n in evaluate],
            "A_tuned": [simulate(models, case, variant=v, noise=n, a_scale=a_selected)
                        for case, v, n in evaluate],
            "B": [simulate(models, case, selected, variant=v, noise=n) for case, v, n in evaluate],
            "B_no_feedforward": [simulate(models, case, best_no_feedforward, variant=v, noise=n)
                                 for case, v, n in evaluate],
            "loss_GLF_at_12s": {
                "A": simulate(models, cases[0], invalid_at=12),
                "B": simulate(models, cases[0], selected, invalid_at=12),
            }}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("identification", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    models = json.loads(args.identification.read_text(encoding="utf-8"))["models"]
    result = compare(models)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)


if __name__ == "__main__":
    main()
