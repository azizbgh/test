@echo off
setlocal
rem Immer die aktuelle Einzeldatei aus diesem Paket im Hardwaremodus aufrufen.
pushd "%~dp0"
if errorlevel 1 goto ordner_fehler
if not exist "luftsteuerung_kommentiert.py" goto datei_fehlt
if not exist ".venv\Scripts\python.exe" goto installation_fehlt

echo Starte Luftsteuerung im REALEN HARDWAREMODUS.
echo Die Messung wird gestartet; Stellbefehle erfordern eine Bestaetigung.
echo.
".venv\Scripts\python.exe" "luftsteuerung_kommentiert.py" --hardware
rem Rueckgabestatus sofort sichern, bevor weitere Befehle ihn veraendern.
set "LUFT_EXIT=%ERRORLEVEL%"
if "%LUFT_EXIT%"=="0" goto fertig
echo.
echo Die Anwendung wurde mit Fehlercode %LUFT_EXIT% beendet.
echo Python-Pakete mit INSTALLIEREN.bat installieren; NI-DAQmx separat pruefen.
pause

:fertig
popd
exit /b %LUFT_EXIT%

:installation_fehlt
echo Bitte zuerst INSTALLIEREN.bat ausfuehren.
pause
popd
exit /b 1

:datei_fehlt
echo luftsteuerung_kommentiert.py fehlt. ZIP vollstaendig entpacken.
pause
popd
exit /b 1

:ordner_fehler
echo Der Paketordner konnte nicht geoeffnet werden. ZIP lokal entpacken.
pause
exit /b 1
