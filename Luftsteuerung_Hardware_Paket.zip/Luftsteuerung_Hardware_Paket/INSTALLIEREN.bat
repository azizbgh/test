@echo off
setlocal
rem Alle Befehle im entpackten Paketordner ausfuehren, auch bei Leerzeichen.
pushd "%~dp0"
if errorlevel 1 goto ordner_fehler

echo Installation der Python-Abhaengigkeiten fuer die Luftsteuerung.
echo Die Anwendung und reale Ausgaenge werden dabei nicht gestartet.
echo.
if not exist "requirements.txt" goto datei_fehlt
if exist ".venv\Scripts\python.exe" goto pakete

rem Python 3.12 bevorzugen; sonst eine vorhandene Python-3-Installation nutzen.
where py >nul 2>&1
if errorlevel 1 goto python_befehl
py -3.12 --version >nul 2>&1
if errorlevel 1 goto py_standard
py -3.12 -m venv ".venv"
if errorlevel 1 goto fehler
goto pakete

:py_standard
py -3 -m venv ".venv"
if errorlevel 1 goto fehler
goto pakete

:python_befehl
where python >nul 2>&1
if errorlevel 1 goto python_fehlt
python -m venv ".venv"
if errorlevel 1 goto fehler

:pakete
rem NI-Betrieb auf dem Zielrechner benoetigt eine passende 64-Bit-Installation.
".venv\Scripts\python.exe" -c "import sys, struct; sys.exit(0 if sys.version_info >= (3, 10) and struct.calcsize('P') == 8 else 1)"
if errorlevel 1 goto python_version
".venv\Scripts\python.exe" -m pip install -r "requirements.txt"
if errorlevel 1 goto fehler
".venv\Scripts\python.exe" -m pip check
if errorlevel 1 goto fehler
rem Nur Python-Imports pruefen, keine NI-Tasks und keine Verbindung anlegen.
".venv\Scripts\python.exe" -c "import tkinter, customtkinter, PIL, nidaqmx; print('Python-Pakete erfolgreich geprueft. Keine Hardware angesprochen.')"
if errorlevel 1 goto fehler
echo.
echo Python-Installation abgeschlossen.
echo Der NI-DAQmx-Geraetetreiber und NI MAX muessen separat installiert sein.
echo Danach START_HARDWARE.bat verwenden.
pause
popd
exit /b 0

:python_fehlt
echo Python wurde nicht gefunden. Bitte Python 3.12 in 64 Bit installieren.
echo Bei der Python-Installation den Launcher und Tcl/Tk mit installieren.
goto fehler

:python_version
echo Benoetigt wird Python ab 3.10 in 64 Bit. Empfohlen: Python 3.12.
echo Die vorhandene lokale .venv ist dafuer nicht geeignet.
goto fehler

:datei_fehlt
echo requirements.txt fehlt. Bitte das ZIP vollstaendig entpacken.
goto fehler

:fehler
echo.
echo Installation fehlgeschlagen. Bitte die Fehlermeldung oben pruefen.
echo Fuer das Herunterladen der Python-Pakete wird Internetzugang benoetigt.
pause
popd
exit /b 1

:ordner_fehler
echo Der Paketordner konnte nicht geoeffnet werden. ZIP lokal entpacken.
pause
exit /b 1
