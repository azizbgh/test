# Prüfbericht zur Regelungsseite „Luftwege im Blick“

66 Softwaretests bestanden in 21.219 Sekunden. Die GUI-Tests liefen mit
Tk und CustomTkinter auf einer virtuellen Anzeige. Die Messwerte kamen aus
Softwaretests. Das vollständige Ergebnis steht in `Regelung_FU_Nachfuehrung_Tests.txt`.

Die Regelungsseite wurde bei 1024 × 700, 1366 × 768 und 1536 × 864 geprüft.
Der Testlauf umfasst auch Parameterdialog, Betriebsarten, Start, HOLD,
Fehlerquittierung und manuelle Korrektur.

Der Start über die Schaltfläche der Regelungsseite wurde mit GHF 78 m³/h,
GLF 17 m³/h, FU 0 % und Sollwert 150 m³/h geprüft. Der simulierte
DAQ-Controller erhielt nach der Verweilzeit einen FU-Befehl über 4 mA.
Ein weiterer Test bestätigt, dass sich die FU-Nachführung für feste
Betriebspunkte ausschalten lässt.

Die Vorschau `Regelung_Luftwege.png` zeigt die laufende Oberfläche im
Simulationsmodus. Für das Ziel ±2 m³/h in 30 Sekunden steht die Prüfung
an der Anlage aus. Die GHF-Messuntergrenze und die Fehlerverzögerung
bleiben als Versuchsparameter in der Bedienungsanleitung dokumentiert.

## Wichtige Quellstellen

| Datei | Zeile | Inhalt |
| --- | ---: | --- |
| `luftsteuerung/oberflaeche/dashboard.py` | 47 | Navigation und Modusanzeige |
| `luftsteuerung/oberflaeche/reglerseite.py` | 23 | Bedienleiste, Parameterdialog und Messwertanzeige |
| `luftsteuerung/oberflaeche/luftschema.py` | 39 | Luftschema mit FU, GHF, GLF und Gesamtwert |
| `luftsteuerung/oberflaeche/reglerverlauf.py` | 19 | Soll- und Istverläufe über 60 Sekunden |
| `luftsteuerung/regelung.py` | 205 | Regelung und HOLD |
