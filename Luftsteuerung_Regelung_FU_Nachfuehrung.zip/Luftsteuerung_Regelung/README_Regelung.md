# Luftsteuerung: manuelle Bedienung und neue Regelseite

Diese Erweiterung verwendet das vorhandene modulare Projekt. Messung, manuelle Stellbefehle und automatische Regelschritte werden im selben DAQ-Worker bearbeitet. Die Tk-Oberfläche erhält Daten über die vorhandene Queue; sie führt keine NI-Aufrufe aus. Die neue Python-Regelung ist noch keine an der Anlage nachgewiesene Reglerabstimmung.

**Wichtig vor einem Hardwarestart:** `--hardware` ist in diesem Projekt kein ausschließlich lesender Modus. Der vorhandene Worker fordert beim Start **an allen drei Ausgängen 4 mA** an: FU 0 %, GLF 100 %, GHF 100 %. Beim bestätigten Programmabschluss werden ebenfalls dreimal 4 mA angefordert. Ein FU-Sollwert von 0 % garantiert weder Nullförderung noch einen sicheren Anlagenzustand.

## Start und Betriebsarten

Im Projektordner mit `main.py`:

Die Oberfläche benötigt Python ab 3.10 und CustomTkinter. Bei dir ist Python
3.13 vorhanden. Falls die Bibliothek noch fehlt:

```text
python -m pip install -r requirements.txt
```

```text
python main.py
python main.py --simulate
```

Beide Aufrufe starten die vorhandene hardwarefreie Demonstration. Ihre zeitabhängigen Sensorsignale sind **unabhängig von den Stellbefehlen**. Sie sind kein physikalisches Anlagenmodell. Die GUI und Softwarezustände lassen sich damit prüfen; Einschwingzeit, Genauigkeit und geeignete Verstärkungen der realen Luftstrecke lassen sich daraus nicht bestimmen.

Erst nach organisatorischer und elektrischer Betriebsfreigabe:

```text
python main.py --hardware
```

Dafür werden CustomTkinter, das Pythonpaket `nidaqmx` und ein zum Zielrechner und zur Hardware passender NI-DAQmx-Gerätetreiber benötigt. Das Pythonpaket ersetzt den Treiber nicht. Diese Arbeit hat keine reale Hardware eingeschaltet und keine GitHub-Publikation veranlasst.

Die Regelseite bietet einen Sollwert in m³/h und die drei Arten:

| Auswahl | Eingabebereich | Wirkungsweise |
| --- | --- | --- |
| Nur GLF | 12–100 m³/h | GLF regelt; GHF wird geschlossen angefordert, 0 % = 20 mA |
| Nur GHF | 50–449 m³/h | GHF regelt; GLF wird geschlossen angefordert, 0 % = 20 mA |
| Beide | 12–549 m³/h | GHF-Grundlast und GLF-Feinkorrektur; im niedrigen Bereich GLF-Teilbetrieb |

Die Bereiche sind **Software-Sollbereiche und keine nachgewiesenen erreichbaren Anlagenbereiche**. Bei der vorläufigen GHF-Untergrenze 50 m³/h wird in „Beide“ unter 62 m³/h zunächst nur GLF verwendet. Ein Schließbefehl bestätigt keine tatsächliche Stellung oder Dichtheit. Im GLF-Teilbetrieb ist ein möglicher GHF-Restfluss nicht als gemessene Null nachgewiesen; die Anzeige weist darauf hin.

In **Regelung · Luftwege im Blick** stehen Betriebsart und Gesamtsollwert
über dem Schema. Die Zweigkarten zeigen Teilsoll, Istwert, Sensorstrom und
Messwertalter. Links unten steht der Gesamtverlauf, rechts die beiden
Zweigverläufe. Die Diagramme zeigen bis zu 60 Sekunden aus der laufenden
Messung und den jeweils übernommenen Sollwert. Über **Parameter** öffnest
du den separaten Dialog für PID-Werte und Versuchseinstellungen.

Vor dem automatischen Betrieb sind FU, GLF und GHF bestätigt zu initialisieren. Der Übernahmedialog zeigt die Betriebsart, Sollwerte und relevanten Aktionen. Eine Auftragsannahme ist noch keine erfolgreiche Ausgabe. Erst ein bestätigter DAQ-Schreibaufruf wird als bestätigter Sollbefehl übernommen. Der Ausgangsstrom wird nicht zurückgemessen.

## Regelung und offene Annahmen

Im gemeinsamen Betrieb hält GHF eine langsam verschiebbare Grundlast. GLF korrigiert die verbleibende Mengenabweichung. Fehlt GLF dauerhaft Stellreserve, darf die Grundlast nach einer Verweilzeit langsam nachgeführt werden. Das bevorzugte GLF-Band 40–60 m³/h, Verweilzeiten, Filter und Änderungsraten sind ausdrücklich **Entwicklungs- und Versuchsparameter**. Sie sind kein nachgewiesenes Optimum.

Die vorläufige GHF-Messuntergrenze von **50 m³/h ist unbestätigt** und in den Einstellungen sichtbar. Aus dem derzeit vorliegenden Code und den verfügbaren Gesprächsnotizen ergibt sich kein belastbarer Nachweis der minimal zuverlässig messbaren GHF-Menge. Die Sensorskalierung allein liefert diesen Nachweis nicht. Unterhalb dieser Grenze wird ein GHF-Anteil nicht als zuverlässig gemessene Gesamtsumme ausgewiesen. Messwerte außerhalb des nominalen Bereichs und veraltete Werte bleiben entsprechend gekennzeichnet; reine Diagnoseanzeigen dürfen nicht als Genauigkeitsbeleg verwendet werden.

Die übernommenen PID-Werte:

| Regler | Kc | Ti [min] | Td [min] | Interne Zeiten [s] |
| --- | --- | --- | --- | --- |
| GHF | 0,900 | 0,108 | 0,007 | Ti 6,48; Td 0,42 |
| GLF | 0,320 | 0,075 | 0,001 | Ti 4,50; Td 0,06 |

Soll- und Istwerte werden für die PID-Rechnung in Prozent des jeweiligen Durchflussbezugs normalisiert; der Ausgang ist ein Stellbefehl in Prozent. Für aktive Ventile gelten zunächst 20–100 %, ein inaktiver Zweig erhält den getrennten Schließbefehl 0 %. Dieser Schließbefehl liegt bewusst außerhalb der Stellgrenzen eines aktiven Reglers.

Die Python-Berechnung ist eine eigene definierte Umsetzung: P- und I-Anteil auf der Regelabweichung, gefilterter D-Anteil auf dem Messwert, tatsächliche verstrichene Zeit, Begrenzung und Anti-Windup. Ein vorhandener Bezug auf NI/LabVIEW PID, Stand 2025, ist **kein Nachweis bitidentischer Ergebnisse** dieser neuen Implementierung. Filterzeit, Initialisierung, Zeitbehandlung und Einheiten müssen bei einem Vergleich ausdrücklich berücksichtigt werden.

Die gemeinsame **FU-Nachführung ist beim Reglerstart standardmäßig EIN**. Bei zu niedrigem Durchfluss und einem aktiven Schieber ab 90 % beginnt der Regler nach fünf Sekunden, den FU schrittweise zu erhöhen. Die Geschwindigkeit beträgt einen Prozentpunkt pro Sekunde. Bei anhaltend überschüssiger Ventilreserve kann der Regler entsprechend absenken. Die Nachführung verwendet qualifizierte Durchflussmessungen. Für einen Versuch am manuell eingestellten, festen FU-Punkt lässt sie sich unter **Parameter → Erweitert** ausschalten. Die ältere FU-Kennlinie und der Faktor 1,05 sind hierfür unbenutzt. Das Verhalten der Nachführung an der Anlage muss geprüft werden.

Ein mechanischer Bypass wird organisatorisch am Aufbau berücksichtigt. Für ihn gibt es hier weder einen neuen Druckeingang noch eine zugesicherte softwareseitige Drucküberwachung.

## Anhalten, Fehler und Korrektur

- **Bewusst „Regelung stoppen“:** Weitere automatische Stellbefehle enden; die zuletzt bestätigten Stellwerte bleiben angefordert. Das ist kein Anlagenstopp.
- **Regelfehler:** Die Automatik hält ebenfalls die zuletzt bestätigten Stellwerte und meldet den Fehler. Sie erzeugt dafür keinen 4-mA-Reset. Manuelle Prüfung und Korrektur bleiben möglich; automatische Wiederaufnahme erfolgt erst nach einem neuen bestätigten Start.
- **Manuelle Übernahme:** Zuerst die Automatik ausdrücklich stoppen. Danach sind manuelle Stellbefehle wieder möglich, auch nach einem Regelfehler. Bestätigte Teilbefehle bleiben bei einem späteren Schreibfehler sichtbar; es gibt keinen automatischen Rollback oder Wiederholungsauftrag.
- **Messung neu verbinden:** Ist ein gesonderter Auftrag des vorhandenen Workers. Ein fehlgeschlagener Mess-Task wird nicht stillschweigend durch einen zweiten ersetzt. Die Automatik läuft danach nicht ohne erneute Übernahme weiter.
- **Programm schließen:** Fordert wie bisher die vereinbarten 4-mA-Abschlusswerte an und gibt danach Tasks frei. Das ist eine andere Aktion als „Regelung stoppen“. Auch die Task-Freigabe beweist keinen sicheren Anlagenzustand.

Ein bereits begonnener NI-Treiberaufruf kann nicht durch einen GUI-Klick sicher abgebrochen werden. Eine Fehlermeldung oder ein Timeout beweist nicht, dass elektrisch nichts verändert wurde. Der tatsächliche Zustand muss unabhängig geprüft werden.

Als vorläufiges Regelziel gelten **±2 m³/h nach 30 s**. Wird das Ziel anschließend weiterhin verfehlt, muss die Abweichung zunächst zusätzlich die konfigurierte Verzögerung anhalten. Die anfänglichen **2 s Verzögerung sind eine vorläufige Projektvorgabe**, keine Herstellerspezifikation. Messfehler werden getrennt behandelt. Ist GLF tatsächlich in Verwendung und bleibt der Durchfluss 10 s unter 5 m³/h, wird die Automatik angehalten; Magnetstellung, Schieber, Versorgung und Luftweg sind zu prüfen. Dieser Hinweis ist keine sicherheitsgerichtete Schutzfunktion.

## CSV-Messprotokoll

Die Oberfläche verwendet ein Verzeichnis `messprotokolle` für die Sitzungsdateien. Jeder neue Regellauf erhält eine eigene Datei. Bei rein programmgesteuerter Nutzung kann der Worker mit `log_directory=None` ohne Dateiausgabe betrieben werden.

Format:

1. UTF-8, erste Zeile `# metadata ` mit einem JSON-Objekt.
2. CSV-Kopf und Datenzeilen mit Semikolon als Trennzeichen, Dezimalpunkt für Zahlen.
3. Periodische Proben höchstens 10 Hz; **Statuswechsel wie Stopp und Fehler werden zusätzlich sofort protokolliert**.

Die Metadaten enthalten die vollständigen Laufparameter einschließlich Kc, Ti/Td und deren Minuten-Einheiten, vorläufiger GHF-Untergrenze sowie Verzögerungen. Hersteller- und Hardwarevalidierung werden ausdrücklich nicht behauptet.

Die Datenzeilen enthalten monotone Zeit und Laufdauer, Status, Betriebsart, Sollwert, verwendeten Regel-Istwert und Fehler, beide aus Sensorströmen berechneten Durchflüsse, Rohströme in A, originales Messwertalter in ms, Zweigsollwerte, Meldung, Warnung und die Kennzeichnung `within_tolerance`.

`*_confirmed_percent` enthält ausschließlich bestätigte Stellbefehle. `*_command_current_A` ist der daraus **berechnete Sollstrom**, keine Ausgangsmessung. Fehlende Bestätigungen bleiben leer. Fehlende Durchflüsse werden nicht durch null ersetzt; nicht endliche Rohströme werden als solche ausgewiesen. Außerhalb einer Sensor-Kennlinie berechnete Durchflüsse sind Diagnosewerte, kein Kalibriernachweis. In `control_flow_m3h` steht die tatsächlich verwendete Regelgröße; Warnungen zu einem unvollständigen Gesamtstrom sind bei jeder Bewertung zu beachten.

Dateifehler werden als Protokollwarnung an die Oberfläche gemeldet. Sie dürfen für sich keine neue Hardwareausgabe oder einen ungefragten Anlagenzustandswechsel auslösen. Die Datei ist kein garantiert vollständiges Echtzeit- oder Sicherheitsprotokoll.

Beispiel zum Lesen mit der Python-Standardbibliothek:

```python
import csv
import json

with open("messprotokolle/DATEINAME.csv", encoding="utf-8", newline="") as stream:
    metadata = json.loads(stream.readline().removeprefix("# metadata "))
    rows = list(csv.DictReader(stream, delimiter=";"))
```

Für die Prüfung, ob der angezeigte Istwert spätestens nach 30 s im Band
±2 m³/h liegt, werden **reale, gekennzeichnete CSV-Läufe** ausgewertet.
Betriebsart, Messwertqualität und Vorbedingungen gehören zur Bewertung.
Die absolute Genauigkeit des wirklichen Luftstroms ist eine zusätzliche
Messfrage; dafür sind Kalibrierunterlagen oder eine geeignete unabhängige
Referenz nötig. Eine ruhige Anzeige oder ein Softwaremodell allein belegt
diese absolute Genauigkeit nicht.

## Prüfungen ohne reale Hardware

Im Projektordner:

```text
python -m unittest discover -s tests -v
```

Die Protokolltests verwenden temporäre Verzeichnisse und die echten reinen Datenklassen. Sie öffnen weder Tk noch NI-Tasks. Die Demo-Sensorsignale dürfen nicht als gekoppeltes Modell zur Bewertung der Regelgüte verwendet werden. Erst die übrigen tatsächlich ausgeführten Tests und ein dokumentierter Hardwareversuch können weitere Aussagen tragen; die bloße Existenz eines Tests ist kein bestandenes Ergebnis.

## Kontrollierte Hardwareprüfung vorbereiten

Die folgenden Schritte sind ein Plan, kein bereits durchgeführter Test und keine Betriebsfreigabe:

1. **Verantwortung und Sicherung:** Anlagenverantwortliche Person und qualifizierte Elektro-/Automatisierungsfachperson bestimmen. Nicht allein testen. Den unabhängigen Weg zur Sicherung der Anlage, zulässige Werte und Abbruchverfahren vorher konkret festlegen. Nicht auf Fensterabschluss oder eine Softwarefehlermeldung als Abschaltung vertrauen.
2. **Aufbau prüfen:** Gerätebezeichnung, NI-MAX-Konfiguration, Modulpositionen, Klemmen, Versorgung, Stromschleifen, Last-/Bürdenbedingungen und mechanischen Bypass mit freigegebenen Unterlagen abgleichen. Geeignete kalibrierte Messmittel und eine unabhängige Durchflussreferenz vorbereiten. Insbesondere die Wirkung dreier 4-mA-Startwerte vor einem realen GUI-Start freigeben.
3. **Messung und Kennlinien getrennt prüfen:** GHF/GLF-Sensorskalierung, Rohströme und Null-/Referenzpunkte überprüfen. FU-%-zu-Sollstrom und Ventil-%-zu-Sollstrom unabhängig messen. Eine gültige elektrische Zuordnung beweist keine Ventilposition oder gemeinsame FU-Durchflusskennlinie. Die tatsächlich zuverlässige GHF-Untergrenze aus Messungen mit Referenz und dokumentierter Unsicherheit bestimmen; die 50-m³/h-Vorbelegung nicht als Messergebnis übernehmen.
4. **Manuellen Betriebspunkt herstellen:** Die Wirkung manuell freigegebener, kleiner Änderungen beobachten. Einen geeigneten festen FU-Punkt wählen und FU-Nachführung ausgeschaltet lassen. Keine großen Sollwertsprünge ohne eigene Freigabe. Initiale Ausgangswerte und tatsächlich anliegende Ströme protokollieren.
5. **Einzelzweige prüfen:** Zunächst einen freigegebenen Arbeitspunkt je Zweig verwenden. Inaktiven Zweig und möglichen Restfluss unabhängig prüfen. Wirkungsrichtung, Reaktionszeit, Schwankungen und Sättigung erfassen. Abweichungen zwischen bestätigtem Sollbefehl und wirklichem Strom als solche behandeln.
6. **Gemeinsamen Betrieb prüfen:** Nur nach geeigneten Einzelergebnissen GHF-Grundlast und GLF-Feinkorrektur an freigegebenen Punkten untersuchen. Kleine freigegebene Solländerungen und langsame Grundlastverschiebung protokollieren. Die Kopplung durch den gemeinsamen FU beobachten. Den Bereich bis 549 m³/h nicht allein aus der Summe zweier Sensorendwerte als erreichbar annehmen.
7. **Genauigkeit bewerten:** Reale Sitzungs-CSV mit Messreferenz auswerten: Zeit bis zum Erreichen des Bandes, Abweichung ab 30 s, Verweildauer, Rohsignalqualität, Zweiganteile und Stellreserve. ±2 m³/h sind vorerst das Prüfziel. Protokoll und verantwortliche Bewertung entscheiden; keine Kalibrierung aus einer simulierten Kurve ableiten.
8. **Bedien- und Fehlerfälle:** Stopp/HOLD und bestätigte manuelle Übernahme zunächst im sicheren Aufbau prüfen. Fehlerlogik zuerst mit Mocks untersuchen. Keine Prozessabstürze, Leitungsunterbrechungen oder gefährlichen Fehlzustände im bewegungswirksamen Betrieb zu Testzwecken erzeugen. Ein realer Fehlerfall benötigt ein gesondert freigegebenes Verfahren.
9. **Automatische FU-Nachführung prüfen:** Für diesen begleiteten Versuch vor dem Start den eingeschalteten Schalter und die freigegebenen Betriebsbedingungen prüfen. Änderungen der gemeinsamen Förderleistung und Rückwirkungen auf beide Zweige getrennt bewerten. Ohne Druckmessung bleibt die Druckwirkung unbeobachtet.
10. **Abschluss und Abbruch:** Bei unerwarteter Wirkung, falschem Kanal, unklaren Stromwerten, verlorener Messqualität oder verlorener Stellreserve den Test gemäß dem vorher festgelegten Verfahren beenden und die Anlage unabhängig sichern. Ursache und Teilbefehle dokumentieren; Wiederaufnahme erst nach Klärung. Normaler Programmabschluss fordert weiterhin 4 mA an allen Ausgängen an.
