"""Reine Softwareprüfungen; diese Tests starten weder NI-Tasks noch eine GUI.

Die eingespeisten Ströme sind Testdaten, kein Modell der Luftstrecke. Ein
bestandener Test belegt daher Logik, Zeitverhalten und HOLD-Semantik, niemals
die physische Erreichbarkeit eines Sollwerts oder eine reale Regelgüte.
"""

from __future__ import annotations

import dataclasses
import unittest

from luftsteuerung.konfiguration import GHF_SENSOR_FACTOR, GLF_SENSOR_FACTOR
from luftsteuerung.messwerte import SensorReading
from luftsteuerung.regelung import (
    PIDGains, RegulationController, RegulationSettings, _PercentPID,
)


def readings(now: float, ghf: float = 80.0, glf: float = 30.0) -> dict[str, SensorReading]:
    return {
        "GHF": SensorReading(0.004 + ghf * GHF_SENSOR_FACTOR, now, None),
        "GLF": SensorReading(0.004 + glf * GLF_SENSOR_FACTOR, now, None),
    }


class RegulationTests(unittest.TestCase):
    def start(self, mode="GLF", target=30.0, **kwargs) -> RegulationController:
        controller = RegulationController()
        controller.start(RegulationSettings(mode, target, **kwargs),
                         {"FU": 20.0, "GLF": 50.0, "GHF": 50.0}, 100.0)
        return controller

    def test_mode_ranges_and_nonfinite_inputs(self):
        for mode, lower, upper in (("GLF", 12, 100), ("GHF", 50, 449), ("BEIDE", 12, 549)):
            RegulationSettings(mode, lower).validate()
            RegulationSettings(mode, upper).validate()
            for value in (lower - 0.01, upper + 0.01, float("nan"), True):
                with self.subTest(mode=mode, value=value), self.assertRaises(ValueError):
                    RegulationSettings(mode, value).validate()
        with self.assertRaises(ValueError):
            RegulationSettings("anders", 50).validate()
        with self.assertRaises(ValueError):
            RegulationSettings("GLF", 50, ghf_gains=PIDGains(1, -1, 0)).validate()
        with self.assertRaises(ValueError):
            RegulationSettings("GLF", 50, valve_min_percent=0).validate()

    def test_start_requires_all_confirmed_outputs_and_is_atomic(self):
        controller = self.start()
        old = controller.snapshot()
        with self.assertRaises(ValueError):
            controller.start(RegulationSettings("GLF", 30), {"FU": 0.0}, 101)
        self.assertEqual(controller.snapshot(), old)
        with self.assertRaises(ValueError):
            controller.start(RegulationSettings("BEIDE", 110, ghf_min_m3h=150),
                             {"FU": 20, "GLF": 50, "GHF": 50}, 101)
        self.assertEqual(controller.snapshot(), old)

    def test_bumpless_first_step_and_inactive_branch(self):
        controller = self.start()
        desired = controller.step(readings(100.1, glf=10), 100.1)
        self.assertEqual(desired, {"FU": 20, "GLF": 50, "GHF": 0})
        # Eine Rechenabsicht ist noch kein bestätigter Ausgangsbefehl.
        self.assertEqual(controller.snapshot().outputs_percent["GHF"], 50)
        controller.acknowledge(desired)
        self.assertEqual(controller.snapshot().outputs_percent["GHF"], 0)

    def test_inactive_bad_sensor_does_not_stop_selected_branch(self):
        for mode, target, bad in (("GLF", 30, "GHF"), ("GHF", 80, "GLF")):
            controller = self.start(mode, target)
            data = readings(100.1)
            data[bad] = SensorReading(0.0, 100.1, "Kabel prüfen")
            self.assertTrue(controller.step(data, 100.1))
            self.assertEqual(controller.snapshot().status, "running")

    def test_invalid_or_stale_active_sensor_faults_without_output_request(self):
        for sample in (SensorReading(0.021, 100.1, "Strom zu hoch"),
                       SensorReading(0.0088, 98.0, None),
                       SensorReading(0.0088, 101.0, None)):
            controller = self.start()
            controller.acknowledge({"FU": 24})
            before = dict(controller.snapshot().outputs_percent)
            self.assertEqual(controller.step({"GLF": sample}, 100.1), {})
            self.assertEqual(controller.snapshot().status, "fault")
            self.assertIn("GLF", controller.snapshot().message)
            self.assertEqual(dict(controller.snapshot().outputs_percent), before)

    def test_stop_and_fault_hold_confirmed_values(self):
        for kind in ("stop", "fault"):
            controller = self.start()
            desired = controller.step(readings(101), 101)
            controller.acknowledge(desired)
            before = dict(controller.snapshot().outputs_percent)
            getattr(controller, kind)("Bediener-Test")
            self.assertEqual(controller.step(readings(102), 102), {})
            self.assertEqual(dict(controller.snapshot().outputs_percent), before)
            self.assertEqual(controller.snapshot().status, "stopped" if kind == "stop" else "fault")

    def test_partial_confirmation_and_snapshot_are_independent(self):
        controller = self.start()
        previous = controller.snapshot()
        controller.acknowledge({"GLF": 70})
        self.assertEqual(previous.outputs_percent["GLF"], 50)
        self.assertEqual(controller.snapshot().outputs_percent["GLF"], 70)
        with self.assertRaises(TypeError):
            previous.outputs_percent["FU"] = 40
        with self.assertRaises(dataclasses.FrozenInstanceError):
            previous.status = "running"

    def test_combined_low_target_is_explicit_glf_part_operation(self):
        controller = self.start("BEIDE", 20)
        desired = controller.step({"GLF": readings(100.1, glf=20)["GLF"]}, 100.1)
        snap = controller.snapshot()
        self.assertEqual(desired["GHF"], 0)
        self.assertAlmostEqual(snap.measured_total_m3h, 20)
        self.assertIn("Restfluss", snap.warning)
        self.assertTrue(snap.within_tolerance)

    def test_combined_91_is_residual_control_not_fixed_ratio(self):
        controller = self.start("BEIDE", 91)
        controller.step(readings(100.1, ghf=55, glf=36), 100.1)
        self.assertAlmostEqual(controller.snapshot().branch_setpoints["GHF"], 50)
        self.assertAlmostEqual(controller.snapshot().branch_setpoints["GLF"], 36)
        self.assertAlmostEqual(controller.snapshot().measured_total_m3h, 91)
        self.assertTrue(controller.snapshot().within_tolerance)

    def test_low_ghf_is_not_added_as_reliable_total(self):
        controller = self.start("BEIDE", 91)
        self.assertTrue(controller.step(readings(100.1, ghf=40, glf=51), 100.1))
        snap = controller.snapshot()
        self.assertAlmostEqual(snap.measured_total_m3h, 51)
        self.assertFalse(snap.within_tolerance)
        self.assertIn("unvollständig", snap.warning)

    def test_unreliable_ghf_preserves_planned_glf_share_and_holds_fu(self):
        controller = self.start("BEIDE", 91, fu_follow=True, fu_dwell_s=0)
        controller.acknowledge({"GLF": 100, "GHF": 100})
        for now in (100, 101, 102):
            desired = controller.step(readings(now, ghf=49, glf=41), now)
            self.assertTrue(desired)
            self.assertEqual(desired["FU"], 20)
            self.assertAlmostEqual(controller.snapshot().branch_setpoints["GLF"], 41)
            self.assertIsNone(controller.snapshot().error_m3h)
            self.assertFalse(controller.snapshot().within_tolerance)

    def test_reliable_ghf_restores_residual_control(self):
        controller = self.start("BEIDE", 91)
        controller.step(readings(100, ghf=49, glf=41), 100)
        self.assertAlmostEqual(controller.snapshot().branch_setpoints["GLF"], 41)
        controller.step(readings(101, ghf=50, glf=41), 101)
        self.assertAlmostEqual(controller.snapshot().measured_total_m3h, 91)
        self.assertAlmostEqual(controller.snapshot().error_m3h, 0)
        self.assertTrue(controller.snapshot().within_tolerance)
        controller.step(readings(102, ghf=55, glf=36), 102)
        self.assertAlmostEqual(controller.snapshot().branch_setpoints["GLF"], 36)

    def test_unreliable_total_fault_identifies_measurement_qualification(self):
        controller = self.start("BEIDE", 91, deviation_delay_s=2)
        for now in (100, 130, 131.9):
            self.assertTrue(controller.step(readings(now, ghf=49, glf=41), now))
        self.assertEqual(controller.step(readings(132.1, ghf=49, glf=41), 132.1), {})
        snap = controller.snapshot()
        self.assertEqual(snap.status, "fault")
        self.assertIn("Messbereich", snap.message)
        self.assertIn("nicht zuverlässig", snap.message)
        self.assertNotIn("±2", snap.message)

    def test_coordinator_moves_base_even_when_glf_residual_is_saturated(self):
        controller = self.start("BEIDE", 300, coordinator_dwell_s=2, base_rate_m3h_s=2)
        controller.step(readings(100.1, ghf=150, glf=100), 100.1)
        initial = controller.snapshot().branch_setpoints["GHF"]
        # GLF ist bei 100 begrenzt. Der ungekürzte Restbedarf von 150 muss
        # trotzdem eine weitere Grundlastverschiebung zulassen.
        for now in (101, 102.1, 103.1):
            controller.step(readings(now, ghf=150, glf=100), now)
        self.assertGreater(controller.snapshot().branch_setpoints["GHF"], initial)
        self.assertEqual(controller.snapshot().branch_setpoints["GLF"], 100)
        self.assertEqual(controller.snapshot().outputs_percent["FU"], 20)

    def test_coordinator_releases_base_when_glf_required_is_small(self):
        controller = self.start("BEIDE", 300, coordinator_dwell_s=1)
        controller.step(readings(100.1, ghf=280, glf=20), 100.1)
        initial = controller.snapshot().branch_setpoints["GHF"]
        controller.step(readings(101.2, ghf=280, glf=20), 101.2)
        self.assertLess(controller.snapshot().branch_setpoints["GHF"], initial)

    def test_missing_glf_timer_resets_when_flow_returns(self):
        controller = self.start()
        controller.step(readings(100, glf=0), 100)
        self.assertTrue(controller.step(readings(109, glf=0), 109))
        self.assertTrue(controller.step(readings(109.5, glf=10), 109.5))
        self.assertTrue(controller.step(readings(110, glf=0), 110))
        self.assertTrue(controller.step(readings(119, glf=0), 119))
        self.assertEqual(controller.step(readings(120, glf=0), 120), {})
        self.assertIn("Magnetstellung", controller.snapshot().message)
        self.assertNotIn("Magnet geschlossen", controller.snapshot().message)

    def test_deviation_has_settling_period_and_persistent_delay(self):
        controller = self.start(target=50, deviation_delay_s=2)
        for now in (100, 129.9, 130, 131.9):
            self.assertTrue(controller.step(readings(now, glf=40), now))
        # Ein gültiger Zwischenwert setzt den Abweichungstimer zurück.
        self.assertTrue(controller.step(readings(132, glf=50), 132))
        self.assertTrue(controller.step(readings(132.1, glf=40), 132.1))
        self.assertTrue(controller.step(readings(134, glf=40), 134))
        self.assertEqual(controller.step(readings(134.2, glf=40), 134.2), {})
        self.assertEqual(controller.snapshot().status, "fault")

    def test_restart_clears_previous_fault_and_timers(self):
        controller = self.start()
        controller.fault("Test")
        controller.start(RegulationSettings("GHF", 80), {"FU": 20, "GLF": 70, "GHF": 50}, 200)
        self.assertTrue(controller.step(readings(200.1), 200.1))
        self.assertEqual(controller.snapshot().status, "running")
        self.assertAlmostEqual(controller.snapshot().elapsed_s, 0.1)

    def test_default_fu_follow_increases_from_idle_with_150_target(self):
        controller = RegulationController()
        controller.start(RegulationSettings("BEIDE", 150),
                         {"FU": 0, "GLF": 100, "GHF": 100}, 100)
        for tick in range(41):
            now = 100 + tick / 4
            desired = controller.step(readings(now, ghf=78, glf=17), now)
            self.assertEqual(desired["GLF"], 100)
            self.assertEqual(desired["GHF"], 100)
            expected_fu = 0 if tick < 20 else (tick - 19) / 4
            self.assertEqual(desired["FU"], expected_fu)
            controller.acknowledge(desired)
        self.assertIn("ohne Drucküberwachung", controller.snapshot().warning)

        # Eine Messung im Sollband beendet die FU-Erhöhung.
        in_band = controller.step(readings(110.25, ghf=110, glf=40), 110.25)
        self.assertEqual(in_band["FU"], desired["FU"])
        self.assertTrue(controller.snapshot().within_tolerance)

    def test_fu_follow_can_be_disabled_for_fixed_fu_tests(self):
        controller = RegulationController()
        controller.start(RegulationSettings("BEIDE", 150, fu_follow=False),
                         {"FU": 0, "GLF": 100, "GHF": 100}, 100)
        for now in (100, 101, 105, 110):
            self.assertEqual(controller.step(readings(now, ghf=78, glf=17), now)["FU"], 0)


class PIDTests(unittest.TestCase):
    def test_minutes_are_seconds_and_actual_dt_is_used(self):
        pid = _PercentPID(PIDGains(1, 1, 0), 0, 100, 0)
        pid.track(50, 10, 10)
        self.assertAlmostEqual(pid.update(20, 10, 6), 61)

    def test_derivative_acts_on_measurement_not_setpoint(self):
        pid = _PercentPID(PIDGains(1, 0, 1 / 60), 0, 100, 0)
        pid.track(50, 10, 10)
        self.assertAlmostEqual(pid.update(20, 10, 1), 60)
        self.assertAlmostEqual(pid.update(20, 11, 1), 58)

    def test_saturation_does_not_accumulate_integral_and_can_recover(self):
        pid = _PercentPID(PIDGains(1, 1, 0), 20, 100, 0)
        pid.track(50, 10, 10)
        for _ in range(1000):
            self.assertLessEqual(pid.update(20, 10, 60), 100)
        self.assertAlmostEqual(pid.output, 100)
        # Gleicher Prozesswert, neuer Sollwert: ohne langes Entladen des
        # Integrators muss sich die Ausgabe sofort aus der Sättigung lösen.
        self.assertLess(pid.update(0, 10, 1), 100)


if __name__ == "__main__":
    unittest.main()
