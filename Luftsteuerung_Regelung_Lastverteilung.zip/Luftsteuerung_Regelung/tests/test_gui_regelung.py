"""Echte Tk-Integration mit Software-DAQ; niemals NI-Hardware.

Ohne DISPLAY oder CustomTkinter werden alle Fälle ausdrücklich übersprungen.
Optional AIRFLOW_GUI_SCREENSHOT=/absoluter/pfad.png erzeugt eine Vorschau mit
sichtbar beschrifteten Softwaretestdaten. Das ist kein Anlagenmodell.
"""
from __future__ import annotations

import importlib.util
import math
import os
from pathlib import Path
import tempfile
import threading
import time
import traceback
import unittest
from unittest.mock import patch

HAS_GUI = bool(os.environ.get("DISPLAY")) and importlib.util.find_spec("customtkinter") is not None
if HAS_GUI:
    import tkinter as tk
    from luftsteuerung.hardware import SimulatedDaqController
    from luftsteuerung.konfiguration import GHF_SENSOR_FACTOR, GLF_SENSOR_FACTOR
    from luftsteuerung.oberflaeche.dashboard import LuftsteuerungDashboard
    from luftsteuerung.protokoll import SessionLog
else:
    SimulatedDaqController = object


class GuiFakeController(SimulatedDaqController):
    """Feste, änderbare Sensorströme, keine Rückwirkung der Stellbefehle."""

    def __init__(self):
        super().__init__()
        self.lock = threading.RLock()
        self.confirmed = []
        self.currents = (0.004 + 80 * GHF_SENSOR_FACTOR,
                         0.004 + 30 * GLF_SENSOR_FACTOR)
        self.block_next_read = False
        self.read_entered = threading.Event()
        self.read_release = threading.Event()

    def set_flows(self, ghf, glf):
        with self.lock:
            self.currents = (0.004 + ghf * GHF_SENSOR_FACTOR,
                             0.004 + glf * GLF_SENSOR_FACTOR)

    def set_currents(self, ghf, glf):
        with self.lock:
            self.currents = (ghf, glf)

    def read_currents(self):
        with self.lock:
            block = self.block_next_read
            self.block_next_read = False
        if block:
            self.read_entered.set()
            if not self.read_release.wait(3):
                raise RuntimeError("GUI-Test hat Fake-Leseblock nicht freigegeben")
        with self.lock:
            return self.currents

    def write_current(self, name, current_a):
        with self.lock:
            super().write_current(name, current_a)
            self.confirmed.append((name, current_a))

    def writes(self):
        with self.lock:
            return tuple(self.confirmed)


@unittest.skipUnless(HAS_GUI, "GUI benötigt DISPLAY und CustomTkinter")
class RegulationGuiTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="airflow-gui-")
        self.addCleanup(self.temp.cleanup)
        self.errors = []
        self.callback_errors = []
        self.patches = [
            patch("tkinter.messagebox.askyesno", return_value=True),
            patch("tkinter.messagebox.showerror", side_effect=lambda title, text, **kw:
                  self.errors.append((title, text))),
            patch("luftsteuerung.worker.SessionLog",
                  side_effect=lambda directory=None: SessionLog(self.temp.name)),
        ]
        for item in self.patches:
            item.start()
            self.addCleanup(item.stop)
        self.controller = GuiFakeController()
        self.app = LuftsteuerungDashboard(simulate=True, controller=self.controller)
        self.addCleanup(self.close_app)
        self.app.report_callback_exception = lambda *args: self.callback_errors.append("".join(traceback.format_exception(*args)))
        self.app.geometry("1024x700")
        self.pump(lambda: self.app._measurement_is_recent() and len(self.controller.writes()) >= 3)
        self.app._show_page("Regelung")
        self.pump()

    def pump(self, until=None, duration=.10, timeout=3):
        deadline = time.monotonic() + timeout
        minimum = time.monotonic() + duration
        while time.monotonic() < deadline:
            self.app.update()
            if time.monotonic() >= minimum and (until is None or until()):
                self.assertFalse(self.callback_errors, self.callback_errors)
                return
            time.sleep(.01)
        self.fail("GUI-Zustand nicht rechtzeitig erreicht")

    def close_app(self):
        self.controller.read_release.set()
        try:
            exists = bool(self.app.winfo_exists())
        except tk.TclError:
            exists = False
        if exists and not self.app.closing:
            self.app.on_close()
        # Worker-Ende allein genügt nicht: Erst das folgende closed-Ereignis
        # zerstört den Tk-Interpreter. Vor dem nächsten Test beides abwarten.
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            try:
                self.app.update()
                exists = bool(self.app.winfo_exists())
            except tk.TclError:
                exists = False
            if not exists and not self.app.worker.is_alive():
                break
            time.sleep(.01)
        self.app.worker.join(3)
        self.assertFalse(self.app.worker.is_alive(), "Worker muss geordnet schließen")
        self.assertFalse(exists, "closed-Ereignis muss auch das Tk-Fenster zerstören")
        self.assertFalse(self.callback_errors, self.callback_errors)

    def start(self, mode="Nur GLF", setpoint="30"):
        self.app._reg_variables["setpoint"].set(setpoint)
        self.app.regulation_mode_buttons[mode].invoke()
        self.app.regulation_start_button.invoke()
        self.pump(lambda: self.app.regulation_snapshot.status == "running")

    def open_parameters(self):
        self.app.regulation_parameters_button.invoke()
        window = self.app.regulation_parameters_window
        self.pump(lambda: window.winfo_ismapped())
        self.assertIsNot(window, self.app)
        return window

    def close_parameters(self, window):
        # Den tatsächlichen WM-Schließhandler auslösen, ohne Fenstermanager-
        # Tastenkürzel oder einen plattformspezifischen Klick zu benötigen.
        handler = window.protocol("WM_DELETE_WINDOW")
        self.assertTrue(handler, "Parameterfenster braucht einen geordneten Schließhandler")
        window.tk.call(handler)
        self.pump(lambda: not window.winfo_ismapped())

    def display(self):
        return self.app.regulation_diagram.display_model

    def branch_display(self, name):
        return self.display()["readings"][name]

    def bounds(self, widget):
        self.assertTrue(widget.winfo_ismapped(), "Widget nicht sichtbar")
        return (widget.winfo_rootx(), widget.winfo_rooty(),
                widget.winfo_rootx() + widget.winfo_width(),
                widget.winfo_rooty() + widget.winfo_height())

    def assert_inside_client(self, widget, container=None):
        container = self.app if container is None else container
        x, y, right, bottom = self.bounds(widget)
        left = container.winfo_rootx()
        top = container.winfo_rooty()
        self.assertGreaterEqual(x, left)
        self.assertGreaterEqual(y, top)
        self.assertLessEqual(right, left + container.winfo_width(), str(widget))
        self.assertLessEqual(bottom, top + container.winfo_height(), str(widget))

    def test_navigation_und_original_start_close_4ma(self):
        self.assertEqual(self.controller.writes()[:3], (("FU", .004), ("GLF", .004), ("GHF", .004)))
        self.assertEqual(set(self.app.pages), {"Steuerung", "Regelung", "Einstellungen"})
        for name in self.app.pages:
            self.app.nav_buttons[name].invoke()
            self.pump()
            self.assertTrue(self.app.pages[name].winfo_ismapped())
            self.assertEqual(sum(p.winfo_ismapped() for p in self.app.pages.values()), 1)
        self.app.on_close()
        self.pump(lambda: not self.app.worker.is_alive())
        self.assertEqual(self.controller.writes()[-3:], (("FU", .004), ("GLF", .004), ("GHF", .004)))
        self.assertEqual(len(self.controller.writes()), 6, "Genau drei Start- und drei Abschlussbefehle")

    def test_start_stop_hold_und_manuelle_freigabe(self):
        self.start()
        self.assertTrue(all(w.cget("state") == "disabled" for w in self.app.inputs.values()))
        self.assertTrue(all(w.cget("state") == "disabled" for w in self.app._reg_editable))
        self.assertEqual(self.app.output_button.cget("state"), "disabled")
        self.app.regulation_stop_button.invoke()
        self.pump(lambda: self.app.regulation_snapshot.status == "stopped")
        writes = self.controller.writes()
        self.pump(duration=.25)
        self.assertEqual(self.controller.writes(), writes, "Stopp darf keine Endwerte schreiben")
        self.assertEqual(self.app.output_button.cget("state"), "normal")
        self.assertEqual(self.app.regulation_start_button.cget("state"), "normal")
        self.assertNotIn("—", str(self.display()["actual"]))
        self.assertIn("Stopp/Fehler", self.display()["caption"])
        self.assertIn("HOLD", self.display()["fu_text"])

    def test_fault_popup_einmal_istwerte_sichtbar_und_manuelle_korrektur(self):
        self.start()
        self.controller.set_currents(.004 + 80 * GHF_SENSOR_FACTOR, .0)
        self.pump(lambda: self.app.regulation_snapshot.status == "fault")
        self.assertNotIn("—", str(self.branch_display("GLF").actual))
        self.assertIn("ungeprüft", self.branch_display("GLF").age.lower())
        self.assertNotIn("—", str(self.display()["actual"]))
        self.assertEqual(self.app.output_button.cget("state"), "normal")
        self.assertEqual(self.app.regulation_snapshot.status, "fault", "Popup-OK startet nicht neu")
        self.assertEqual(len(self.errors), 1, "Eine GLF-Fehlerursache erzeugt genau einen Dialog")
        self.assertIn("GLF", self.errors[0][1])
        self.pump(duration=.35)
        self.assertEqual(len(self.errors), 1, "Kein zweiter Dialog pro Sensorpaket oder Fehlerpfad")
        self.controller.set_currents(.004 + 80 * GHF_SENSOR_FACTOR, math.nan)
        self.pump(lambda: math.isnan(self.app.sensor_readings["GLF"].current_a))
        self.assertNotIn("—", str(self.branch_display("GLF").actual))
        self.assertIn("Alt", self.branch_display("GLF").age)
        self.controller.set_flows(80, 30)
        self.pump(lambda: self.app.sensor_readings["GLF"].valid)
        self.app.inputs["GLF"].insert(0, "40")
        self.app.output_button.invoke()
        self.pump(lambda: not self.app.output_busy and self.app.inputs["GLF"].get() == "")
        self.assertEqual(self.app.regulation_snapshot.status, "fault")

    def test_ungueltige_eingabe_popup_und_variable_warnwerte(self):
        before = self.controller.writes()
        self.app._reg_variables["setpoint"].set("nan")
        self.app.regulation_start_button.invoke()
        self.assertTrue(any(title == "Regelungsparameter ungültig" for title, _ in self.errors))
        self.assertIn("endlich", self.app.regulation_message_label.cget("text"))
        self.assertEqual(self.controller.writes(), before)
        self.app._reg_variables["setpoint"].set("30")
        self.app._reg_variables["ghf_min"].set("65")
        self.app._reg_variables["delay"].set("3")
        settings = self.app._reg_settings()
        self.assertEqual(settings.ghf_min_m3h, 65)
        self.assertEqual(settings.deviation_delay_s, 3)
        window = self.open_parameters()
        if not self.app._reg_advanced_open:
            self.app.regulation_advanced_button.invoke()
        self.pump()
        self.assertIn("65", self.app.regulation_parameter_note.cget("text"))
        self.assertIn("3", self.app.regulation_parameter_note.cget("text"))
        self.close_parameters(window)

    def test_startdialog_exception_und_worker_rejection_lassen_bedienung_frei(self):
        self.app._reg_variables["setpoint"].set("30")
        with patch("tkinter.messagebox.askyesno", side_effect=RuntimeError("Dialog-Testfehler")):
            self.app.regulation_start_button.invoke()
        self.assertFalse(self.app.confirming)
        self.assertEqual(self.app.regulation_start_button.cget("state"), "normal")
        self.assertTrue(any("Dialog-Testfehler" in text for _, text in self.errors))
        with patch.object(self.app.worker, "request_start_regulation", side_effect=ValueError("Worker-Testfehler")):
            self.app.regulation_start_button.invoke()
        self.assertFalse(self.app._reg_request_pending)
        self.assertTrue(any("Worker-Testfehler" in text for _, text in self.errors))
        self.assertEqual(self.app.regulation_start_button.cget("state"), "normal")

    def test_sofortstopp_verwirft_wartenden_start_ohne_pending_hang(self):
        self.controller.block_next_read = True
        self.pump(self.controller.read_entered.is_set)
        self.app._reg_variables["setpoint"].set("30")
        self.app.regulation_start_button.invoke()
        self.assertTrue(self.app._reg_request_pending)
        self.app.regulation_stop_button.invoke()
        self.controller.read_release.set()
        self.pump(lambda: not self.app._reg_request_pending and not self.app._reg_stop_pending)
        self.assertNotEqual(self.app.regulation_snapshot.status, "running")
        self.assertEqual(self.app.regulation_start_button.cget("state"), "normal")

    def test_normaler_reglerstart_fuehrt_fu_aus_leerlauf_nach(self):
        self.controller.set_flows(78, 17)
        self.pump(lambda: abs(self.app.sensor_readings["GHF"].current_a
                              - (0.004 + 78 * GHF_SENSOR_FACTOR)) < 1e-9)
        self.start(mode="Beide", setpoint="150")
        self.pump(lambda: self.app.regulation_snapshot.outputs_percent["FU"] > 0,
                  timeout=9)
        self.assertTrue(any(name == "FU" and current > 0.004
                            for name, current in self.controller.writes()))
        self.assertEqual(self.app.regulation_snapshot.status, "running")

    def test_parameterfenster_oeffnen_fokussieren_schliessen_und_werte_behalten(self):
        writes = self.controller.writes()
        self.app._reg_variables["setpoint"].set("91")
        window = self.open_parameters()
        self.assertEqual(window.__class__.__name__, "CTkToplevel")
        self.app.regulation_parameters_button.invoke()
        self.pump()
        self.assertIs(self.app.regulation_parameters_window, window,
                      "Erneutes Öffnen soll dasselbe Parameterfenster fokussieren")
        self.assertTrue(window.winfo_ismapped())
        self.app._reg_variables["ghf_kc"].set("0,95")
        self.app._reg_variables["glf_ti"].set("0,080")
        self.close_parameters(window)
        self.assert_inside_client(self.app.regulation_start_button)
        self.assertEqual(self.app.regulation_start_button.cget("state"), "normal")
        self.open_parameters()
        self.assertEqual(self.app._reg_variables["ghf_kc"].get(), "0,95")
        self.assertEqual(self.app._reg_variables["glf_ti"].get(), "0,080")
        settings = self.app._reg_settings()
        self.assertEqual(settings.ghf_gains.kc, .95)
        self.assertEqual(settings.glf_gains.ti_minutes, .080)
        self.assertTrue(settings.fu_follow, "Beim normalen Reglerstart soll der FU nachführen")
        self.app._reg_fu_follow.set(False)
        self.assertFalse(self.app._reg_settings().fu_follow)
        self.assertEqual(self.controller.writes(), writes,
                         "Parameterfenster und Entwürfe dürfen keine Stellbefehle senden")
        self.close_parameters(window)

    def test_radiobuttons_aendern_modus_ohne_unbeabsichtigte_ausgabe(self):
        self.assertEqual(set(self.app.regulation_mode_buttons), {"Nur GLF", "Nur GHF", "Beide"})
        self.app._reg_variables["setpoint"].set("91")
        writes = self.controller.writes()
        for caption, code in (("Nur GLF", "GLF"), ("Nur GHF", "GHF"), ("Beide", "BEIDE")):
            with self.subTest(mode=caption):
                radio = self.app.regulation_mode_buttons[caption]
                self.assertEqual(radio.__class__.__name__, "CTkRadioButton")
                radio.invoke()
                self.pump()
                self.assertEqual(self.app._reg_mode.get(), caption)
                self.assertEqual(self.app._reg_settings().mode, code)
                self.assertEqual(self.app._reg_settings().setpoint_m3h, 91)
                self.assertEqual(self.display()["target"], "— m³/h")
                self.assertTrue(all(target is None for _, _, target in
                                    self.app.regulation_graphs["TOTAL"].last_draw["samples"]))
                self.assertEqual(self.controller.writes(), writes)

    def test_reconnect_nur_bei_messfehler_auf_reglerseite_sonst_weiter_verfuegbar(self):
        self.assertFalse(self.app.reconnect_button.winfo_ismapped(),
                         "Gesunde Regelungsseite soll den Vorlagen-Footer behalten")
        for page in ("Steuerung", "Einstellungen"):
            self.app._show_page(page)
            self.pump()
            self.assertTrue(self.app.reconnect_button.winfo_ismapped())
        self.app._show_page("Regelung")
        self.pump()
        with patch.object(self.controller, "read_currents", side_effect=RuntimeError("Fake-Verbindung unterbrochen")):
            self.pump(lambda: self.app.measurement_error)
        self.assertTrue(self.app.reconnect_button.winfo_ismapped(),
                        "Messfehler muss den Wiederverbinden-Button sichtbar machen")
        self.assert_inside_client(self.app.reconnect_button)
        self.app.reconnect_button.invoke()
        self.pump(lambda: not self.app.measurement_error and not self.app.output_busy
                  and self.app._measurement_is_recent())
        self.assertFalse(self.app.reconnect_button.winfo_ismapped())

    def test_layout_groessen_advanced_und_steuerungsaktionen(self):
        for width, height in ((1024, 700), (1366, 768), (1536, 864)):
            with self.subTest(size=(width, height)):
                self.app.geometry(f"{width}x{height}")
                self.app._show_page("Regelung")
                self.pump()
                self.assertEqual(set(self.app.regulation_graphs), {"TOTAL", "GHF", "GLF"})
                controls = [self.app.regulation_start_button, self.app.regulation_stop_button,
                            self.app.regulation_setpoint_entry, self.app.regulation_parameters_button,
                            self.app.regulation_message_label, self.app.regulation_diagram,
                            *self.app.regulation_mode_buttons.values(),
                            *self.app.regulation_graphs.values()]
                footer_y = self.app.close_button.winfo_rooty()
                for widget in controls:
                    self.assert_inside_client(widget)
                    self.assertLessEqual(self.bounds(widget)[3], footer_y,
                                         "Bedienung überschneidet Footer")
                diagram = self.app.regulation_diagram
                self.assertGreaterEqual(diagram.winfo_width(), width * .50,
                                        "Luftschema darf nicht zur kleinen Randvorschau schrumpfen")
                self.assertGreaterEqual(diagram.winfo_height(), 160)
                self.assertIn("Befehl:", self.display()["fu_text"])
                bounds = diagram.bbox("all")
                self.assertIsNotNone(bounds)
                self.assertGreaterEqual(min(bounds[:2]), 0)
                self.assertLessEqual(bounds[2], diagram.winfo_width())
                self.assertLessEqual(bounds[3], diagram.winfo_height())
                total = self.bounds(self.app.regulation_chart_frames["TOTAL"])
                ghf = self.bounds(self.app.regulation_chart_frames["GHF"])
                glf = self.bounds(self.app.regulation_chart_frames["GLF"])
                self.assertLessEqual(total[2], ghf[0], "Gesamttrend und Zweigtrends überlappen")
                self.assertLessEqual(ghf[3], glf[1], "Zweigtrends müssen untereinander stehen")
                self.assertGreater(total[2] - total[0], (ghf[2] - ghf[0]) * 1.15,
                                   "Gesamttrend soll breiter als die Zweigtrends sein")
                self.assertGreater(total[3] - total[1], (ghf[3] - ghf[1]) * 1.5)
                self.assertGreaterEqual(self.app.regulation_graphs["TOTAL"].winfo_height(), 150)
                for name in ("GHF", "GLF"):
                    self.assertGreaterEqual(self.app.regulation_graphs[name].winfo_height(), 55)
                for advanced in (False, True):
                    window = self.open_parameters()
                    if self.app._reg_advanced_open != advanced:
                        self.app.regulation_advanced_button.invoke()
                    self.pump()
                    if advanced:
                        self.assert_inside_client(self.app.regulation_advanced_panel, window)
                        self.assert_inside_client(self.app.regulation_fu_switch, window)
                    self.assert_inside_client(self.app.regulation_advanced_button, window)
                    self.close_parameters(window)
            self.app._show_page("Steuerung")
            self.pump()
            for widget in (self.app.output_button, self.app.clear_button, *self.app.inputs.values()):
                self.assert_inside_client(widget)
                self.assertLessEqual(self.bounds(widget)[3], self.app.close_button.winfo_rooty())

    def test_unvollstaendige_summe_keine_erfundene_gesamtabweichung(self):
        self.controller.set_flows(250, 50)
        self.start("Beide", "300")
        self.pump(lambda: self.app.regulation_snapshot.error_m3h is not None)
        self.controller.set_flows(40, 50)
        self.pump(lambda: self.app.regulation_snapshot.measured_total_m3h == 50
                  and self.app.regulation_snapshot.error_m3h is None)
        self.assertIn("50,00", str(self.display()["actual"]))
        self.assertIn("—", str(self.display()["error"]))
        self.assertIn("unvollständig", self.app.regulation_warning_label.cget("text"))
        self.assertFalse(self.app.regulation_snapshot.within_tolerance)

    def test_beide_softwaretestdaten_screenshot_optional(self):
        self.controller.set_flows(250, 50)
        self.pump(lambda: abs(self.app.sensor_readings["GHF"].current_a - (.004 + 250 * GHF_SENSOR_FACTOR)) < 1e-9)
        self.app.geometry("1366x768")
        self.start("Beide", "300")
        self.pump(lambda: self.app.regulation_snapshot.measured_total_m3h is not None, duration=.45)
        self.assertAlmostEqual(self.app.regulation_snapshot.measured_total_m3h, 300)
        self.assertAlmostEqual(self.app.regulation_snapshot.error_m3h, 0)
        total_trend = self.app.regulation_graphs["TOTAL"]
        self.assertTrue(total_trend.find_withtag("actual_trace"))
        self.assertTrue(total_trend.find_withtag("target_trace"))
        self.assertTrue(any(actual is not None and math.isclose(actual, 300) and target == 300
                            for _, actual, target in total_trend.last_draw["samples"]))
        path = os.environ.get("AIRFLOW_GUI_SCREENSHOT")
        if path:
            from PIL import ImageGrab
            self.app.regulation_message_label.configure(text=
                "SOFTWARETESTDATEN · Fake: GHF 250 / GLF 50 m³/h · keine reale Hardware, kein Anlagenmodell")
            self.app.update_idletasks()
            box = (self.app.winfo_rootx(), self.app.winfo_rooty(),
                   self.app.winfo_rootx() + self.app.winfo_width(),
                   self.app.winfo_rooty() + self.app.winfo_height())
            ImageGrab.grab(bbox=box, xdisplay=os.environ["DISPLAY"]).save(Path(path))


if __name__ == "__main__":
    unittest.main()
