"""Protokollprüfung mit echten Datenklassen, ohne NI, Tk oder Hardwareausgabe."""

import csv
from dataclasses import replace
import io
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from types import MappingProxyType
import unittest
from unittest.mock import patch

PROJECT = Path(__file__).resolve().parents[1]
if str(PROJECT) not in sys.path:
    sys.path.insert(0, str(PROJECT))

from luftsteuerung.messwerte import SensorReading
from luftsteuerung.protokoll import CSV_FIELDS, SessionLog
from luftsteuerung.regelung import RegulationSettings, RegulationSnapshot


class SessionLogTests(unittest.TestCase):
    def setUp(self):
        self.directory = TemporaryDirectory(prefix="luftsteuerung-protokoll-")
        self.addCleanup(self.directory.cleanup)
        self.log = SessionLog(Path(self.directory.name))
        self.addCleanup(self.log.close)
        self.settings = RegulationSettings(mode="BEIDE", setpoint_m3h=300.0)
        self.snapshot = RegulationSnapshot(
            status="running", mode="BEIDE", setpoint_m3h=300.0,
            measured_total_m3h=299.0,
            branch_setpoints=MappingProxyType({"GHF": 250.0, "GLF": 50.0}),
            outputs_percent=MappingProxyType({"FU": 25.0, "GLF": 100.0, "GHF": 50.0}),
            error_m3h=1.0, elapsed_s=99.0, message="Regelung läuft",
            warning="GHF-Untergrenze vorläufig", within_tolerance=True,
        )
        self.readings = {
            "GHF": SensorReading(.012, 999.9, None),
            "GLF": SensorReading(.012, 999.8, None),
        }

    def start(self):
        return self.log.start(self.settings, self.snapshot, 1000.0)

    def read(self, path=None):
        text = (path or self.log.path).read_text(encoding="utf-8")
        first, data = text.split("\n", 1)
        self.assertTrue(first.startswith("# metadata "))
        metadata = json.loads(first[len("# metadata "):])
        reader = csv.DictReader(io.StringIO(data), delimiter=";")
        self.assertEqual(tuple(reader.fieldnames), CSV_FIELDS)
        return metadata, list(reader)

    def test_metadata_includes_real_settings_and_readonly_mapping_snapshot(self):
        path = self.start()
        metadata, rows = self.read()
        self.assertEqual(path.parent, Path(self.directory.name))
        self.assertEqual(rows, [])
        self.assertEqual(metadata["settings"]["ghf_gains"]["kc"], .900)
        self.assertEqual(metadata["settings"]["ghf_gains"]["ti_minutes"], .108)
        self.assertEqual(metadata["settings"]["glf_gains"]["td_minutes"], .001)
        self.assertEqual(metadata["settings"]["ghf_min_m3h"], 50.0)
        self.assertEqual(metadata["settings"]["deviation_delay_s"], 2.0)
        self.assertEqual(metadata["initial_snapshot"]["outputs_percent"]["GHF"], 50.0)
        self.assertFalse(metadata["evidence"]["manufacturer_validation"])
        self.assertFalse(metadata["evidence"]["hardware_validation"])
        self.assertIn("Vorläufig", metadata["evidence"]["GHF_minimum"])
        self.assertIn("vorläufig", metadata["evidence"]["error_delay"])
        self.assertIn("kein gemessener Ausgangsstrom", metadata["output_semantics"])

    def test_only_acknowledged_values_become_command_currents(self):
        self.start()
        self.assertTrue(self.log.record(self.snapshot, self.readings, 1000.0))
        row = self.read()[1][0]
        self.assertEqual(float(row["FU_confirmed_percent"]), 25.0)
        self.assertAlmostEqual(float(row["FU_command_current_A"]), .008)
        self.assertAlmostEqual(float(row["GLF_command_current_A"]), .004)
        self.assertAlmostEqual(float(row["GHF_command_current_A"]), .012)
        self.assertEqual(float(row["GHF_target_m3h"]), 250.0)
        self.assertEqual(float(row["GLF_target_m3h"]), 50.0)

    def test_missing_unconfirmed_or_invalid_output_is_not_replaced_with_zero(self):
        self.start()
        # Vorschläge dürfen unter einem fremden Feld mitkommen; maßgeblich ist
        # ausschließlich das vereinbarte outputs_percent aus acknowledge().
        snap = {
            "status": "running", "mode": "BEIDE",
            "outputs_percent": {"FU": 0.0, "GLF": float("nan")},
            "proposed_outputs_percent": {"GLF": 100.0, "GHF": 100.0},
        }
        self.log.record(snap, self.readings, 1000.0)
        row = self.read()[1][0]
        self.assertEqual(float(row["FU_confirmed_percent"]), 0.0)
        self.assertAlmostEqual(float(row["FU_command_current_A"]), .004)
        for channel in ("GLF", "GHF"):
            self.assertEqual(row[f"{channel}_confirmed_percent"], "")
            self.assertEqual(row[f"{channel}_command_current_A"], "")

    def test_sensor_scaling_and_raw_zero_are_distinct_from_output_commands(self):
        self.start()
        readings = {"GHF": SensorReading(.020, 1000.0, None),
                    "GLF": SensorReading(0.0, 1000.0, "Signalfehler")}
        self.log.record(self.snapshot, readings, 1000.0)
        row = self.read()[1][0]
        self.assertAlmostEqual(float(row["GHF_m3h"]), .016 / .0000356)
        self.assertEqual(float(row["GLF_sensor_current_A"]), 0.0)
        self.assertEqual(float(row["GLF_m3h"]), -25.0)
        self.assertAlmostEqual(float(row["GLF_command_current_A"]), .004)

    def test_missing_and_nan_measurements_remain_missing_without_fake_flow(self):
        self.start()
        readings = {"GHF": SensorReading(None, 999.0, "Fehlt"),
                    "GLF": SensorReading(float("nan"), 999.5, "NaN")}
        self.log.record(self.snapshot, readings, 1000.0)
        row = self.read()[1][0]
        self.assertEqual(row["GHF_sensor_current_A"], "")
        self.assertEqual(row["GLF_sensor_current_A"], "NaN")
        self.assertEqual(row["GHF_m3h"], "")
        self.assertEqual(row["GLF_m3h"], "")
        self.assertEqual(float(row["GHF_age_ms"]), 1000.0)
        self.assertEqual(float(row["GLF_age_ms"]), 500.0)

    def test_periodic_measurements_are_limited_to_ten_hz(self):
        self.start()
        accepted = [self.log.record(self.snapshot, self.readings, 1000.0 + i / 100)
                    for i in range(101)]
        self.assertEqual(sum(accepted), 11)
        stamps = [float(row["timestamp_monotonic_s"]) for row in self.read()[1]]
        self.assertTrue(all(b - a >= .1 - 1e-9 for a, b in zip(stamps, stamps[1:])))

    def test_stop_and_fault_are_recorded_even_twenty_ms_after_periodic_sample(self):
        self.start()
        self.log.record(self.snapshot, self.readings, 1000.0)
        self.assertFalse(self.log.record(self.snapshot, self.readings, 1000.01))
        stopped = replace(self.snapshot, status="stopped", message="Bewusst angehalten")
        self.assertTrue(self.log.record(stopped, self.readings, 1000.02))
        fault = replace(stopped, status="fault", message="Messfehler; Stellwerte halten")
        self.assertTrue(self.log.record(fault, self.readings, 1000.04))
        self.log.close()
        rows = self.read()[1]
        self.assertEqual([row["status"] for row in rows], ["running", "stopped", "fault"])
        self.assertEqual(rows[-1]["message"], fault.message)
        self.assertEqual(rows[0]["FU_confirmed_percent"], rows[-1]["FU_confirmed_percent"])

    def test_each_run_gets_new_file_and_preserves_previous_run(self):
        first = self.start()
        self.log.record(self.snapshot, self.readings, 1000.0)
        first_bytes = first.read_bytes()
        second = self.log.start(self.settings, self.snapshot, 1000.0)
        self.assertNotEqual(first, second)
        self.assertEqual(first.read_bytes(), first_bytes)
        self.assertEqual(len(list(Path(self.directory.name).glob("*.csv"))), 2)
        self.assertEqual(len(self.read(second)[1]), 0)

    def test_none_directory_disables_logging_without_creating_files(self):
        disabled = SessionLog(None)
        self.assertIsNone(disabled.start(self.settings, self.snapshot, 1000.0))
        self.assertFalse(disabled.record(self.snapshot, self.readings, 1000.0))
        disabled.close()
        self.assertFalse(disabled.active)
        self.assertEqual(list(Path(self.directory.name).iterdir()), [])

    def test_open_and_write_failures_are_propagated_without_altering_commands(self):
        with patch.object(Path, "open", side_effect=PermissionError("Schreibschutz")):
            with self.assertRaises(PermissionError):
                self.start()
        self.assertFalse(self.log.active)
        self.start()
        before = dict(self.snapshot.outputs_percent)
        with patch.object(self.log._writer, "writerow", side_effect=OSError("Datenträger voll")):
            with self.assertRaises(OSError):
                self.log.record(self.snapshot, self.readings, 1000.0)
        self.assertEqual(dict(self.snapshot.outputs_percent), before)
        self.assertIsNone(self.log._last_written_at)

    def test_elapsed_and_sample_age_use_original_monotonic_times(self):
        self.start()
        self.log.record(self.snapshot, self.readings, 1001.0)
        row = self.read()[1][0]
        self.assertEqual(float(row["elapsed_s"]), 1.0)  # Nicht snapshot.elapsed_s=99.
        self.assertAlmostEqual(float(row["GHF_age_ms"]), 1100.0)
        self.assertAlmostEqual(float(row["GLF_age_ms"]), 1200.0)
        self.assertEqual(float(row["timestamp_monotonic_s"]), 1001.0)
        with self.assertRaises(ValueError):
            self.log.record(replace(self.snapshot, status="fault"), self.readings, 1000.5)

    def test_utf8_semicolon_quoting_and_close_roundtrip(self):
        self.start()
        snap = replace(self.snapshot, message="GHF prüfen; Stellwerte halten\nKein Reset",
                       warning="Messung veraltet – Ursache prüfen", within_tolerance=False)
        self.log.record(snap, self.readings, 1000.0)
        self.log.close()
        self.log.close()
        self.assertFalse(self.log.record(snap, self.readings, 1000.2))
        row = self.read()[1][0]
        self.assertEqual(row["message"], snap.message)
        self.assertEqual(row["warning"], snap.warning)
        self.assertEqual(row["within_tolerance"], "0")
        self.assertFalse(self.log.active)


if __name__ == "__main__":
    unittest.main(verbosity=2)
