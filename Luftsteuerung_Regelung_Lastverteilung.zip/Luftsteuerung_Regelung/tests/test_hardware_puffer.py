"""Frische Pakete und unabhängige Rohkanäle ohne NI-Treiber prüfen."""
import math
from types import SimpleNamespace
import unittest

from luftsteuerung.hardware import DaqController


class BufferTests(unittest.TestCase):
    def controller(self, data):
        controller = DaqController(driver=SimpleNamespace(
            constants=SimpleNamespace(READ_ALL_AVAILABLE=-1)))
        controller.measurement_task = SimpleNamespace(read=lambda **kwargs: data)
        return controller

    def test_old_buffer_does_not_dilute_latest_window(self):
        # Ein langsamer Write kann alte Messpakete aufstauen. Für die nächste
        # Rechnung zählen die letzten 50 Samples, nicht der gesamte Verlauf.
        controller = self.controller([[0.004] * 1000 + [0.012] * 50,
                                      [0.020] * 1000 + [0.008] * 50])
        ghf, glf = controller.read_currents()
        self.assertAlmostEqual(ghf, 0.012)
        self.assertAlmostEqual(glf, 0.008)

    def test_invalid_active_channel_does_not_hide_other_channel(self):
        ghf, glf = self.controller([[0.009] * 50, [math.nan] * 50]).read_currents()
        self.assertAlmostEqual(ghf, 0.009)
        self.assertTrue(math.isnan(glf))

    def test_out_of_range_current_is_not_clipped(self):
        ghf, glf = self.controller([[0.0] * 50, [0.021] * 50]).read_currents()
        self.assertEqual(ghf, 0.0)
        self.assertAlmostEqual(glf, 0.021)

    def test_missing_channel_stays_missing_without_discarding_valid_channel(self):
        ghf, glf = self.controller([[], [0.008] * 50]).read_currents()
        self.assertIsNone(ghf)
        self.assertAlmostEqual(glf, 0.008)


if __name__ == "__main__":
    unittest.main()
