"""Integration des DAQ-Workers ohne NI-Treiber, Hardware oder Tk prüfen.

Der Fake bildet ausdrücklich keine Luftstrecke nach. Er bestätigt vorgegebene
Strombefehle und liefert kontrollierte Eingangssignale. So werden Besitz des
DAQ-Zugriffs, Auftragsreihenfolge, Stop und Fehlerbehandlung geprüft, ohne aus
einem erfundenen Anlagenmodell Aussagen über die reale Regelgüte abzuleiten.
"""

from __future__ import annotations

import math
import queue
import threading
import time
import unittest

from luftsteuerung.kennlinien import CONFIGURED_ACTUATOR_CURVES, prepare_commands
from luftsteuerung.konfiguration import GHF_SENSOR_FACTOR, GLF_SENSOR_FACTOR
from luftsteuerung.regelung import RegulationSettings
from luftsteuerung.worker import DaqWorker


class FakeController:
    """Kleiner DAQ-Vertrag mit steuerbaren Fehlern und Treiberwartezeiten."""

    def __init__(self) -> None:
        self.measurement_task = None
        self.output_tasks = {}
        self.last_written = {}
        self.output_attempted = False
        self.output_fault = False
        self.currents = (
            0.004 + 80 * GHF_SENSOR_FACTOR,
            0.004 + 30 * GLF_SENSOR_FACTOR,
        )
        self.confirmed = []
        self.attempted = []
        self.owner_thread_ids = set()
        self.read_count = 0
        self.measurement_starts = 0
        self.fail_on_attempt = None
        self.failed_outputs = set()
        self.block_next_write = False
        self.block_next_read = False
        self.write_entered = threading.Event()
        self.write_release = threading.Event()
        self.read_entered = threading.Event()
        self.read_release = threading.Event()
        self.lock = threading.RLock()

    def _record_owner(self) -> None:
        self.owner_thread_ids.add(threading.get_ident())

    def start_measurement(self) -> None:
        with self.lock:
            self._record_owner()
            self.measurement_task = object()
            self.measurement_starts += 1

    def read_currents(self):
        with self.lock:
            self._record_owner()
            if self.measurement_task is None:
                raise RuntimeError("Fake-Messung ist nicht gestartet")
            should_wait = self.block_next_read
            self.block_next_read = False
        if should_wait:
            self.read_entered.set()
            if not self.read_release.wait(2):
                raise RuntimeError("Test hat Fake-Leseaufruf nicht freigegeben")
        with self.lock:
            self.read_count += 1
            return self.currents

    def write_current(self, name, current_a) -> None:
        with self.lock:
            self._record_owner()
            self.output_attempted = True
            self.attempted.append((name, current_a))
            attempt_number = len(self.attempted)
            should_wait = self.block_next_write
            self.block_next_write = False
        # Die Sperre wird während der simulierten Treiberwartezeit freigegeben.
        # Der Test kann somit einen Stopp auslösen, während ein Write läuft.
        if should_wait:
            self.write_entered.set()
            if not self.write_release.wait(2):
                raise RuntimeError("Test hat Fake-Schreibaufruf nicht freigegeben")
        with self.lock:
            if attempt_number == self.fail_on_attempt:
                self.failed_outputs.add(name)
                self.output_fault = True
                raise RuntimeError(f"{name}: gezielter Fake-Ausgabefehler")
            self.last_written[name] = current_a
            self.output_tasks.setdefault(name, object())
            self.failed_outputs.discard(name)
            self.output_fault = bool(self.failed_outputs)
            self.confirmed.append((name, current_a))

    def close_measurement(self):
        with self.lock:
            self._record_owner()
            self.measurement_task = None
        return []

    def close_tasks(self):
        # Der vorhandene Abschlussvertrag schreibt erst dreimal 4 mA.
        for name in ("FU", "GLF", "GHF"):
            self.write_current(name, 0.004)
        with self.lock:
            self.measurement_task = None
            self.output_tasks.clear()
        return []

    def writes(self):
        with self.lock:
            return tuple(self.confirmed)

    def attempts(self):
        with self.lock:
            return tuple(self.attempted)


class WorkerRegulationTests(unittest.TestCase):
    """Der echte Worker läuft; lediglich seine DAQ-Grenze wird ersetzt."""

    def setUp(self) -> None:
        self.controller = FakeController()
        self.worker = DaqWorker(self.controller)
        self.observed_events = []
        self.addCleanup(self._shutdown)
        self.worker.start()
        self.wait_event("started")
        self.wait_event("measurement")

    def _shutdown(self) -> None:
        self.controller.write_release.set()
        self.controller.read_release.set()
        self.controller.fail_on_attempt = None
        if self.worker.is_alive():
            self.worker.request_close()
            self.worker.join(3)
        self.assertFalse(self.worker.is_alive(), "DAQ-Worker wurde nicht beendet")

    def wait_until(self, condition, message="Bedingung nicht eingetreten", timeout=2):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if condition():
                return
            time.sleep(0.005)
        self.fail(message)

    def wait_event(self, kind, predicate=lambda payload: True, timeout=2):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            try:
                event = self.worker.events.get(timeout=0.02)
            except queue.Empty:
                continue
            self.observed_events.append(event)
            if event[0] == kind and predicate(event[1]):
                return event[1]
        self.fail(f"Worker-Ereignis {kind!r} fehlt")

    def status(self):
        return self.worker.regulation_snapshot.status

    def start_auto(self, mode="GLF", setpoint=30):
        settings = RegulationSettings(mode=mode, setpoint_m3h=setpoint)
        self.assertTrue(self.worker.request_start_regulation(settings))
        self.wait_until(lambda: self.status() == "running", "AUTO wurde nicht aktiv")

    def set_manual_middle_positions(self):
        commands = prepare_commands({"FU": "20", "GLF": "60", "GHF": "60"})
        self.assertTrue(self.worker.request_write(commands))
        self.wait_event("write_ok", lambda payload: any(n == "FU" and p == 20 for n, p, _ in payload))

    def test_startup_and_normal_close_keep_three_4ma_commands(self):
        self.assertEqual(self.controller.writes(), (("FU", 0.004), ("GLF", 0.004), ("GHF", 0.004)))
        self.worker.request_close()
        self.worker.join(3)
        self.assertFalse(self.worker.is_alive())
        self.assertEqual(self.controller.writes()[-3:], (("FU", 0.004), ("GLF", 0.004), ("GHF", 0.004)))
        self.assertEqual(self.controller.owner_thread_ids, {self.worker.ident})

    def test_stop_holds_outputs_and_does_not_resume_on_new_measurements(self):
        self.set_manual_middle_positions()
        self.start_auto()
        self.wait_event("auto_written")
        self.worker.request_stop_regulation()
        self.wait_until(lambda: self.status() == "stopped")
        held = self.controller.writes()
        reads_before = self.controller.read_count
        self.wait_until(lambda: self.controller.read_count >= reads_before + 3)
        self.assertEqual(self.controller.writes(), held)
        self.assertNotEqual(dict(held[-3:]), {"FU": 0.004, "GLF": 0.004, "GHF": 0.004})

    def test_active_sensor_fault_holds_and_allows_confirmed_manual_recovery(self):
        self.set_manual_middle_positions()
        self.start_auto()
        self.wait_event("auto_written")
        self.controller.currents = (self.controller.currents[0], math.nan)
        self.wait_until(lambda: self.status() == "fault", "Ungültiger aktiver GLF-Sensor stoppt AUTO nicht")
        held = self.controller.writes()
        reads_before = self.controller.read_count
        self.wait_until(lambda: self.controller.read_count >= reads_before + 2)
        self.assertEqual(self.controller.writes(), held, "Regelfehler darf keine Ersatzstellwerte ausgeben")
        commands = prepare_commands({"GHF": "25"})
        self.assertTrue(self.worker.request_write(commands))
        self.wait_event("write_ok", lambda payload: any(n == "GHF" and p == 25 for n, p, _ in payload))
        self.assertAlmostEqual(self.controller.last_written["GHF"], CONFIGURED_ACTUATOR_CURVES["GHF"](25))
        self.assertNotEqual(self.status(), "running", "Manuelle Korrektur darf AUTO nicht neu starten")

    def test_invalid_inactive_ghf_sensor_does_not_disable_glf_regulation(self):
        self.controller.currents = (math.nan, 0.004 + 30 * GLF_SENSOR_FACTOR)
        self.wait_event("measurement", lambda payload: not payload[0]["GHF"].valid)
        self.assertFalse(self.worker.measurement_valid)
        self.start_auto(mode="GLF", setpoint=30)
        self.wait_event("auto_written")
        reads_before = self.controller.read_count
        self.wait_until(lambda: self.controller.read_count >= reads_before + 3)
        self.assertEqual(self.status(), "running")
        self.assertAlmostEqual(self.controller.last_written["GHF"], 0.020)

    def test_manual_and_automatic_commands_have_one_owner(self):
        self.start_auto()
        commands = prepare_commands({"FU": "40"})
        self.assertFalse(self.worker.request_write(commands), "Manueller Write wurde während AUTO angenommen")
        self.worker.request_stop_regulation()
        self.wait_until(lambda: self.status() == "stopped")
        self.assertTrue(self.worker.request_write(commands))
        self.wait_event("write_ok", lambda payload: any(n == "FU" and p == 40 for n, p, _ in payload))
        self.assertEqual(self.controller.owner_thread_ids, {self.worker.ident})

    def test_stop_during_write_allows_inflight_confirmation_but_no_following_channels(self):
        self.set_manual_middle_positions()
        before_attempts = len(self.controller.attempts())
        self.controller.block_next_write = True
        settings = RegulationSettings(mode="BEIDE", setpoint_m3h=200)
        self.assertTrue(self.worker.request_start_regulation(settings))
        self.assertTrue(self.controller.write_entered.wait(2), "Kein automatischer Write gestartet")
        self.worker.request_stop_regulation()
        self.controller.write_release.set()
        self.wait_until(lambda: self.status() == "stopped")
        reads_before = self.controller.read_count
        self.wait_until(lambda: self.controller.read_count >= reads_before + 2)
        self.assertEqual(len(self.controller.attempts()) - before_attempts, 1,
                         "Nach dem laufenden Treiberaufruf wurde ein weiterer Kanal geschrieben")
        self.assertEqual(len(self.controller.writes()) - before_attempts, 1)

    def test_partial_auto_write_failure_preserves_only_confirmed_commands(self):
        self.set_manual_middle_positions()
        before = dict(self.controller.last_written)
        before_attempts = len(self.controller.attempts())
        before_confirmed = len(self.controller.writes())
        self.controller.fail_on_attempt = before_attempts + 2
        self.assertTrue(self.worker.request_start_regulation(
            RegulationSettings(mode="BEIDE", setpoint_m3h=200)))
        self.wait_until(lambda: self.status() == "fault", "Teilfehler stoppte AUTO nicht")
        confirmed = self.controller.writes()[before_confirmed:]
        attempts = self.controller.attempts()[before_attempts:]
        self.assertEqual(len(confirmed), 1)
        self.assertEqual(len(attempts), 2)
        expected = before | dict(confirmed)
        self.assertEqual(self.controller.last_written, expected)
        snapshot = self.worker.regulation_snapshot
        for name, percent in snapshot.outputs_percent.items():
            self.assertAlmostEqual(CONFIGURED_ACTUATOR_CURVES[name](percent), expected[name])
        self.assertEqual(self.controller.writes()[before_confirmed:], confirmed,
                         "Nach Teilfehler dürfen weder Rollback noch 4-mA-Reset folgen")

    def test_low_combined_setpoint_uses_glf_without_activating_ghf(self):
        self.set_manual_middle_positions()
        self.start_auto(mode="BEIDE", setpoint=30)
        self.wait_event("auto_written")
        snapshot = self.worker.regulation_snapshot
        self.assertEqual(snapshot.branch_setpoints["GHF"], 0)
        self.assertAlmostEqual(self.controller.last_written["GHF"], 0.020)
        self.assertEqual(snapshot.outputs_percent["GHF"], 0)

    def test_stop_invalidates_start_waiting_behind_a_read(self):
        self.controller.block_next_read = True
        self.assertTrue(self.controller.read_entered.wait(2), "Fake-Lesepause nicht erreicht")
        before = self.controller.writes()
        settings = RegulationSettings(mode="GLF", setpoint_m3h=30)
        self.assertTrue(self.worker.request_start_regulation(settings))
        self.worker.request_stop_regulation()
        self.controller.read_release.set()
        reads_before = self.controller.read_count
        self.wait_until(lambda: self.controller.read_count >= reads_before + 3)
        self.wait_event("regulation", lambda snapshot: snapshot.status in ("idle", "stopped"))
        self.assertEqual(self.controller.writes(), before, "Ein überholter Start hat AUTO-Befehle gesendet")
        # Ein nie gestarteter Controller darf idle bleiben. Entscheidend ist,
        # dass die überholte Anforderung nicht nachträglich wirksam wird.
        self.assertNotEqual(self.status(), "running")

    def test_delayed_read_is_not_relabelled_as_a_fresh_control_sample(self):
        settings = RegulationSettings(mode="GLF", setpoint_m3h=30, max_measurement_age_s=0.25)
        self.assertTrue(self.worker.request_start_regulation(settings))
        self.wait_until(lambda: self.status() == "running")
        self.wait_event("auto_written")
        self.controller.block_next_read = True
        self.assertTrue(self.controller.read_entered.wait(2))
        held = self.controller.writes()
        # Bewusst länger als das konfigurierte Messalter warten. Diese kurze
        # Treiberpause prüft echte Worker-Zeitstempel, kein gefälschtes Anlagenmodell.
        self.assertFalse(self.controller.read_release.wait(0.35))
        self.controller.read_release.set()
        self.wait_until(lambda: self.status() == "fault", "Alter Leseauftrag wurde als frische Messung verwendet")
        self.assertEqual(self.controller.writes(), held)

    def test_stop_then_new_start_during_start_logging_cannot_revive_old_run(self):
        self.set_manual_middle_positions()
        log_entered = threading.Event()
        log_release = threading.Event()
        original_start = self.worker.session_log.start

        def delayed_log_start(*args, **kwargs):
            log_entered.set()
            if not log_release.wait(2):
                raise RuntimeError("Test hat Protokollstart nicht freigegeben")
            return original_start(*args, **kwargs)

        self.addCleanup(log_release.set)
        self.worker.session_log.start = delayed_log_start
        before = self.controller.writes()
        self.assertTrue(self.worker.request_start_regulation(
            RegulationSettings(mode="GLF", setpoint_m3h=30)))
        self.assertTrue(log_entered.wait(2))
        self.worker.request_stop_regulation()
        # Der erste Start befindet sich bereits im Besitzerthread. Solange
        # dessen Stopp noch nicht bestätigt ist, darf ein neuer Start das
        # sofortige Stoppsignal nicht löschen und den alten Lauf reaktivieren.
        self.assertFalse(self.worker.request_start_regulation(
            RegulationSettings(mode="GHF", setpoint_m3h=100)))
        log_release.set()
        self.wait_until(lambda: self.status() == "stopped")
        reads_before = self.controller.read_count
        self.wait_until(lambda: self.controller.read_count >= reads_before + 2)
        self.assertEqual(self.controller.writes(), before)

    def test_delayed_auto_write_does_not_send_following_channels_from_old_sample(self):
        self.set_manual_middle_positions()
        before_attempts = len(self.controller.attempts())
        self.controller.block_next_write = True
        settings = RegulationSettings(mode="BEIDE", setpoint_m3h=200, max_measurement_age_s=0.25)
        self.assertTrue(self.worker.request_start_regulation(settings))
        self.assertTrue(self.controller.write_entered.wait(2))
        self.assertFalse(self.controller.write_release.wait(0.35))
        self.controller.write_release.set()
        self.wait_until(lambda: self.status() == "fault",
                        "Langer Write hat weitere Ausgaben aus alten Messdaten nicht verhindert")
        self.assertEqual(len(self.controller.attempts()) - before_attempts, 1,
                         "Nach Ablauf des Messalters wurde ein weiterer Kanal geschrieben")

    def test_measurement_restart_stops_auto_without_touching_outputs(self):
        self.start_auto()
        self.wait_event("auto_written")
        self.assertTrue(self.worker.request_restart_measurement())
        self.wait_event("measurement_restart_done")
        held = self.controller.writes()
        reads_before = self.controller.read_count
        self.wait_until(lambda: self.controller.read_count >= reads_before + 2)
        self.assertEqual(self.controller.writes(), held)
        self.assertNotEqual(self.status(), "running")
        self.assertEqual(self.controller.measurement_starts, 2)

    def test_incomplete_start_initialization_blocks_auto_but_manual_retry_can_recover(self):
        self.worker.request_close()
        self.worker.join(3)
        self.assertFalse(self.worker.is_alive())
        self.controller = FakeController()
        self.controller.fail_on_attempt = 2
        self.worker = DaqWorker(self.controller)
        self.worker.start()
        self.wait_event("started")
        self.wait_event("measurement")
        self.assertEqual(tuple(name for name, _ in self.controller.attempts()), ("FU", "GLF", "GHF"))
        self.assertNotIn("GLF", self.controller.last_written)
        before = self.controller.writes()
        # Je nach Ort der Vorprüfung darf die Anfrage sofort abgelehnt oder
        # angenommen und anschließend mit einem Reglerfehler beendet werden.
        self.worker.request_start_regulation(RegulationSettings(mode="GLF", setpoint_m3h=30))
        reads_before = self.controller.read_count
        self.wait_until(lambda: self.controller.read_count >= reads_before + 2)
        self.assertNotEqual(self.status(), "running")
        self.assertEqual(self.controller.writes(), before)
        self.assertTrue(self.worker.request_write(prepare_commands({"GLF": "60"})))
        self.wait_event("write_ok", lambda payload: any(n == "GLF" and p == 60 for n, p, _ in payload))
        self.assertFalse(self.controller.output_fault)
        self.assertEqual(set(self.controller.last_written), {"FU", "GLF", "GHF"})
        self.assertNotEqual(self.status(), "running")


if __name__ == "__main__":
    unittest.main()
