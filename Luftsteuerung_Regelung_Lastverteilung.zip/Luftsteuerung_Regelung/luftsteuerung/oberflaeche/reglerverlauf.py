"""Kompakter 60-s-Regelverlauf mit Soll-/Istwerten aus übergebenen Messpaketen.

Das Canvas liest keine Sensoren und plant keine eigene Aktualisierung. Ein
Resize zeichnet ausschließlich den zuletzt übergebenen Datenstand erneut.
Originalzeitstempel bleiben auch bei Datenlücken unverändert erhalten.
"""

from __future__ import annotations

import math
import tkinter as tk
from tkinter import font as tkfont
from types import MappingProxyType

from ..konfiguration import MAX_MEASUREMENT_AGE_S
from .darstellung import FONT_FAMILY, TEXT_MUTED, COLOR_DARK, number_de


class RegulationTrend(tk.Canvas):
    """Ein Diagramm; Titel und äußerer Rahmen gehören zum umgebenden Layout.

    ``samples`` enthält Tripel ``(monotone Zeit, Istwert | None, Sollwert | None)``.
    Nicht endliche Werte und ``None`` unterbrechen jeweils ihre eigene Kurve.
    Der Aufrufer setzt ``live=False``, wenn die aktuelle Messqualität ungültig
    ist. Historische Linien bleiben dann sichtbar, ohne ein Live-Wertkästchen.
    """

    WINDOW_S = 60.0
    TARGET_COLOR = "#263F85"

    def __init__(self, parent, *, color: str):
        super().__init__(parent, bg="#F6F9FD", highlightthickness=0, bd=0,
                         width=100, height=130)
        self.color = color
        self._axis_font = tkfont.Font(root=self, family=FONT_FAMILY, size=-11)
        self._badge_font = tkfont.Font(root=self, family=FONT_FAMILY, size=-12,
                                      weight="bold")
        rgb = self.winfo_rgb(color)
        self._badge_bg = self._tint(rgb, .91)
        self._badge_border = self._tint(rgb, .68)
        self._samples = ()
        self._now = None
        self._live = False
        self.last_draw = MappingProxyType({"samples": (), "now": None, "live": False})
        self.bind("<Configure>", self._on_resize, add="+")

    @staticmethod
    def _tint(rgb, white_fraction):
        return "#" + "".join(f"{round((channel / 257) * (1 - white_fraction) + 255 * white_fraction):02x}"
                              for channel in rgb)

    @staticmethod
    def _finite(value):
        return (isinstance(value, (int, float)) and not isinstance(value, bool)
                and math.isfinite(value))

    def draw(self, samples, now: float, *, live: bool = True):
        """Daten kopieren und zeichnen; weder Zeitstempel noch Werte auffüllen."""
        if not self._finite(now):
            raise ValueError("Der Verlauf benötigt eine endliche monotone Zeit.")
        # Keine Referenz auf eine vom Aufrufer weiterveränderte Messwertliste.
        self._samples = tuple(tuple(sample) for sample in samples)
        self._now, self._live = float(now), bool(live)
        self.last_draw = MappingProxyType({"samples": self._samples, "now": self._now, "live": self._live})
        self._redraw()

    def _on_resize(self, _event=None):
        if self._now is not None:
            self._redraw()

    def _legend(self, width):
        """Legende auch ohne Messdaten und bei schmalem Diagramm anzeigen."""
        line_height = self._axis_font.metrics("linespace")
        soll_width, ist_width = self._axis_font.measure("Soll"), self._axis_font.measure("Ist")
        legend_width = 20 + 5 + soll_width + 14 + 20 + 5 + ist_width
        narrow = width < legend_width + 54
        y = line_height * (1.5 if narrow else .5) + 2
        left = max(7, (width - legend_width) / 2) if narrow else width - legend_width - 8
        self.create_text(7, 2, text="m³/h", anchor="nw", fill=TEXT_MUTED,
                         font=self._axis_font, tags="axis_unit")
        self.create_line(left, y, left + 20, y, fill=self.TARGET_COLOR,
                         dash=(5, 3), width=1.5, tags="legend_target")
        self.create_text(left + 25, y, text="Soll", anchor="w", fill=TEXT_MUTED,
                         font=self._axis_font, tags="legend_target")
        x = left + 25 + soll_width + 14
        self.create_line(x, y, x + 20, y, fill=self.color, width=2, tags="legend_actual")
        self.create_text(x + 25, y, text="Ist", anchor="w", fill=TEXT_MUTED,
                         font=self._axis_font, tags="legend_actual")
        return line_height * (2 if narrow else 1) + 8

    @staticmethod
    def _axis_label(value, span):
        if abs(value) >= 10000 or 0 < abs(value) < .001:
            return f"{value:.1e}".replace(".", ",")
        return number_de(value, 3 if span < .1 else 2 if span < 1 else 1)

    def _redraw(self):
        width, height = self.winfo_width(), self.winfo_height()
        if width < 2 or height < 2:
            return
        self.delete("all")
        top = self._legend(width)
        if self._now is None:
            return
        now = self._now
        data = []
        for sample in self._samples:
            if len(sample) != 3 or not self._finite(sample[0]):
                data.append(None)  # Ein beschädigtes Paket darf keine Linie überbrücken.
            elif now - self.WINDOW_S <= sample[0] <= now:
                data.append((sample[0], sample[1] if self._finite(sample[1]) else None,
                             sample[2] if self._finite(sample[2]) else None))
        numbers = [value for sample in data if sample is not None
                   for value in sample[1:] if value is not None]
        low, high = (min(numbers), max(numbers)) if numbers else (0.0, 100.0)
        span = high - low
        margin = max(1.0, span * .20)
        low = max(0.0, low - margin) if low >= 0 else low - margin
        high += margin
        renderable = math.isfinite(high - low) and high > low
        if not renderable:
            low, high = 0.0, 100.0
        span = high - low
        ticks = [low, low + span / 2, high]
        labels = [self._axis_label(value, span) for value in ticks]
        left = max(self._axis_font.measure(label) for label in labels) + 9
        right = width - 9
        line_height = self._axis_font.metrics("linespace")
        bottom = height - line_height * 2 - 8
        if right - left < 20 or bottom - top < 20:
            return

        def point(stamp, value):
            return (left + (stamp - (now - self.WINDOW_S)) / self.WINDOW_S * (right - left),
                    bottom - (value - low) / span * (bottom - top))

        for value, label in zip(ticks, labels):
            y = point(now, value)[1]
            self.create_line(left, y, right, y, fill="#DDE6EF", tags="grid")
            self.create_text(left - 5, y, text=label, anchor="e", font=self._axis_font,
                             fill=TEXT_MUTED, tags="axis_tick")
        seconds = (-60, -45, -30, -15, 0) if right - left >= 220 else (-60, -30, 0)
        for second in seconds:
            x = point(now + second, low)[0]
            self.create_line(x, top, x, bottom, fill="#E6EDF4", tags="grid")
            self.create_text(x, bottom + 4, text=str(second), anchor="n", font=self._axis_font,
                             fill=TEXT_MUTED, tags="axis_tick")
        self.create_line(left, top, left, bottom, right, bottom, fill="#A9BAC8", tags="axis")
        self.create_text((left + right) / 2, height - 1, text="Zeit [s]", anchor="s",
                         font=self._axis_font, fill=TEXT_MUTED, tags="axis_unit")
        if not numbers or not renderable:
            self.create_text((left + right) / 2, (top + bottom) / 2,
                             text="Noch keine Messdaten" if not numbers else "Wertebereich nicht darstellbar",
                             fill=TEXT_MUTED, font=self._axis_font, tags="empty")
            return

        for index in (2, 1):
            coordinates = []
            previous = None

            def finish():
                if len(coordinates) >= 4:
                    options = {"fill": self.TARGET_COLOR, "dash": (5, 3), "width": 1.5} if index == 2 else {
                        "fill": self.color, "width": 2}
                    self.create_line(*coordinates, smooth=False,
                                     tags="target_trace" if index == 2 else "actual_trace", **options)

            for sample in data:
                if sample is None or sample[index] is None:
                    finish()
                    coordinates, previous = [], None
                    continue
                if previous is not None and not 0 < sample[0] - previous[0] <= MAX_MEASUREMENT_AGE_S:
                    finish()
                    coordinates, previous = [], None
                if previous is not None and index == 2:
                    # Ein Sollsprung bleibt eine Stufe am tatsächlichen Zeitpunkt.
                    coordinates.extend(point(sample[0], previous[index]))
                coordinates.extend(point(sample[0], sample[index]))
                previous = sample
            finish()

        last = data[-1] if data else None
        source_last = self._samples[-1] if self._samples else ()
        live = (self._live and last is not None and last[1] is not None
                and len(source_last) == 3 and source_last[0] == last[0]
                and 0 <= now - last[0] <= MAX_MEASUREMENT_AGE_S)
        if not live:
            return
        x, y = point(last[0], last[1])
        self.create_oval(x - 3, y - 3, x + 3, y + 3, fill=self.color,
                         outline="#FFFFFF", tags="live_dot")
        label = number_de(last[1], 2) + " m³/h"
        badge_width = self._badge_font.measure(label) + 12
        badge_height = self._badge_font.metrics("linespace") + 6
        if badge_width >= right - left or badge_height >= bottom - top:
            return
        bx = max(left, min(right - badge_width, x - badge_width + 4))
        preferred_y = y - badge_height - 8
        if preferred_y < top:
            preferred_y = y + 8
        by = max(top, min(bottom - badge_height, preferred_y))
        self.create_rectangle(bx, by, bx + badge_width, by + badge_height,
                              fill=self._badge_bg, outline=self._badge_border, tags="live_badge")
        self.create_text(bx + badge_width / 2, by + badge_height / 2,
                         text=label, font=self._badge_font, fill=COLOR_DARK, tags="live_badge")
