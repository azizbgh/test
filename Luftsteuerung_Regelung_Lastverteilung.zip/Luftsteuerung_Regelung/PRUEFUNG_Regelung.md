# Prüfbericht zur Regelungsseite „Luftwege im Blick“

70 Softwaretests bestanden in 21.456 Sekunden. Die GUI-Tests liefen mit
Tk und CustomTkinter auf einer virtuellen Anzeige. Die Messwerte kamen aus
Softwaretests. Das vollständige Ergebnis steht in `Regelung_Lastverteilung_Tests.txt`.

Die Regelungsseite wurde bei 1024 × 700, 1366 × 768 und 1536 × 864 geprüft.
Der Testlauf umfasst auch Parameterdialog, Betriebsarten, Start, HOLD,
Fehlerquittierung und manuelle Korrektur.

Der Start über die Schaltfläche der Regelungsseite wurde mit GHF 78 m³/h,
GLF 17 m³/h, FU 0 % und Sollwert 150 m³/h geprüft. Der simulierte
DAQ-Controller erhielt nach der Verweilzeit einen FU-Befehl über 4 mA.
Ein weiterer Test bestätigt, dass sich die FU-Nachführung für feste
Betriebspunkte ausschalten lässt.

## Vergleich der Lastverteilung im Modell

Die Regression prüft beide Richtungen der Lastverteilung, den Fall eines
unzuverlässigen Zweigwerts und die Übernahme des fehlenden Anteils durch GHF,
wenn GLF kaum noch Stellreserve hat.

In einem Rückkopplungsmodell mit angenommener FU-Wirkung von 3 m³/h je
Prozentpunkt bei offenen Schiebern und Zeitkonstanten von 1,5 s beim Anstieg
und 4 s beim Abfall blieb der Hochlauf von 95 auf 150 m³/h ab etwa 25 s
bis zum Testende bei 60 s im Band 148–152 m³/h. Der anschließende Start
mit 120 m³/h Soll erreichte bei Sekunde 30 etwa 111 m³/h und ging in HOLD.
Ein Hochlauf mit angenommener geringerer FU-Wirkung verfehlte das Ziel ebenfalls.
Die Annahmen dienen der Softwareprüfung. Rampenzeit und Regelgüte in beiden
Richtungen müssen an der Anlage anhand eines Messprotokolls beurteilt werden.

Die Vorschau `Regelung_Luftwege.png` zeigt die laufende Oberfläche im
Simulationsmodus. Für das Ziel ±2 m³/h in 30 Sekunden steht die Prüfung
an der Anlage aus. Die GHF-Messuntergrenze und die Fehlerverzögerung
bleiben als Versuchsparameter in der Bedienungsanleitung dokumentiert.

## Wichtige Quellstellen

| Datei | Zeile | Inhalt |
| --- | ---: | --- |
| `luftsteuerung/oberflaeche/dashboard.py` | 47 | Navigation und Modusanzeige |
| `luftsteuerung/oberflaeche/reglerseite.py` | 23 | Bedienleiste, Parameterdialog und Messwertanzeige |
| `luftsteuerung/oberflaeche/luftschema.py` | 39 | Luftschema mit FU, GHF, GLF und Gesamtwert |
| `luftsteuerung/oberflaeche/reglerverlauf.py` | 19 | Soll- und Istverläufe über 60 Sekunden |
| `luftsteuerung/regelung.py` | 205 | Regelung und HOLD |
