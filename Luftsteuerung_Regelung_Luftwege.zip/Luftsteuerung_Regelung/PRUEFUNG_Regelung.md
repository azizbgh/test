# Prüfbericht zur Regelungsseite „Luftwege im Blick“

64 Softwaretests bestanden in 15.583 Sekunden. Die GUI-Tests liefen mit
Tk und CustomTkinter auf einer virtuellen Anzeige. Die Messwerte kamen aus
Softwaretests. Das vollständige Ergebnis steht in `Regelung_Luftwege_Tests.txt`.

Die Regelungsseite wurde bei 1024 × 700, 1366 × 768 und 1536 × 864 geprüft.
Der Testlauf umfasst auch Parameterdialog, Betriebsarten, Start, HOLD,
Fehlerquittierung und manuelle Korrektur.

Die Vorschau `Regelung_Luftwege.png` zeigt die laufende Oberfläche im
Simulationsmodus. Für das Ziel ±2 m³/h in 30 Sekunden steht die Prüfung
an der Anlage aus. Die GHF-Messuntergrenze und die Fehlerverzögerung
bleiben als Versuchsparameter in der Bedienungsanleitung dokumentiert.

## Wichtige Quellstellen

| Datei | Zeile | Inhalt |
| --- | ---: | --- |
| `luftsteuerung/oberflaeche/dashboard.py` | 47 | Navigation und Modusanzeige |
| `luftsteuerung/oberflaeche/reglerseite.py` | 23 | Bedienleiste, Parameterdialog und Messwertanzeige |
| `luftsteuerung/oberflaeche/luftschema.py` | 39 | Luftschema mit FU, GHF, GLF und Gesamtwert |
| `luftsteuerung/oberflaeche/reglerverlauf.py` | 19 | Soll- und Istverläufe über 60 Sekunden |
| `luftsteuerung/regelung.py` | 204 | Regelung und HOLD |
