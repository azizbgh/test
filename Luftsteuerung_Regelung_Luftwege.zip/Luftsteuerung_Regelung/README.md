# Nassheuer-Luftsteuerung mit Regelungsseite

Das Programm bleibt modular. Die ZIP vollständig entpacken und die Ordner
zusammenlassen; `main.py` ist der Programmeinstieg.

```text
python -m pip install -r requirements.txt
python main.py --simulate
```

Der Simulationsstart öffnet keine NI-Hardware. Die Beispielsensoren sind kein
Anlagenmodell. Die Regelungsseite zeigt das Luftschema für FU, GHF und GLF
sowie den Gesamtverlauf und die beiden Zweigverläufe. Über **Parameter**
öffnest du die PID-Werte und Versuchseinstellungen. Stopp und Regelfehler
halten die letzten Stellbefehle.

Hardwarebetrieb nach betrieblicher Freigabe:

```text
python -m pip install -r requirements-hardware.txt
python main.py --hardware
```

Dieser Start fordert bereits dreimal 4 mA an. Der passende NI-DAQmx-Treiber
muss auf dem Rechner vorhanden sein. FU-Nachführung ist zunächst ausgeschaltet.

Bedienung, offene Versuchsparameter, Protokolle und Prüfschritte:
[README_Regelung.md](README_Regelung.md).

Softwareprüfungen: `python -m unittest discover -s tests -v`.
GUI-Prüfungen benötigen zusätzlich eine verfügbare grafische Anzeige.
